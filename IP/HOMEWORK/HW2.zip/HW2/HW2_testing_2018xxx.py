import unittest
from HW2_2018xxx import minFunc



class testpoint(unittest.TestCase):
	def test_minFunc(self):
		
                
if __name__=='__main__':
	unittest.main()
