# function to get weather response
def weather_response(location, API_key):
	return 
	# write your code 

# function to check for valid response 
def has_error(location,json):
	# write your code 
	return 

# function to get attributes on nth day
def get_temperature (json, n=0):
	# write your code 
	return 

def get_humidity(json, n=0):
	# write your code 
	return 

def get_pressure(json, n=0):
	# write your code 
	return 

def get_wind(json, n=0):
	# write your code 
	return 

def get_sealevel(json, n=0):
	# write your code
	return 




