s1_q1 = "end_other"
s1_q2 = "count_code"
s2_q1 = "end_begin_other"
s2_q2 = "valid_password"
s3_q1 = "count_matchingChars"
s3_q2 = "valid_password"

# Session 1 Question 1
s1_q1_cases = [
[["Hiabc", "abc"], True],
[["AbC", "HiaBc"], True],
[["abc", "abXabc"], True],
[["abc", "defx"], False],
]

# Session 1 Question 2
s1_q2_cases = [
[["aaacodebbb"], 1],
[["cpdexxcode"], 1],
[["cozexxcope"], 2],
[["aabbccc"], 0],
]

# Session 2 Question 1
s2_q1_cases = [
[["AbCHiabc", "abc"], True],
[["AbC", "ABCHiaBc"], True],
[["abc", "aBCabXabc"], True],
[["abc", "aCCabXabc"], False],
]

# Session 2 Question 2
s2_q2_cases = [
[["aaac1@SD"], True],
[["ASDF12@23"], True],
[["cope1234"], False],
]

# Session 3 Question 1
s3_q1_cases = [
[["abcdef", "defghia"], 4],
[["bbbbbbb", "Abbb"], 1],
[["aabcdddekll12@", "bb22llll@k55"], 5],
[["abc", "ABC"], 3],
[["abc", "defx"], 0],
]

# Session 3 Question 2
s3_q2_cases = [
[["aaac1@SD"], True],
[["ASDF12@23"], True],
[["cope1234"], False],
[["Aaa12@21aaA"], False],
]

names = [
[],
[s1_q1, s1_q2],
[s2_q1, s2_q2],
[s3_q1, s3_q2],
]

cases = [
[],
[s1_q1_cases, s1_q2_cases],
[s2_q1_cases, s2_q2_cases],
[s3_q1_cases, s3_q2_cases],
]
