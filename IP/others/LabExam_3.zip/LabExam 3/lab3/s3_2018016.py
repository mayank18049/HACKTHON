def count_matchingChars(s1,s2):
	l1=len(s1)
	l2=len(s2)
	result=0
	for i in range(0,l1-1):
		for j in range (0,l2-1):
			if ord(s1[i])>=65 and ord(s1[i])<=90:
				if ord(s1[i])==ord(s2[j]) or (ord(s1[i])-32==ord(s2[j])):
					result=result+1
					break
			if s1[i]==s2[j]:
				result=result+1
				break
	return(result)

def valid_password(s3):
	up_flag=0
	num_flag=0
	char_flag=0
	for i in range(0,len(s3)-1):
		if ord(s3[i])>=65 and ord(s3[i])<=90:
			up_flag=1	
		if ord(s3[i])>=48 and ord(s3[i])<=57:
			num_flag=1
		if ord(s3[i])==95 or ord(s3[i])==64 or ord(s3[i])==36:
			char_flag=1
	if len(s3)<8:
		return (False)
	elif up_flag==0:
		return (False)
	elif num_flag==0:
		return (False)
	elif char_flag==0:
		return (False)
	else :
		return(True)

print("No. of matching characters are "+str(count_matchingChars("aabcdddek1112@","bb221111@k55")))
print("Password check return value "+str(valid_password("Aaa12@21aaA")))
