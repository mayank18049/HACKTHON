#Midterm Lab Exam Set 3 - 2018
#Name:Shashank Sehrawat
#Roll Number:2018095
#Section:A
#Group:07
#Date:23/09/2018
#function1
#def count_matching(s1,s2):
s1,s2=input().split()
x=len(s1)
y=len(s2)
#a=s2.index(i)
#b=s1.index(m)
sum=0
for i in range(x):
	for m in range(y):
		if(chr(i)==chr(m)):
			sum=sum+1
		else:
			sum=0
print(sum)
def valid_password(s3):
	x=input()
	if(len(x)>=8 and x. )