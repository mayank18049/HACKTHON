# Midterm Lab Exam Set 3 - 2018
# Name : Aditya Singh Rathore
# Roll Number : 2018007
# Section : A
# Group : 7
#Date : 23 September

#Function1

def count_matchingChars(s1,s2) :
	n = 0 
	""" Returns the count of matching characters in s1 and s2 considering the single
	count for the character which have duplicates in the string. Computation is case 	insensitive.
	If there is not even a single char matching returns 0.
	"""
	s1 = s1.casefold()
	s2 = s2.casefold()
	for char_s1 in s1 :
		if s1.count(char_s1) > 1 :
			s1 = s1.replace(char_s1*s1.count(char_s1),char_s1)
			
		else:
			s1 = s1
			
	for char_s2 in s2 :
		if s2.count(char_s2) > 1 :
			s2 = s2.replace(char_s2*s2.count(char_s2),char_s2)
			
		else:
			s2 = s2
			
	for i in s1 :
		
		if i in s2 :
			n = n+1
			
		else :
			n = n
			
	return n

#Function2
def valid_password(s3) :
	n = 0
	if len(s3) > 7:
		capitals = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
		lowers = 'abcdefghijklmnopqrstuvwxyz'
		digits = '0123456789'
		characters = '_@$'
		for w in capitals :
			for x in lowers :
				for y in digits :
					for z in characters : 
						if (w in s3) and (x in s3) and (y in s3) and (z in s3) :
							n = n+1
						else :
							n = n 
		if n>0:
			bool = 'True'
		else:
			bool = 'False' 
			
	else :
		bool = 'False'		
	return bool 
			
		
	
if __name__ == '__main__' : 
	s1='abcddue'#input('enter s1 here : ')
	s2 = 'aauiocdoj'#input('enter s2 here : ')
	s3 = '123afaghBB@'#input('enter s3 here : ')
	x = count_matchingChars(s1,s2)
	y = valid_password(s3)
	print('No. of matching characters are :' , x)
	print("Password Check returns value : " , y) 
		
			

				
