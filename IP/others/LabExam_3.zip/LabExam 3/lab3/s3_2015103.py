# Midterm Lab Exam Set 3 - 2018
# Name: Subramanyam Dantu
# Roll Number: 2015103
# Section: B
# Group: NA
# Date: 23/09/2018

def count_matchingChars(s1, s2):
	count = 0

	s1 = s1.lower()
	s2 = s2.lower()
	
	new_s1 = ""
	new_s2 = ""

	for i in s1:
		if i not in new_s1:
			new_s1 = new_s1 + i

	for i in s2:
		if i not in new_s2:
			new_s2 = new_s2 + i

	for i in new_s1:
		if i in new_s2:
			count += 1

	return count



def valid_password(s3):
	flag = 1

	# Condition 1
	if len(s3) < 8:
		return False

	# Condition 3
	for i in s3:
		if i >= "A" and i <= "Z":
			flag = 1
			break
		else:
			flag = 0

	if flag == 0:
		return False

	# Condition 4
	for i in s3:
		if i >= "0" and i <= "9":
			flag = 1
			break
		else:
			flag = 0

	if flag == 0:
		return False

	# Condition 5
	for i in s3:
		if i == "_" or i == "@" or i == "$":
			flag = 1
			break
		else:
			flag = 0

	if flag == 0:
		return False

	# Condition 6
	i = 0
	j = len(s3) - 1
	while i < len(s3)/2:
		if s3[i] == s3[j]:
			flag = 0
		else:
			flag = 1
			break
		i += 1
		j -= 1

	if flag == 0:
		return False
	else:
		return True

		