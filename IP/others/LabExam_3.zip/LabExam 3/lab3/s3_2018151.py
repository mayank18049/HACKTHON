# Name:		Jayant Chhillar
# Roll no.:	2018151
# Section:	A
# Group:	7
# Date:		23/09/2018
from string import *
# Function 1 :
def count_matchingchars(s1,s2):
	temp=''
	count=0
	for c in s1:
		if temp.find(c)==-1:
			for x in s2:
				if x.lower()==c.lower():
					count+=1
					break
		temp+=c


	return count

# Function 2 : 
def valid_password(s3):
	flag=0
	if (s3.isalpha())==False:
		if (s3.isdigit())==False:
			if (s3.islower())==False:
				if s3.find('_') !=-1 or s3.find('@') !=-1 or s3.find('$') !=-1:
					if len(s3)>=8:
						length=len(s3)
						if length%2 != 0:
							r= int(length/2)
							fhalf=s3[:r]
							lhalf=''
							for c in s3[(r+1):]:
								lhalf=c+lhalf
							if fhalf!=lhalf:
								flag = 1
						else:
							r= (length/2)
							fhalf=s3[:r]
							lhalf=''
							for c in s3[r:]:
								lhalf=c+lhalf
							if fhalf!=lhalf:
								flag = 1
	if flag==0:
		return False
	else:
		return True



# Printing Output:
print('No. of matching characters are : ' + str(count_matchingchars("aabcdddek1112@","bb221111@k55")))
print('Password check returns value : ' + str(valid_password("Aaa12@21aaA")))