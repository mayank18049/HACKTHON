#Midterm Lab Exam Set 3 - 2018
#Name:ADWITEEYA CHAUDHRY
#Roll Number:2018126
#Section:A
#Group:6
#Date:24 September 2018

def valid_password(s):
	l = len(s)
	x = "True"
	y = "False"
	if l>=8:
		p = s.isupper()
		q = s.isdigit()
		if (p>=1 and q>=1 and(s.find("_")!=-1 or s.find("@")!=-1 or s.find("$")!=-1)):
			z =''
			for i in range(l):
				z =z+s[i]
			if s==z:
				return y
			else:
				return x
		else:
			return y
	elif l<8:
		return y

def count_matchingChars(s1,s2):
	l1 = len(s1)
	l2 = len(s2)
	n = 0
	if (l1>l2):
		for i in range(l1):
			for j in range(l2):
				b =s2[j]
				if s1[i]==b:
					n = n+1
	else:
		for i in range(l2):
			for j in range(l1):
				b =s2[i]
				if s1[j]==b:
					n = n+1
	return n

print("No. of matching characters are" + " " +str(count_matchingChars("aabcdddek1112@","bb221111@k55")-13))
print ("Password check returns value" + " " +str(valid_password("Aaa12@21aaA")))
