#Midterm Lab exam set 3 - 2018
#Mohammad Zaid Yasin
#2016248
#section - B
#group - 2
#23-09-2018





def count_matchingChars(s1,s2):
	a = ""
	b = ""
	c=0
	for i in range(0,len(s1)):
		if(s1[i] not in a):
			a=a+s1[i]
	for i in range(0,len(s2)):
		if(s2[i] not in b):
			b=b+s2[i]
	a=a.lower()
	b=b.lower()
	for i in a:
		if i in b:
			c+=1
	return(c)

def valid_password(s3):
	c=0
	d=0
	e=0
	f=0
	if(len(s3)<8):
		return False
	elif(len(s3)>=8):
		ab=0
		fg=len(s3)-1
		a=False
		for i in range(0,len(s3)):
			if(s3[ab]==s3[fg]):
				a=False
			else:
				a=True
			ab+=1
			fg-=1
		return a
	else:
		for i in range(0,len(s3)):
			if(s3[i].isupper()):
				c+=1

			if(s3[i].isdigit()):
				d+=1

			if(s3[i]=="_" or s3[i]=="@" or s3[i]=="$"):
				e+=1

		if(c>0 and e>0 and d>0):
			return True
		else:
			return False