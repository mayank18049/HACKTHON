def count_matchingChars(s1,s2):
	count=0
	n=0
	s=''
	s1=s1.lower()
	s2=s2.lower()
	for c in s1:
		for m in s2:
			if m==c:
				count=count+1
				s=s+m
		if count>0:
			n=n+1
			count=0
	"""for k in range(0,len(s)):
		for j in range(1,len(s)):
			if s[k]==s[j]:
				s"""
	return n
print("No. of matching characters are "+str(count_matchingChars('aabcdddek1112@','bb221111@k55')))

def valid_password(s3):
	n1=0
	n2=0
	n3=0
	n4=0
	if len(s3)>=8:
		for m in range(0,len(s3)//2):
			if s3[m]==s3[len(s3)-m-1]:
				n4=n4+1

		for x in s3:
			if 64<ord(x)<91:
				n1=n1+1
			elif 47<ord(x)<58:
				n2=n2+1
			elif x=='_' or x=='@'or x=='$':
				n3=n3+1
		if n4!=(len(s3)//2) and n1>0 and n2>0 and n3>0:
			return True
		else:
			return False
	else:
		return False
print ("Password check returns value "+ str(valid_password('Aaa12@21aaA')))