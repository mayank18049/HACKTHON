# Midterm Lab Exam Set 3 - 2018
# Name: Ayush Goel
# Roll No.: 2018029
# Section: A
# Group: 5
# Date: 23/09/2018
def count_matchingChars(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	count=0
	s=''
	for i in range(len(s1)):
		for j in range(len(s2)):
			if(s1[i]==s2[j] and s.find(s1[i])==-1):
				s+=s1[i]
				count+=1
	return count


def valid_password(s3):
	palin=0
	upper=0
	char=0
	dig=0
	count=0
	for i in range(len(s3)//2):
		if(s3[i]==s3[len(s3)-1-i]):
			count+=1
	if(count==len(s3)//2):
		palin=1
	for i in range(len(s3)):
		if(s3[i].isupper()):
			upper+=1
		if(s3[i].isdigit()):
			dig+=1
		if(s3[i]=='_' or s3[i]=='@' or s3[i]=='$'):
			char+=1
	if(len(s3)>=8 and upper>0 and dig>0 and char>0 and palin==0):
		return True
	else:
		return False

print("No. of matching characters are "+str(count_matchingChars("aabcdddekll12@","bb22llll@k55")))
print("Password check returns value "+ str(valid_password("Aaa12@21aaA")))