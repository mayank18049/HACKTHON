# midterm lab exam set 3 - 2018
# Name : Pranshu kumar
# section : A
# Roll No. : 2018070
# Group : 6
# Date: 23/09/2018


def count_matchingChars(s1,s2) :
	
	count = 0
	for k in s1 :
		for l in s2 :
			if l==k :
				count = count + 1


def valid_password(s3) :
	count = 0
	flag=0
	x=0
	y=0
	z=len(s3)
	w=0
	for k in s3:
		if k>='A' and k<='Z' :
			count+=1
	for l in s3:

		if l.isdigit():
			flag+=1

	for m in s3:
		if m=="_" or m=="@" or m=="$" :
			x+=1
	for q in range((z-1)/2) :
		if s3[q]==s3[z-1] :
			z-=1
			w=1
		else:
			w=0
			break


	if len(s3)==8 and count!=0 and flag !=0 and x!=0 and w==0:
		return True

	else :
		return False


print("no. of matching characters are " + str(count_matchingChars("aabcdddek1112@","bb221111@k55")))
print("password check return value " + str(valid_password("Aaa12@12aaA")))






