# Midterm Lab Exam Set 3 - 2018
# Name : Simarjeet Singh
# Roll Number : 2018103
# Section : A
# Group : 7
# Date : 23-09-2018

def count_matchingChars(s1,s2):
    lngth_s1 = len(s1)
    lngth_s2 = len(s2)
    new_s1 = ""
    new_s2 = ""
    count = 0
    
    for i in range (lngth_s1):              # To remove duplicates in s1
        if (not(s1[i] in new_s1)) :
            new_s1 += s1[i]
            
    for i in range (lngth_s2):              # To remove duplicates in s2
        if (not(s2[i] in new_s2)) :
            new_s2 += s2[i]
            
    for i in range(len(new_s1)):
        ascii_value_1 = ord(new_s1[i])                                          
        if ((ascii_value_1 >= 65) and (ascii_value_1 <= 90)):  
            new_ascii_value_1 = ascii_value_1 + 32
        elif ((ascii_value_1 >= 97) and (ascii_value_1 <= 122)):     
            new_ascii_value_1 = ascii_value_1 - 32
        for j in range(len(new_s2)):
            ascii_value_2 = ord(new_s2[j])
            if ((ascii_value_1 == ascii_value_2) or (new_ascii_value_1 == ascii_value_2)):
               count += 1                              
           
    return(count)           
    
def valid_password(s3):
    if (len(s3) >= 8):
       count_cap = 0
       count_num = 0
       count_spec = 0
       pal = 1
       for i in range (len(s3)):
           ascii_value = ord(s3[i])
           if ((ascii_value >= 65) and (ascii_value <= 90)):
              count_cap += 1 
           elif ((ascii_value >= 48) and (ascii_value <= 57)):   
              count_num += 1
           elif ((s3[i] == "_") or (s3[i] == "@") or (s3[i] == "$")):
              count_spec += 1
       
       for i in range(len(s3)//2):                                       # To check for palindrome
           if s3[i] == s3[len(s3)-1-i]:
              c = 1
           else :
              pal = 0
              break
               
       if ((count_cap >= 1) and (count_num >= 1) and (count_spec >= 1) and (pal == 0)) :       
           return(True)
       else:
           return(False)
    else:
        return(False)                  
                    
