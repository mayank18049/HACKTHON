#Midterm Lab Exam
#roll No.2018128
def count_matchingChars(s1,s2):
    for j1 in range(0,len(s1)):
        if s1[j1] not in t1:
            t1=t1+s[j1]

    for j2 in range(0,len(s2)):
        if s2[j2] not in t2:
            t2=t2+s[j2]

    t1.tolower()
    t2.tolower()
    cnt=0

    for k in range(0,len(t1)):
        if t1[k] in t2:
            cnt=cnt+1

    return cnt

def valid_password(s3):
    n=1
    if len(s3)<8:
        n=0
    for i in range(0,len(s3)):
        if s3[i].isupper:
            a=1
    if a==0:
        n=0
    for i1 in range(0,len(s3)):
        if s3[i1].isdigit:
            b=1
    if b==0:
        n=0
    t=''
    for c in s3:
        t=c+t
    if t==s3:
        n=0
    for i2 in range(0,len(s3)):
        if (s3[i2]=='_' or s3[i2]=='@' or s3[i2]=='$'):
            d=1     
    if d==0:
        n=0
    if n==1:
        return True
    else:
        return False

print(valid_password('abcd1234'))
print('abc','def')    
        
        

            

