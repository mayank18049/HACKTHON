


#midterm Lab Exam Set3 - 2018
#Name    =   arbaaz khan
#Roll no   =    2018023
#Section  = A
#Group  =  7
#Date   = 23/09/2018


#funtion 2
s3=str(input())
q=len(s3)
for a in s3:
	if (q>7)and(96<ord("a")<123)and(s3!=s3[::-1])and(a.isdigit()==True)and(a.ischar()==True):
		print("True")
	else:
		print("False")



#funtion 1



s1 = str(input())
s2 = str(input())
for q in s1:
	w=s2.count(q)
	print(w)



