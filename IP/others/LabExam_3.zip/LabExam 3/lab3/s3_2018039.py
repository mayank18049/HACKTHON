def valid_password(s3):

	if(len(s3) >= 8 and s3.find('_') != -1 or s3.find('@' ) != -1 or s3.find('$') != -1):
		for i in range (len(s3)):
			if(ord (s3[i]) >= 97 and ord(s3[i])<= 122 and ord(s3[i]) >=67 and ord(s3[i]) <= 90):
				if(ord(s3[i] )>= 48 and ord(s3[i] )<= 57):
					if (s3 [i] != s3[len(s3)- i-1] ):

						i = i +1
		return("True")

		


s3= input()
t = valid_password (s3)
print ("Password check returns value" , t)


def count_matchingChars(s1,s2):
	i = 0
	for i in range(len(s1)):
		if( s2.find(s1[i]) != -1 and s1[i] != s1[i +1]):
			i = i +1 
		else:
			i = i 
	return(i)

s1 = input("Enter first string: ")
s2 = input("Enter second string: ")
s1  = s1.lower()
s2 = s2.lower()
t = count_matchingChars(s1,s2)
print(t)