#Midterm Lab Exam Set 3 -2018
#Name: Anuneet Anand
#Roll Number:2018022
#Section:A
#Group:6
#Date: 23/09/2018

#Function1

def count_matchingChars(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	a=''
	b=''
	c=0
	for i in s1:
		if a.find(i)==-1:
			a=a+i           #Storing unique characters from s1 in a
	for i in s2:
		if b.find(i)==-1:
			b=b+i           #Storing unique characters from s2 in b
	for i in a:
		if b.find(i)!=-1:
			c=c+1
	return c


#s1=input()
#s2=input()			
#print(count_matchingChars(s1,s2))

#Function2

def valid_password(s3):
	l=len(s3)
	a=False
	b=True
	c=False
	d=False
	e=False
	f=True
	t=''
	if l>=8:
		a=True
	for i in s3:
		if not((ord(i)>=ord('A')and ord(i)<=ord('Z'))or(ord(i)>=ord('a')and ord(i)<=ord('z'))or(ord(i)>=ord('0')and ord(i)<=ord('9'))or(i=='_'or i=='@' or i=='$')):
			b=False
		if (ord(i)>=ord('A')and ord(i)<=ord('Z')):
			c=True
		if (ord(i)>=ord('0')and ord(i)<=ord('9')):
			d=True
		if (i=='_'or i=='@' or i=='$'):
			e=True
		t=i+t                             #reverse string
	if (s3==t):
		f=False
	return (a and b and c and d and e and f)	

#s3=input()
#print(valid_password(s3))

print("No. of matching characters are "+str(count_matchingChars("aabcdddek1112@","bb221111@k55")))
print("Password check returns value "+str(valid_password("Aaa12@21aaA")))