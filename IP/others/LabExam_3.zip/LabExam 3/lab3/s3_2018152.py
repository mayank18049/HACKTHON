
def valid_password(s3):
	value=0
	len(s3)>=8
	for k in range(len(s3)):
		if s3[k] == "_" or s3[k] == "@"or s3[k] == "$"
		value=value+1
		break:
	for k in range(len(s3)):
		if s3[k].isupper















		






def count_matchingChars(s1,s2):
    value=0
    x=0
    for y in range(len(s2)):
    	for x in range(len(s1)):
    		a=s1[x]
    		if s2.find(a)!=-1:
    			if s2[x]!=s1[x-1]:
    				value=value+1
    return value

print(count_matchingChars("abc","defx"))
print(count_matchingChars("abc","aa11bb"))
















