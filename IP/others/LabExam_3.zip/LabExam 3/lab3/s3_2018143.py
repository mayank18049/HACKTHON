#mid term lab exam set 3 2018
#Harsh Sonkar
#2018143
#sec A
#group 07
#lab 320



def count_matchingChars(s1,s2):
  
  o=s2.lower()
  i=s1.lower()
  s=0
  for c in i:
    
    if o.find(c)!=-1:
      s=s+1
     
  return s



def valid_password(s3):
  l=len(s3)
  q=0
  r=0
  t=0
  for c in s3:
    if c.isupper()==True:
      q=q+1
    if c.isalnum()==True:
      r=r+1
    if c=="_" or c=="@" or c=="$":
      t=t+1
  #if l%2!=0:
    #if s3[0:(l+1/2)]==s3[-1:(l+1)/2):-1]:
       #return True

    if l>=8 and q>=1 and r>=1 and t>=1 and :
    return True



print("No. of matching characters are "+str(count_matchingChars("Abcdef","Bcdf")))
print("Password check returns value "+str(valid_password("aaac1@SD")))
