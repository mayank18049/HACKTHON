def count_matchingChars(s1,s2):
	n=0
	s1=s1.lower()
	s2=s2.lower()
	for i in s1:
		a=s2.find(i)
		if a!=-1:
			n+=1
			s2=s2.replace(i,"")
		else:
			continue
	return n




def valid_password(s3):
	n=len(s3)
	if n>=8:
		a=-1
		b=0
		for i in range(10):
			a=s3.find(str(i))
			if a==-1:
				b+=0
			else:
				b+=1
		if b==0:
			return False
		else:
			if s3==s3.lower():
				return False
			else:
				c=s3.find("_")
				d=s3.find("@")
				e=s3.find("$")
				if c==-1 and d==-1 and e==-1:
					return False
				else:
					s4=""
					for i in range(n):
						s4=s3[i]+s4
					if s4==s3:
						return False
					else:
						return True
	else:
	    return False			








