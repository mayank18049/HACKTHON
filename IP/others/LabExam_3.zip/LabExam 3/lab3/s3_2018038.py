"""
Name-Himanshu Raj
Roll No-2018038
Section-A
Group-6"""

def count_matchingChars(s1,s2):
	l1=len(s1)
	a1=s1.lower()
	a2=s2.lower()
	c=0
	for i in range(l1):
		if(a1[i] in a2):
			c+=1
	return c

def valid_password(s3):
	l=len(s3)
	f1=f2=f3=0
	if(l<8):
		return False
	for i in range(l):
		if('A'<=s3[i]<='Z'):
			f1=1
		elif('0'<=s3[i]<='9'):
			f2=1
		elif(s3[i]=='@' or s3[i]=='_' or s3[i]=='$'):
			f3=1
	if(f1==0 or f2==0 or f3==0 or s3==s3[::-1]):
		return False
	else:
		return True