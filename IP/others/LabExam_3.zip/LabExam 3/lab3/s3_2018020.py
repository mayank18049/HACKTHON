def count_matching(s1,s2):
	s1=set(s1.lower())
	s2=set(s2.lower())
	num=0
	for i in s1 :
		if i in s2 :
			num=num+1
		else:
			continue
	return num 		
		




def valid_password(s3):
	if len(s3)<8:
		return False
	elif s3==s3[::-1]:
		return False
	else :
		k=False
		finalK=False
		for i in s3 :
			if 'a'<=i<='z':
				k=True
				finalK=k or finalK
			else:
				k=False
				finalK=k or finalK
	
		L=False
		finalL=False
		for i in s3 :
			if 'A'<=i<='Z':
				L=True
				finalL=L or finalL
			else:
				L=False
				finalK=L or finalL
	
		m=False
		finalm=False
		for i in s3 :
			if '0'<=i<='9':
				m=True
				finalm=m or finalm
			else:
				m=False
				finalm=m or finalm
		n=False
		finaln=False
		for i in s3:
			if i=='_' or i=='@' or i=='$':
				n=True
				finaln=n or finaln
			else:
				n=False
				finaln=finaln or n
		print(finalL,finalm,finaln,finalK)		
		if (finaln and finalm and finalK and  finalL)==True:
			return True
		else:
			return False









								