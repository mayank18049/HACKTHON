#mid term lab exam set 3 
#Name-Himanshi Mathur
#Roll number-2018037
#section-A
#group-5
#DATE-23/09/2018


def count_matchingchars(s1,s2):
	s1=str(s1)
	s2=str(s2)
	s1=s1.lower()
	s2=s2.lower()
	n1=len(s1)
	n2=len(s2)
	b=0
	if n1>n2:
		for i in range (n1):
			for i in range (n2):
				a=s2.count(s1)
				
				if a>=1:
					b=b+1
				elif a==0:
					b=0
	else:
		for i in range (n2):
			for i in range (n1):
				a=s1.count(s2)
				
				if a>=1:
					b=b+1
				elif a==0:
					b=0
	return (b)
#flag=count_matchingchars("bbbbaa","Abb")
#print(flag)





def valid_password(s3):
	s3=str(s3)
	n=len(s3)
	a=len(s3)
	if a>=8:
		for i in range (n+1):

			if (s3[i:]>=ord(65) and s3[i:]<=ord(90)) or (s3>=ord(97) and s3[i:]<=ord(122)):
			
				if s3.count(s3[i:]>=ord(65) and s3[i:]<=ord(90))>=1:
					if s3.count(s3[i:]>=ord(48) and s3[i:]<=ord(57))>=1:
						if s3.count("_" or "@" or "$")>=1:
							if s3!=s3[::-1]:
								print("True")
							else:
								print("false")
#flag=valid_password("aAbc09hgf")
#print(flag)