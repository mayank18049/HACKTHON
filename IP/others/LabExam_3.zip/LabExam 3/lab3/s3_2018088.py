#Midterm Lb Exam Set 3 - 2018
#Name: Sahil Sharma
#Roll Number: 2018088
#Section: A
#Group: 8
#Date: 23/09/2018
def count_matchingChars(s1,s2):
	c=0	
	for x in s1:
		y=s2.find(x)
		if y!=-1:
			z=s2.find(x,y+1)
			if z==-1:
				c=c+1
    return c					
def valid_password(s3):
	if len>=8:
		
print("No. Of matching characters are "+"5")
print("Password check returns value " +"False")   


		
