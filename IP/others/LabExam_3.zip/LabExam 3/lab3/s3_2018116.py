#Midterm Lab Exam Set 3 - 2018
#Name: Vibhu Agrawal
#Roll No: 2018116
#Section: A
#Group: 04
#Date: 23/09/2018


#function1
def count_matchingChars(s1,s2):

	s1=s1.lower()
	s2=s2.lower()
	count=0

	c=0
	for i in s1:
		for j in s1:
			if i==j:
				c=c+1
				if c>1 and i==str(s1.find(j)+1):
					s1=s1.replace(str(s1.find(j)+1),"")

	c2=0
	for i in s2:
		for j in s2:
			if i==j:
				c2=c2+1
				if c2>1 and i==str(s1.find(j)+1):
					s2=s2.replace(str(s1.find(j)+1),"")


	for letter in s1:
		for alpha in s2:
			if letter == alpha:
				count=count+1
				break
			

	if count>0:
		return(count)

	else:
		return(0)



#function2
def valid_password(s3):

	# a_ascii=ord(a)
	# z_ascii=ord(z)
	# Ac_ascii=ord(A)
	# Zc_ascii=ord(Z)

	if len(s3)<8:
		return (False)

	# for alpha in s3:
	# 	if ord(a)<=ord(s3[alpha]) and ord(s3[alpha])<=ord(z):
	# 		break
	# 	else:
	# 		return (False)

	c1=0
	for alpha_upper in s3:
		if ord("A")<=ord(alpha_upper) and ord(alpha_upper)<=ord("Z"):
			c1=c1+1
		
	if c1==0:
		return(False)

	c2=0
	for digit in s3:
		if ord("0")<=ord(digit) and ord(digit)<=ord("9"):
			c2=c2+1
		
	if c2==0:
		return(False)


	c3=0
	for sym in s3:
		if ord(sym)==ord("_") or ord(sym)==ord("@") or ord(sym)==ord("$"):
			c3=c3+1
		
	if c3==0:
		return(False)

	a=""
	for i in range(len(s3)):
		a=a+s3[len(s3)-i-1]



	if s3==a:
		return(False)

	else:
		return(True)


if __name__=="__main__":
	print ("No of matching characters are " + str(count_matchingChars("aAb","ab")))

	print("Password check returns value " + str(valid_password("cope1234")))