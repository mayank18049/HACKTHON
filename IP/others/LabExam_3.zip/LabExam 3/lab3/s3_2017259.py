#Rishav Kumar
#2017259
#Section-B
def valid_password(s3):
	y=len(s3)
	a=0
	b=0
	c=0
	for i in range(y):
		if s3[i].isdigit()==True:
			a=a+1
			if s3[i]=="@"or s3[i]=="_"or s3[i]=="$":
				b=b+1
				if s3[i].isupper()==True:
					c=c+1
					if y>=8 and a>=1 and b>=1 and c>=1:
						return True
					else:
						return False


#def count_matchingChars(s1,s2):







