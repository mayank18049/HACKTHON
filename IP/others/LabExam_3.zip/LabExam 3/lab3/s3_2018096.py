def count_matchingChars(s1,s2):
    s1=s1.lower()
    s2=s2.lower()
    a=list(set(list(s1)))
    a.sort()
    b=list(set(list(s2)))
    b.sort()
    count=0
    for i in a:
        for j in b:
            if i==j:
                count+=1
    return count
#print(count_matchingChars(q,w))

def valid_password(s3):
    state=False
    l=len(s3)
    for i in s3:
        if ord(i)<=122 and ord(i)>=97:
            state=True
        else:
            state=False
    if l>=8:
        state=True
    else:
        state=False
    count1=0
    for i in s3:
        if i.isupper()==True:
            count1+=1
        count2=0
    for i in s3:
        if ord(i)>=48 and ord(i)<=57:
            count2+=1
    count3=0
    count=0
    for i in s3:
        if (ord(i)>=48 and ord(i)<=57) or (ord(i)<=122 and ord(i)>=97):
            count=0
        else:
            count3+=1
    b=""
    for i in s3:
        b=i+b
    if count1>=1 and count2>=1 and count3>=1 and b!=s3:
        state=True
    else:
        state=False
    return state
#print(valid_password("aaac1@SD"))

print("No. Of mathing characters are"+str(count_matchingChars("aabcdddek1112@","bb221111@k55")))
print("Password check return value" +str(valid_password("Aaa12@21aaA")))

f