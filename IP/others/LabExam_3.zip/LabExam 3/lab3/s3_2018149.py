#Midterm Lab Exam Set 3 - 2018
#Name = Jaiklen Singh
#Roll no. = 2018149
#Section = A
#Group = 5


#function1
def count_machingChars(s1,s2):
	count = 0
	s1 = input.str()
	s2 = input.str()
	p = s1.upper()
	q = s2.upper()
	list (q) in (p)
	a = count(q)
	return (a)




#function2
def valid_password(s3):
	s3 = input.str()
	m = len(s3)
	m >= int(8)
	n = s3[a : z]
	o = s3[Q or W or E or R or T or U or Y or U or I or O or P or A or S or D or F or F or H or H or J or K or L or Z or X or C or V or B or N or M ]
	x = s3[1 or 2 or 3 or 4 or 5 or 6 or 7 or 8 or 9 or 0]
	z = s3[_ or @ or $]
	if m and n and o and x and z:
		r = True
	else:
		r = False
	return r



