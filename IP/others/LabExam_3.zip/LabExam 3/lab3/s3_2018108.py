# Name : Tanishq
# Roll Number : 2018108
# Section : A
# Group : 4
# Date : 23.09.18

def count_matchingChars(s1,s2):
	count=0
	flagg=0
	for i in s1:
		for p in range(0,i):
			if s1[p]==i or charCompare(s1[p],i):
				flagg=1
				break
		if flagg==1:
		    flagg==0
		    continue		
		for j in s2:
			if i==j or charCompare(j,i):
				count+=1
				break
	return count


def valid_password(s3):
	ucaseFlag=False
	chFlag=False
	digFlag=False
	if len(s3)<8:
		return False
	for i in s3:
		if ord('A')<=ord(i)<=ord('Z'):
			ucaseFlag=True
		if ord('0')<=ord(i)<=ord('9'):
			digFlag=True
		if i=='_' or i=='@' or i=='$':
			chFlag=True
	if ucaseFlag==False or chFlag==False or digFlag==False:
		return False
	temp = [::-1]
	if s3==temp:
		return False

def charCompare(a,b):
	if a==b:
		return True
	elif ord('A')<=ord(a)<=ord('Z'):
		if ord(a)==ord(b) or ord(a)== ord(b)-( ord('a')-ord('A')):
		    return True
	elif ord('a')<=ord(a)<=ord('z'):
		if ord(a)==ord(b) or ord(a)== ord(b)+( ord('a')-ord('B')):
		    return True
    else:
    	return False




			


		


