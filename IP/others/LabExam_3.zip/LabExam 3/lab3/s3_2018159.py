# Midterm Lab Exam Set 3-2018
#Name: Mudit Dhawan
# Roll Number: 2018159
#Section: A
#Group: 7
#Date: 23.09.2018




import string

def count_matchingChars(s1, s2):
	count=0
	s1new=s1.lower()
	s2new=s2.lower()
	for i in string.printable:
		if s1new.find(i)>=0 and s2new.find(i)>=0:
			count+=1	
	return count




def valid_password(s3):
	count=0
	n=0
	l=len(s3)
	if l>7:
		count+=1
	for i in range(l):
		if s3[i].isupper():
			count+=1
			break


	for i in range(l):
		if s3[i].isdigit():
			count+=1
			break

	for i in range(l):
		if not(s3[i].isalnum()):
			count+=1
			break
	for i in range(int(l/2)):
		if s3[i]!=s3[l-1-i]:
			n=1
			break

	if count==4 and n==1:
		return True
	else:
		return False

		