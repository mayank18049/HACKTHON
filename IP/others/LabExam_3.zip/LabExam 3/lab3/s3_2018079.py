#Midterm Lab Exam Set 3 - 2018
#Name: Rakshit Singh
#Roll Number: 2018079
#Section: A
#Group: 7
#Date: 23-09-2018

#function 1
def count_matchingChars(s1,s2):
	count = 0
	s1 = s1.lower()
	s2 = s2.lower()
	s1 = ''.join(set(s1))
	s2 = ''.join(set(s2))
	for i in range(len(s1)):
		if s1[i] in s2:
			count += 1 
	return count
	
#function 2
def valid_password(s3):
	count_alphabet = 0
	count_digit = 0
	count_special = 0
	if s3 != s3[::-1] and len(s3)>=8 and s3.lower() != s3:
		for substrng in s3:
			if substrng.isalpha():
				count_alphabet += 1
			elif substrng.isdigit():
				count_digit += 1
			else:
				count_special += 1
		if count_special>=1 and count_digit>=1 and count_alphabet>=1:
			return "True"
		else:
			return "False"
	else:
		return "False"



#Output
print("No. of matching characters are " + str(count_matchingChars("aabcdddek1112@", "bb221111@k55")))
print("Password check returns value " + str(valid_password("Aaa12@21aaA")))






















