#midterm lab exam 
#aman shah
#2018207
#sec-A
#group-7
#23/09/2018



def count_matchingchars(s1,s2):
    n=len(s1)
    for k in n: 
    if (s1,find(s1),int(s1))    
        m=m+1
    else
        n=0
    return (n)  


def valid_password(s3):
	if(len(s3)<8):
		return False
	i=0	
	while i<len(s3):
		if(s3[i].isdigit()==True and s3[i].ischar()==True  and (s3[i]=='@' or s3[i]=='_' or s3[i]=='$')):
			return True

print('function2 returns' + str(valid_password("ASDF12@23")))
		
