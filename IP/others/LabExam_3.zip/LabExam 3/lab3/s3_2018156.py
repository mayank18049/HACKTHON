
def count_matchingChars(s1,s2) :
	s1=s1.upper()
	s2=s2.upper()
	a=0
	b=0
	for c in s2 :
		for k in s1 :
			if c==k :
				a=a+1
			else :
				a=a+0
		if a>=2:
			b=b+1
		else:
			b=b+0
	return(b)


def valid_password(s3) :
	a=0
	w=len(s3)
	if w>=8 :
		for q in s3 :
			if ord(q)>= 97 and ord(q)<=122 :
				a=a+1
				if ord(q)>=65 and ord(q)<=90 :
					a=a+1
					if ord(q)>=48 and ord(q)<=57 :	
						a=a+1
						if ord(q)==95 and ord(q)==64 and ord(36) :
							a=a+1
							if s3[::-1]!=s3 :
								a=a+1
	if a>=5 :
		return('True')
	else:
		return('False')

print(b)
print(valid_password(s3))






