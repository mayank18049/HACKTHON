# Midterm Lab Exam Set 3 - 2018
# Name: Kanishk Singh
# Roll Number: 2018044
# Section: A
# Group: 4
# Date: 23/09/2018
#You need to implement both the functions given in this module.

#function2
def valid_password(s3):
	l=len(s3)
	t=''
	for h in range(l):
		t=s3[h]+t
		if t!=s3:
			if l>=8 and (("_" in s3) or ("@" in s3) or ("$" in s3)):
				for i in s3:
					if i.isalnum():
						for j in s3:
							if j.isupper():
								for k in s3:
									if k.islower():
										return True
									else:
										return False
							else:	
								return False
					else:
						return False
			else:
				return False
		else:
 			False															 

	