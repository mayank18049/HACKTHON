#Name=Ritik Gautama
#Roll number=2018180
#Section=A
#Group=4
#function 1
def count_matchingchars(s1,s2):
	n=len(s1)
	m=len(s2)
	for i in range (0,n):
		for j in range (0,m):
			if(s1[i]==s2[j]):
				c=c+1
			else:
				return(0)	
			
				
	return (c)

#function 2


def valid_password(s3):
	l=len(s3)
	for i in range (0,l):
		if s3[i].isupper:
			b=True
		else:
			b=False
		if s3.find('_')>=0 or s3.find('@')>=0 or s3.find('$')>=0:
			c=True
		else:
			c=False
		if s3[i].isdigit:
			d=True
		else:
			d=False
	if l>=8 and b and c and d:
		return True
	else:
		return False





