#MIDTERM LAB EXAM SET 3 - 2018
#NAME : PARAS CHAUDHARY
#ROLL NUMBER : 2018167
#SECTION : A 
#GROUP : 7
#DATE : 23-09-2018
def count_matchingChars(s1,s2):
	i=0
	for x in s1 and s2:
		if (s1.isupper() or s1.islower() or s2.isupper() or s2.islower()):
			if (s1.count('x')>1 or s2.count('x')>1):
				i=i+1
				return i
			else:
				return False

		else: 
			return False

def valid_password(s3):
	if(len(s3)<8):
		return False
	else:
		for x in s3:

			if(s3.isnum() and s3.isupper()):
				while((s3[x]>= '0' or s3[x]<='9') and (s3[x]>='A' or s3[x]<='Z')):
					z=len(s3)
					if len (s3) % 2 ==0:
						m=z/2
						if (s3[0]==s3[-1] and s3[m]==s3[m+1]):
							return False
					else:
						m=(z-1)/2
						if s3[0]==s3[-1] and s3[m]==s3[m+2]:
							retun False
						
						
					else:
						return True	
				
				while(s3[x]=='_' or s3[x]=='@' or s3[x]=='$'):
					return True	
					
					else:
						return False					
	return True				

if __name__ == '__main__':
	print("Function1 returns " + str(count_matchingChars()))
	print("Function2 returns " + str(valid_password()))

count_matchingChars(s1,s2)
valid_password(s3)