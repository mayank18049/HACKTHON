def count_matchingChars(s1,s2):
	count=0
	x=len(s1)
	for i in range(x):
		if s1[i]==s2:
			count=count+1
			return count	
		else:
			return 0


def valid_password(s3):
	count=0
	flag=0
	ship=0
	for i in range(s3):
		if ((s3[i]>="A") and (s3[i]<="Z")) :
			count=count+1
	for j in range(s3):
		if ((s3[j]>=0) and (s3[j]<=9)):
			flag=flag+1
	for k in range(s3):
		if ((s3[k]=="_") or (s3[k]=="@") or (s3[k]=="$")):
			ship=ship+1
	
	if len(s3)>=8 and count>=0 and flag>=0 and ship>=0:
		pw=True 
	else :
		pw=False
 	return pw
