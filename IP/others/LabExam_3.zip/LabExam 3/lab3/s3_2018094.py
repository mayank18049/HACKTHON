# Midterm Lab Exam Set 3 - 2018
# Name : Shantanu Shukla
# Roll Number : 2018094
# Section : A
# Group : 6
# Date : 23/09/2018

#function1
def count_matchingChars(s1,s2):


	s1 = s1.lower()
	s2 = s2.lower()

	m = 0
	l = 0
	


	if(len(s1)<=len(s2)):



		for k in range(0,len(s1)):
			if(s1[k] in s2):
				
				m=m+1 


	else:
		for k in range(0,len(s2)):
			
			if(s1[k] in s1):
				
				m=m+1 


	
	return m

#function2
def valid_password(s3):

	flag1=flag2=flag3=flag4=False

	if(s3 != s3[::-1] and len(s3)>=8):

		for l in range(0,len(s3)):

			if(s3[l].isdigit()):
				flag1 = True

			elif(s3[l]>='a' and s3[l]<='z'):
				flag2 = True

			elif(s3[l]>='A' and s3[l]<='Z'):
				flag3 = True

			elif(s3[l] == '_' or s3[l] == '@' or s3[l] == '$'):
				flag4 = True

		if(flag1==flag2==flag3==flag4==True):
			return True

		else:
			return False

	else:
		return False



#print output
print("No. of matching characters are " + str(count_matchingChars('bbbbbba','Abbb')))
print("Password check returns value " + str(valid_password('cope1234')))