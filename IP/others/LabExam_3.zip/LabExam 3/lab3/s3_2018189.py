#Midterm Lab Exam Set 3- 2018
#Nmae: Satvika Ethakota
#Roll no.: 2018189
#Section A
#Group 5
#Date: 23/09/18
def count_matchingChars(s1,s2):
	a=len(s1)
	b=len(s2)
	count=0
	
		for i in range(a+1):
			for j in range(b+1):
				if s1[i]==s2[j]:
					count=count+1
						return(count)
				else:
					return(0)
	
		

def valid_password(s3):
	a=len(s3)
	if (a>=8):
		if (s3[0:]!=s3[:0]):
		
			if(
				for i in range(a+1):
					ord(Z)>=s3[i]>=ord(A)):
				if (
					for i in range(a+1): 
						ord(Z)>=s3[i]>=ord(A)):
					if( 
						for i range(a+1):
							9>=s3[i]>=0):
						if (
							for i in range(a+1):
								s3[i]=='_' or s3[i]=='@' or s3[i]=='$'):
								
	return(True)
				
	else:

		return(False)

print("Password check returns value" + str(valid_password("Aaa12@21aaA")))
print("No. of matching characters are" + str(count_matchingChars("aaaabbb","bbaa")))

					