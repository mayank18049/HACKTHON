#midterm lab exam set 3 -2018
#name:jaskirath singh
#roll number:2018150
#section:A
#group-6
#Date-23/09/2018
#you need to implement the functions given in this module





#function1
def count_matchingChars(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	if s2 in s1:
		if i in range(97,123) and k in range(65,91) and l in range(48,58):
			a1=chr(i)
			a2=chr(k)
			a3=chr(l)
			print(a1=chr(i),a2=chr(k),a3=chr(l) ,"matches")

	else:
		return 0


#function2
def valid_password(s3):
	s3=str(s3)
	cond1=s3[0:]!=s3[-1:]
	cond2=len(s3)>=8
	if cond1==True and cond2==True:
		for i in range(97,123) and k in range(65,91) and l in range(48,58):
			if chr(i) in s3 and chr(k) in s3 and l in s3 and "_" in s3 or "@" in s3 or "$" in s3:
				print("True")
	else:
		print("False")

#print output
print("no.of matching characters are"+str(count_matchingChars("aabcddek1112@","bb221111@k55")))
print("password check returns value "+ str(valid_password("Aaa12@21aaA")))


