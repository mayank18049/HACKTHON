# Midterm Lab Exam Set 3- 2018
# Name: Tanishq
# Roll No. 2018199
# Section- 'A'
# Group -7
# Date - 23/09/2018
from math import *
#first function
def count_matchingChars(s1,s2):
 n=0
 l=0
 b=''
 c=''
 a1=len(s1)
 a2=len(s2)
 while (n<a1):
    k=0
    b=s1[n]+b
    while (k<a1):
    	if (k != n):
    	   if (b==a[k]):
    	      s1=s1.replace(a[k],'')
    	   k=k+1
    n=n+1    	
 while (n<a2):
    k=0
    c=s1[n]+c
    while (k<a2):
    	if (k!=l):
    	   if (b==a[k]):
    	      s1=s1.replace(a[k],'')
    	   k=k+1
    l=l+1    	
 m=max(a1,a2)
 a=0
 c=0
 while (a<a1):
   b=0
   if (b<a2):	
     if ((s1[a].tolower())==(s2[b].tolower())):	    	
        c=c+1
   b=b+1       
 a=a+1   
 return (c)

#second function
def valid_password(s3):
 a=len(s3)
 n=0
 d=0
 e=0
 f=0
 if (a>=8):
  while (n<a):
  	if (s3[n].isalpha() and s3[n].isupper()):
  		d=1
  	elif (s3[n].isdigit()):
  	    e=1	
  	elif (s3[n]=='_' or s3[n]=='@' or s3[n]=='$'):
  		f=1
  	n=n+1	
 if (f==1 and d==1 and e==1):
 	b=a/2
 	n=0
 	w=-1
 	u=0
 	while (n<b):
 	  if (s3[n]==s3[w]):
 	    u=u+1
 	  n=n+1
 	  w=w-1  
 if (u==1):
  return (False)
 else: 
  return (True)
  
#print output
str(count_matchingChars("aabcdddek1112@","bb221111@k55"))
b="No. of matching characters are ="+ a
print (b)  
print ("Password check returns value" + str(valid_password("Aaa12@21aaA")))
  
  
  
  
  
  
  	    









