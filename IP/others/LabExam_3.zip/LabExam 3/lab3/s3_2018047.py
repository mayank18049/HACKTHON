def count_matchingChars(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	l=len(s1)
	st=1
	n=0
	i=0	
	while i<l:
		c=s1[i]
		k=s2.count(c)
		if k>0:
			n=n+1
		q=s1.count(c)
		i=i+q
	return n


def valid_password(s3):
	pl=len(s3)
	flag=0
	if(pl>=8):
		sa='abcdefghijklmnopqrstuvwxyz'
		ca='ABCDEFGHIJKLMNOPQRSTUVWXYZ'
		for i in range(0,26):
			sc=s3.count(sa[i])
			cc=s3.count(ca[i])
		if cc<1:
			flag=1
		num='0123456789'
		for j in range(0,10):
			nc=s3.count(num[j])
		if nc<1:
			flag=1
		q1=s3.count('_')
		q2=s3.count('@')
		q3=s3.count('$')
		if q1==0 and q2==0 and q3==0:
			flag=1
		for k in range(0,pl):
			news=s3[k]+news
		if s3==news:
			flag=1
	else:
		flag=1
	if flag==0:

		return True
	else:
		return False


print("No. of matching characters"+str(count_matchingChars("aabcdddek1112@","bb221111@k55")))
print("pasword returns value"+str(valid_password("Aaa12@21aaA")))


