#Midterm Lab Exam Set 3 - 2018 
#Name: Ritwik Gupta
#Roll No.: 2018086
#Section: A
#Group: 6
#Date: 23-09-2018
def count_matchingChars(s1,s2):
	t=0
	s1 = s1.upper()
	s2 = s2.upper()
	for s in s1:
		x=s2.find(s)
		if x == -1:
			t+=0
		else:
			t+=1
	return(t)

def valid_password(s3):
	t=True
	x=False
	if len(s3) < 8:
		t=False
	a='ABCDEFGHIJHKLNMOPQRSTUVWXYZ'
	for s in a:
		b=s3.find(s)
		if b == -1:
			t1=False
		else:
			x=True
	t2= t1 or x
	t=t and t2
	x=False
	a='0123456789'
	for s in a:
		b=s3.find(s)
		if b == -1:
			t1=False
		else:
			x=True
	t2= t1 or x
	t=t and t2
	x=False
	a='_@$'
	for s in a:
		b=s3.find(s)
		if b == -1:
			t1=False
		else:
			x=True
	t2= t1 or x
	t=t and t2
	x=False
	s4=''
	for q in s3:
		s4=q+s4
	if s3==s4:
		t =False
	return(t)

print("No. of matching characters are "+str(count_matchingChars("aabcdddek1112@","bb221111@k55")))
print("Password check returns value "+str(valid_password("Aaa12@21aaA")))