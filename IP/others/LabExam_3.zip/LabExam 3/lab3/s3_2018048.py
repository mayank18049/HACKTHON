def count_matchingChars(s1,s2):
	b=''
	for j in s1:
		if j.isalpha():
			j=j.lower()
		b+=str(j)
	a=''
	for i in s2:
		if i.isalpha():
			i=i.lower()
		a+=str(i)
	count=0
	
	for i in range(len(a)):
		if i!=0 and a[i]==a[i-1]:
			new="hello"			#just an empty if ;)
		
		else:	
			for j in b:
				if j==a[i]:
					count=count+1
					break
	return count




def valid_password(s3):
	flag1=False
	flag2=False
	flag3=False
	flag4=False
	if len(s3)<8:
		return False

	for i in s3:
		if i.isupper():		#to check for upper case character
			flag1=True
		elif i.isdigit():	#to check if there is a digit
			flag2=True
		elif i=='_' or i=='@' or i=='$':	#to check if there is a special character
			flag3=True
		flag=flag1 and flag2 and flag3
	
	for j in range(len(s3)//2):				#to check for palendrome
		if s3[j]!=s3[-(j+1)]:
			flag4=True
	
	flag=flag and flag4
	return flag

print("No. of matching characters are"+str(count_matchingChars("abc","defx")))
print("Password check returns value"+str(valid_password("Aaa12@21aaA")))


