#midterm lab exam set-3 - 2018
#name: bhavesh khatri
#roll no. - 2018030
#section-6
#group-6
#date-23-09-2018
#function1
def count_matchingChars(s1,s2):
	count=0
	d=len(s1)
	s1=s1.lower()
	s2=s2.lower()
	for i in range(0,d):
		if s1[i] in s2 and s1[i] not in s1[:i]:
			count+=1
	return count
#function2
def valid_password(s3):
	d=len(s3)
	if d>=8:
		a=0
		for i in range(0,d):
			if s3[i] == s3[i].upper():
				a=1
				break
		b=0
		for i in range(0,d):
			if s3[i].isdigit():
				b=1
				break
		c=0
		for i in range(0,d):
			if s3[i] == "_" or s3[i] == "@" or s3[i] == "$" :
				c=1
				break
		if s3 == s3[-1::-1]:
			e=0
		else:
			e=1
		if a==1 and b==1 and c==1 and e==1:
			return True
		else:
			return False
	else:
		return False
#output
print("no. of matching characters are" + str(count_matchingChars("aabcdddek1112@","bb221111@k55")))
print("Password check returns value" + str(valid_password("Aaa12@21aaA")))