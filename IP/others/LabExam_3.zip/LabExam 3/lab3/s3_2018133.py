#Name: Arjun Lakhera
#Roll Number: 2018133
#Section: A
#Group: 5
#Date: 23/09/2018
def count_matchingChars(s1,s2):
	s1 = s1.lower()
	s2 = s2.lower()
	s1 = set(s1)
	s2 = set(s2)
	count = 0
	for x in s1:
		for y in s2:
			if(x == y):
				count+=1
	return count		

def valid_password(s3):
	t=0
	if(len(s3)<8):
		return False
	elif(s3 == s3[::-1]):
		return False
	elif (s3.isdigit() and s3.isupper()):
			for x in s3:
				if (x == '_') or (x == '@') or (x == '$'):
					t = 0
					break
		if t == 0:
			return True
		else:
			return False
			


