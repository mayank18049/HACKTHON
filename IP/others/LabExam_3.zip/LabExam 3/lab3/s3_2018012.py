#Midterm Lab Exam Set 3 - 2018
#Name - Akshala Bhatnagar
#Roll Number - 2018012
#Section - A
#Group - 4
#Date - 23/9/18

#s1 = input()
#s2 = input()

def count_matchingChars(s1, s2):
	s1 = s1.lower()
	s2 = s2.lower()
	n1 = len(s1)
	n2 = len(s2)
	count = 0
	if n1 < n2:
		n = s2.find(s1[0])	
		if n >= 0:
			count += 1
		for i in range(1, n1):
			for j in range(0, i):
				if s1[i] != s1[j]:
					n = s2.find(s1[i])	
					if n >= 0:
						count += 1
						break
	else:
		n = s1.find(s2[0])	
		if n >= 0:
			count += 1
		for i in range(1, n2):
			for j in range(0, i):
				if s2[i] != s2[j]:
					n = s1.find(s2[i])	
					if n >= 0:
						count += 1
						break

	return count


#s3 = input()

def valid_password(s3):
	if len(s3) >= 8:
		flag = 0
		for i in range(0, len(s3)):
			if (s3[i] >= 'a' and s3[i] <= 'z') or (s3[i] >= 'A' and s3[i] <= 'Z'):
				flag = 1
		if flag == 1:
			flag1 = 0
			for i in range(0, len(s3)):
				if s3[i] >= 'A' and s3[i] <= 'Z':
					flag1 = 1
			if flag1 == 1:
				flag2 = 0
				for i in range(0, len(s3)):
					if s3[i] >= '0' and s3[i] <= '9':
						flag2 = 1
				if flag2 == 1:
					flag3 = 0
					for i in range(0, len(s3)):
						if s3[i] == '_' or s3[i] == '@' or s3[i] == '$':
							flag3 = 1
					if flag3 == 1:
						a = 0
						b = len(s3) - 1
						flag4 = 0
						while a < b:
							if s3[a] != s3[b]:
								flag4 = 1
							a += 1
							b -= 1
						if flag4 == 1:
							return True
			if flag1 == 0 or flag2 == 0 or flag3 == 0 or flag4 == 0:
				return False
	else:
		return False

print("No. of matching characters are -", str(count_matchingChars(s1, s2)))
print("Password check returns value ", str(valid_password(s3)))