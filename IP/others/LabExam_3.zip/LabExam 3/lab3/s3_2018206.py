def count_matchingChars(s1,s2):
	c=[]
	s1=s1.lower()
	s2=s2.lower()
	for i in range(len(s1)):
		if s1[i] in s2:
			if s1[i] in c:
				continue
			else:
				c.append(s1[i])
	c.sort()
	print(c)		
	count=len(c)
	return count

def valid_password(s3):
	chk,alph,dig,sp,caps=0,0,0,0,0
	for i in range(len(s3)):
		if len(s3)>=8 and s3!=s3[::-1]:
			chk=1
			if s3[i].isalpha():
				alph+=1
			elif s3[i].isdigit():
				dig+=1
			elif s3[i] in ['_','@','$']:
				sp+=1
			else:
				chk=0
				break
	if chk==1 and s3[i].isalpha():
		for i in range(len(s3)):
			if ord(65)<=s3[i]<=ord(90):
				caps+=1
	if chk==1 and caps>0 and alph>0 and sp>0 and dig>0:
		return True
	else:
		return False