

def count_matchingChars(s1,s2):
	i=0
	c=0
	s=s1.lower()
	s2=s2.lower()
	l=len(s)
	while i<l:
		if s[i].find(s2)>=0:
			c+=1
			i=0
			s=s.replace(s[i],'')
			l=len(s)
		i=i+1	

	return c
	

			 
def valid_password(s3):
	a=s3
	l=len(a)
	n=0
	b=0
	c=0
	m='a0123456789b'
	lis=['_','@','$']
	for ch in a:
		if ch in m:
			n+=1
		elif ch.isupper():
			b+=1
		elif ch in lis:
			c+=1
	if l>=8 and n>=1 and b>=1 and c>=1 and a[::-1]!=a:
		return True
	else:
		return False


print('No. of matching characters are' + str(count_matchingChars('aabcdddek1112@','bb221111@k55')))
print('password check returns value'+str(valid_password('Aaa12@21aaA')))		
