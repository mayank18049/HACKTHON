#Midterm Lab Exam Set 3 - 2018
#Name = Sachin Sharma
#Roll number : 2018184
#Section : A
#Group : 08
#Date : 23 sept 2018


#function_1
def count_matchingChars(s1,s2):
	count=0
	i=0
	for i in range(len(s1)):
		for j in range(len(s2)):
			c=s1[i]
			while s2.find(c)!=-1:
				count=count+1
				return count

#printstatement
print("No. of matching characters are "+ str(count_matchingChars("aacdddeklll2@","bb221111@k55")))










#function_2
def valid_password(s3):
	if(len(s3)>=8):
		count_1=0
		count_2=0
		count_3=0
		count_4=0
		for i in s3:
			if (ord(i)>=65 and ord(i)<=90):
				count_1+=1
			elif (ord(i)>=48 and ord(i)<=57):
				count_2+=1
			elif (i=='_' or i=='@' or i=='$'):
				count_3+=1
			elif(ord(i)>=97 and ord(i)<=122):
				count_4+=1

		if(count_1>=1 and count_2>=1 and count_3>=1 and ((count_1 +count_2+count_3+count_4)==len(s3))):
			return True
		else:
			return False

	else:
		return False


#print output
print("function_2 returns "+str(valid_password("ASDF12@23")))
print("function_2 returns "+str(valid_password("cope1234")))
print("function_2 returns "+str(valid_password("aaac1@SD")))
