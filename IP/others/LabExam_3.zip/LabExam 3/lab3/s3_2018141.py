def count_matchingchars(s1,s2):

	s1=s1.lower()
	s2=s2.lower()
	n=len(s1)
	count=0
	for a  in range(0,n):
		b=s1[a]
		
		if s2.count(b)!=0:
			count= count+1
		
	return count



