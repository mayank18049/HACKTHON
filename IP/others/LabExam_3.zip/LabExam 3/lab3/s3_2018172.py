def count_matchingChars(s1,s2):
	s1 = s1.upper()
	s2 = s2.upper()
	c = 0
	for x in s1:
		m = x
		if s2.find(x) >= 0:
				
				m1 = s2.find(x)
				
				if m != m1:
					c = c+1

				

	return c





def valid_password(s3):
	a1 = 0
	a2 = 0
	a3 = 0

	if len(s3)>=8:
		if s3 != s3[::-1]:
			for x in s3:
				if x == '_' or x == '@' or x == '$':
					a1 == 1


				if ((x>='a' and x<='z') and (x>='A' and x<='Z')):
					a2 == 1


				if (x >= '0' and x <= '9'):
					a3 == 1

			if (a1 == 1 and a2 == 1 and a3 == 1):
				return True
		else:
			return False
	else:
		return False		

print(str(count_matchingChars("aabcdddek1112@","bb221111@k55")))
print("Pasword check returns value" + str(valid_password("aaac1@SD")))
