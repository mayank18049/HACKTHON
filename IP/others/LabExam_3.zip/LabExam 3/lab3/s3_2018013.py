''' NAME       =  AMAN CHAUDHARY
    ROLL NO.   =  2018013
    GROUP      =  5 
    SECTION    =  A
    BRANCH     =  CSE'''
def count_matchingChars(s1,s2):
    count=0
    for i in range(len(s1)):
        
        for j in range(len(s2)):
            if i>0:
                if s1[i]!=s1[i-1]:
                    if s1[i]==s2[j]:
                       count+=1
                else:
                    count=count
            if i==0:
                if s1[i]==s2[j]:
                       count+=1
    return count
def valid_password(s3):
    if len(s3)>7:
        f1=True
    else:
        f1=False
    alpha='QWERTYUIOPASDFGHJKLZXCVBNM'
    number='0987654321'
    symbol='@$_'
    for i in range (26):
        if alpha[i] in s3:
            f3=True
            break
        
        else:
            f3=False
    for i in range (len(number)):
        if number[i] in s3:
            f4=True
        else:
            f4=False
    for i in range (len(s3)):
        if s3[i]=='@' or s3[i]=='$' or s3[i]=='_':
            f5=True
            break
        else:
            f5=False
    if len(s3)%2==0:
        for i in range (int(len(s3)/2)):
            if s3[i]!=s3[-1-i]:
                f6=True
            else:
                f6=False
    if len(s3)%2==1:
        for i in range (int(len(s3)/2)+1):
            if s3[i]==s3[-1-i]:
                f6=False
            else:
                f6=True
            
    
    return (f1 and f3 and f4 and f5 and f6)
    
     
         
