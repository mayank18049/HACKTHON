# Pratyusha Lakshmi Dronamraju
# 2018173
# A
# 5
# 23/09/2018

def valid_password(s3):
	l=len(s3)
	p=0;q=0;r=0;s=0
	for x in range(0,l):
		if s3[x]>="A" and s3[x]<="Z":
			p=1
			break
		else:
			p=0
	for x in range(0,l):
		if s3[x]>="0" or s3[x]<="9":
			q=1
			break
		else:
			q=0
	if s3.find("_")!=-1 or s3.find("@")!=-1 or s3.find("")!=-1:
		r=1
	else:
		r=0
	n=0
	while n<l:
		m=''
		t=l-1
		m=m+s3[t]
		t=t-1
		n=n+1
	if m==s3:
		s=0
	else:
		s=1

	if p==1 and q==1 and r==1 and s==1:
		return True
	else:
		return False

def count_matchingChars(s1,s2):
	s1.lower()
	s2.lower()
	c=0
	p=len(s1)
	q=len(s2)
	if p>q:
		r=1
	else:
		r=0
	if r==1:
		x=0
		while x<q:
			for y in range(0,p):
				if s2[x]==s1[y]:
					c=c+1
		x=x+1
	if r==0:
		x=0
		while x<p:
			for y in range(0,q):
				if s2[y]==s1[x]:
					c=c+1
		x=x+1
	return c

	print(c)
k=valid_password("aaac1@SD")
print("Password check returns value" + str(k))
print("No. of matching characters are " + str(count_matchingChars("abc","a")))




