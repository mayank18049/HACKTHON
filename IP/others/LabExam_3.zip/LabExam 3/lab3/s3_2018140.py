# Midterm Lab Exam Set-3 - 2018
# Name : Divyansh Kain
# Roll number : 2018140
# Section : A
# Group : 04
# Date : 23 sept 2018

def count_matchingChars(s1,s2):
	count=0
	s1=str(s1)
	s2=str(s2)
	x=int(len(s1))
	for i in s1:
		if i in s2:
			count=count+1
			return(count)
		else:
			return(0)
		i=i+1			

count_matchingChars('ssad','sad')
def valid_password(s3):
	if len(s3)>=8:
		for i in s3:
			if i.isalpha()  

	

