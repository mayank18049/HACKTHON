#Midterm Lab Exam Set 2-2018
#Name-Amandeep Kaur
#Roll no-2018014
#Section-A
#Group-6
#Date-23/09/2018

def count_matchingChars(s1,s2):
	helper_string=''
	s1=s1.lower()
	s2=s2.lower()
	for i in s1:
		if i in s2 and i not in helper_string:
			helper_string+=i
	return len(helper_string)
print("No. Of matching characters are "+str(count_matchingChars("aabcdddek1112@","bb221111@k55")))

# print(count_matchingChars("bbbbbbba","Abbb"))
# print(count_matchingChars("aabcdddek1112@","bb221111@k55"))
# print(count_matchingChars("abc","dfx"))

def palindrome(s):
	for i in s:
		if i==s[len(s)-1]:
			s=s[1:len(s)-2]
		return True


def valid_password(s3):
	count=0
	if len(s3)>=8:
		count+=1
	if palindrome(s3)==False:
		count+=1
	if '_' in s3 or '@' in s3 or '$' in s3:
		count+=1

	for i in s3:
		if i in '0123456789' or i in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ':
			if count<3:
				count+=1		


	if count==5:
		return True 
	else: 
		return False

print("Password check returns value "+str(valid_password("Aaa12@21aaA")))








