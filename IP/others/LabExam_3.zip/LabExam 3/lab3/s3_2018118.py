# midterm lab exam set 3- 2018
#name:vipul kesari
#roll no.:2018118
#section:A
#group:06
#Date : 23-09-2018

def count_matchingChars(s1,s2):
	l=len(s1)
	count=0
	for i in range(l):
		if(s2.find(s1[i],i+1,)):
			count+=1

	return (count)
def valid_password(s3):
	l=len(s3)
	i=1
	sz=l//2
	if(s3):
		for a in range(sz):
		    s3[a]==s3[sz-i]
		    i+=1
		p=-1
	else:
		p=1
	if (l>8):
	elif(p==-1):
	elif(s3.isalpha()):
	elif(s3.isupper()):
	elif(s3.isdigit()):
	elif(s3.find('_')or s3.find('@')or s3.find('$')):
		return('True')
	else:
		return ('False')
print ("No. of matching characters are "+ str(count_matchingChars("aabcddek1112@","bb221111@k55")))
print ("password check returns value"+str(valid_password("Aaa12@21aaA")))



