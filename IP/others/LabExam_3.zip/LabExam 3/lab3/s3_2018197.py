s3=input()
m="abcdefghijklmnopqrstuvwxyz"
n="0123456789"
b="_@$"
v="ABCDEFGHIJKLMNOPQRSTUVWXYZ"
for k in s3:
	if s3.find(m):
		print(True)



	
		

