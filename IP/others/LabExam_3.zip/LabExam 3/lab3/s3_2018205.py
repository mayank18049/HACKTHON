# Midterm Lab Exam Set 3 - 2018
# Name: Yashwin Agrawal
# Roll number : 2018205
# Section : A
# Group : 5
# Date : 23-09-2018


# Function1
def count_matchingChars(s1,s2):
	count = 0
	s = ""
	for i in s1:
		if s1.find(c) == -1:
			s = s + 1
		for c in s:
			if s2.find(c) == -1:
				continue
			count = count + 1
		return (count)







# Function2
def valid_password(s3):
	length = len(s3)
	t = 0
	s = 0
	r = 0
	u = 0
	z = 0
	if length >= 8 and s3[::-1] != s3:
		for i in s3:
			x1 = ord(i)
			if x1 >= 65 and x1<=90:
				t = t + 1
			elif x1 >= 48 and x1 <= 57:
				s = s + 1
			elif i == '_' or i == '@' or i == '$':
				r = r + 1
			elif x1 >= 97 and x1 <= 122:
				u = u + 1
			else :
				z = 1
	else:
		z = 1
	if t >= 1 and s>= 1 and r >= 1:
		return ("True")
	else:
		return ("False")
print ("Password check returns value " +str(valid_password("Aaa12@21aaA")))

		

