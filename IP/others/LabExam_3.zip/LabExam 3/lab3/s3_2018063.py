# Midterm Lab Exam Set 3 - 2018
# Name: Paritosh Shukla
# Roll Number: 2018063
# Section: A
# Group: 7
# Date: 23 September 2018


#function1
def count_matchingChars(s1,s2):
	new_s1=s1.upper()
	new_s2=s2.upper()
	matching=0
	l=len(new_s2)
	ascii_value=-1
	for k in range(l):
		c1=new_s2[k] in new_s1
		if c1 and ascii_value!=ord(new_s2[k]):
			matching=matching+1
			ascii_value=ord(new_s2[k])
	return matching





#function2
def valid_password(s3):
	length=len(s3)
	if length>=8:
		cond1= True
	else:
		cond1=False
	cond2= False
	for a in s3:
		alpha=ord(a)
		if 64<alpha<91:
			cond2=True or cond2
		else:
			cond2= False or cond2
	cond3= False
	for c in s3:
		number=ord(c)
		if 47<number<58:
			cond3=True or cond3
		else:
			cond3= False or cond3
	cond4= False
	for b in s3:
		char=ord(b)
		if char==95 or char==36 or char==64:
			cond4=True or cond4
		else:
			cond4=False or cond4
	cond5=True
	for d in s3:
		k=s3.find(d)
		if s3[k]==s3[length-k-1]:
			cond5=cond5 and True
		else:
			cond5=False
	can_be_password=cond1 and cond2 and cond3 and cond4 and (not(cond5))
	return can_be_password

	
			


		

