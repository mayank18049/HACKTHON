#function 1
def count_matchingChars(s1,s2):
	c=-1
	d=-1
	count=0
	for i in range(len(s1)):
		for j in range(len(s2)):
			if(s1[i]==s2[j]):
				k=i-1
				while(k>=0):
					if(s1[i]==s1[k]):
						c=0
						break
					k-=1
				k=j-1
				while(k>=0):
					if(s2[j]==s2[k]):
						d=0
						break
					k-=1
				if(c==-1 and d==-1):
					count+=1
			c=-1
			d=-1
	return count


#function 2
def valid_password(s3):
	flag1=0
	flag2=0
	flag3=0
	flag4=0
	for q in range(len(s3)):
		if 65<=ord(s3[q])<=90:
			flag1=1
		if(s3[q]=='_' or s3[q]=='@' or s3[q]=='$'):
			flag2=1
		if(48<=ord(s3[q])<=57):
			flag3=1
		if(s3[q]!=s3[len(s3)-q-1]):
				flag4=1
	if len(s3)>=8 and flag1==1 and flag2==1 and flag3==1 and flag4==1:
		return True
	else:
		return False