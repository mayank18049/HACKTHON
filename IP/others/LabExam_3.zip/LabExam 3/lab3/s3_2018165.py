#Midterm lab exam set 3- 2018
#Name=NISHANT MISHRA
#ROLL NUMBER=2018165
#SECTION=A
#GROUP=5
#DATE=23/09/2018


#Function2

def valid_password(s3):
     n=o
for for each n in s3:
        if (ord('n')>97 and ord('n')<122) and len(s3)>=8 and (ord('n')>65 and ord('n')<90)) and (ord('n')>=48 and ord('n')<=57) and n.isspecialcharecter():
             return True
        else:
             return False


#function1
def count_matchingchars(s1,s2):
    if len(s1)=len(s2):
        k=0
        for each c in (s1,s2):
         if c.in s1()=c.in s2():
          k=k+1
        return k
    else:
        return 0
            
        
             
