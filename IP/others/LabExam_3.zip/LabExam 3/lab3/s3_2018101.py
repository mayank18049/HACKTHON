#Midterm Lab Exam Set 3- 2018
#Shubham Mittal
#Roll Number- 2018101
#Section- A
#Group- 5
#Date- 23/09/2018



import string
def count_matchingChars(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	c=0
	for i in string.ascii_lowercase:
		if(s1.find(i)>=0 and s2.find(i)>=0):
			c=c+1
	for i in string.punctuation:
		if(s1.find(i)>=0 and s2.find(i)>=0):
			c=c+1
	for i in string.digits:
		if(s1.find(i)>=0 and s2.find(i)>=0):
			c=c+1
	return c
def valid_password(s3):
	c=0
	if(len(s3)>=8):
		c=c+1
	for i in string.ascii_uppercase:
		if(s3.find(i)>=0):
			c=c+1
			break
	for i in string.digits:
		if(s3.find(i)>=0):
			c=c+1
			break
	rev=s3[::-1]
	if(rev!=s3):
		c=c+1
	if(s3.find('_') or s3.find('@') or s3.find('$')):
		c=c+1
	return (c==5)