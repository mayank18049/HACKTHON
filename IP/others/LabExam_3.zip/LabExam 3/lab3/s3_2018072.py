#Midterm Lab Exam Set 3 - 2018
#Name: PRATHAM GUPTA
#Roll Number: 2018072
#Section: A 
#Group: 8
#Date: 23-09-2018

from string import *

def count_matchingChars(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	x=len(s2)
	i=0
	count=0
	name=''
	name=''
	for i in range(0,x):
		if s1.find(s2[i])!=-1:
			if name.find(s2[i])==-1:
				name= name+ s2[i]
				count+=1
	return count

def valid_password(s3):
	x=len(s3)
	flag=0
	for i in range(0,x/2):
		if s3[i]==s3[x-i-1]:
			flag=0
		else:
			flag=1
	if flag==1:
		ch=''
		for j in range(0,x):
			if s3[j] >='A' and s3[j]<='Z':
				ch='a'
				break
		if ch!='a':
			flag=0
		for j in range(0,x):
			if s3[j]>='0' and s3[j]<='9':
				ch='a'
				break
		if ch!='a':
				flag=0
		for k in range(0,x):
			if s3[i]=='_' or s3[i]=='@' or s3[i]=='$':
				ch='a'
				break
		if ch!='a':
				flag==0
		if x<8:
			flag=0
	if flag==1:
			return True
	else:
		return False

print("No. of matching characters are " + str(count_matchingChars("aabcdddek1112@","bb221111@k55")))
print("Password check returs value " + str(valid_password("Aaa12@21aaA")))


