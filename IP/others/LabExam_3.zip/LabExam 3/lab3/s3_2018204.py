def count_matchingChars(s1,s2):
	count=0
	s1=set(s1.lower())
	s2=set(s2.lower())
	count=0
	for i in s2
		if s2 in s1:
			count=count+1
		else:
			continue
		
	return count








def valid_password(s3):
	s3=input()
	x=0
	if len(s3)>8:
		for i in s3:
			if i<='z' and i>='a':
				x=x+1
			if x==1:
				if i<='Z' and i>='A':
					x=x+1
			if x==2:
				if i=='_' or i=='@' or i=='$':
					x=x+1
			if x==3:
				s3=int(s3)
				if s3>=0 and s3<=0:
					x=x+1
			if x==4:
				if s3[::-1]!=s3:
					x=x+1

	    return True
	else:
		return False
