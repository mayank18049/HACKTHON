# Midterm Lab Exam Set 3 - 2018
# Name: AYAAN KAKKAR
# Roll Number: 2018028
# Section: A
# Group: 4
# Date: 23/09/2018

#function1
def count_matchingChars(s1,s2):
	count=0
	s1=s1.lower()
	s2=s2.lower()
	for x in s2:
		if(s1.find(x)!=-1):
			count+=1
			s1=s1.replace(x,'')
	return count

#function2
def valid_password(s3):
	if(len(s3)<8):
		return False
	has_upperCase= False
	has_digit=False
	has_char=False
	temp=''
	for x in s3:
		if(x.isupper()):
			has_upperCase=True
		elif(x.isdigit()):
			has_digit=True
		elif(x=='_' or x=='@' or x=='$'):
			has_char=True
		temp=x+temp
	if(temp==s3):
		pal=True
	else:
		pal=False
	if (has_upperCase and has_digit and has_char and not pal):
		return True
	return False

