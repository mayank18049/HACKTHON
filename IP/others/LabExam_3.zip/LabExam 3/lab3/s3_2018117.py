""" NAME = VINAY
	SECTION = A
	ROLL NUMBER = 2018117
	GROUP = 5
	DATE = 23/09/2018
"""
#FUNCTION TO CHECK VALID PASSWORD
def valid_password(s3):
	def uppercase(s3):
		for i in s3:
			if 'A'<=i.alpha()<='Z':
				return True
			else:
				False
	def numeric(s3):
		for i in s3:
			if i.isnumeric()==True:
				return True
			else:
				return False
	def specialcase(s3):
		for i in s3:
			if i == '_' or i=='@'or i=='$':
				return True
			else:
				return False
	def palindrome(s3):
		s3reverse = s3[::-1]
		if s3 == s3reverse:
			return True
		else:
			return False

	if s3 >=8:
		if numeric(s3)==True:
			if palindrome(s3)==True:
				if specialcase(s3)==True:
						if uppercase(s3)==True:
							return True
						else:
							False


# Function to check count of matching characters
def count_matchingChars(s1,s2):
	s1 = s1.lower()
	s2 = s2.lower()
	s1 = set(s1)
	s2 = set(s2)
	if len(s1 in s2) != 0:
		return len(s1 in s2)
	else:
		return 0
#print("Password CHeck returns value"+str(valid_password("Aaa12@21aaA")))		
#print('No. of Matching characters are"+ str(count_matchingChars("aabcdddek112@","bbss1111@k55")))