

def count_matchingChars(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	n=0
	for a in s1:
		
		for b in s2:
			if a==b :
				n=n+1
				return n
			else:
				return 0
#s3=input("")
def valid_password(s3):
	s4 = '_' 
	s5 = '@'
	s6 = '$'
	y=len(s3)
	for x in s3:
		if s3[:y//2]!=s3[y//2+1:]:
			if len(s3)>=8 and x.isupper() and x.islower() and x.isdigit() and (x.iss4() or x.iss5() or x.iss6()):

				return True
			else:
				return False
print("No. of matching characters are"+str(count_matchingChars("aabcdddek1112@","bb221111@k55")))
print("Password check returns value "+str(valid_password("Aaa12@21aaA")))