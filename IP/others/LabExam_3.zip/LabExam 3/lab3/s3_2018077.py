"""def count_matchingChars(s1,s2):
	h=0
	for i in range(len(s1)):
		if s1[i] in s2:

			
	print(h)"""

"""def valid_passsword(s3):
	count=0
	listt=["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"]
	for x in s3:
		if len(s3)>=8:
			count=count+1
		elif x>="a" and x<="z":
			count=count+1
	print(count)
		
valid_passsword("abshfe02792hdj") 
"""
def valid_password(s3):
	h=0
	A="ABCDEFGHIJKLMNOPQRSTUVWXYZ"
	a="abcdefghijklmnopqrstuvwxyz"
	c="1234567890"
	b="!@#$%^&*_"
	if len(s3)>=8:
		h=h+1
	for e in s3:
		if e in a:
			h=h+1

	for x in s3:
		if x in A:
			h=h+1
	for w in s3:
		if w in c:
			h=h+1

	for r in s3:
		if r in b:
			h=h+1
	if s3[::-1]!=s3:
		h=h+1

	if h==6:
		return True

o=valid_password("Awfdesh") 
print(o)

