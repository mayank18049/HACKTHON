
#question 2
def vlid_password(s3)
	a=input("enter your passoword  ")
	b=len(a)
	i=0
	d=for i in range b:
		print(i)
		i=i+1
	if (b>=8)and(65<=ord(d)<=90)and(48<=ord(d)<=57)and(d==(_ or @ or $)):
		print(True)
	else:
		print(False)
	
	
