'''Name = Abhinesh prajapati
section=A
Group=5'''

def count_matchingChars(s1):
	p=0
	count=0
	a=str(s1)
	#b=str(s2)
	a=a.upper()
	#b=b.upper()
	c=len(a)
	#d=len(b)
	k=0
	for i in range(c):

		if a[k]==a[i] or i!=0:

			a=a.replace(a[i+1],'')
			k=k+1
			print(a)
			









	'''for i in range(c):
		
		for j in range(d):
			if a[i]==b[j]: 
				count=count+1
			
		
		
	return count'''

print (count_matchingChars('abaaaa'))


		

