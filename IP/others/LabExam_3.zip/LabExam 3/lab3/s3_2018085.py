def count_matchingChars(s1,s2):
	s1 = str(s1)
	s2 = str(s2)
	y1 = s1.lower()
	y2 = s2.lower()
	count = 0
	i = 0
	for c in y2:
		r = y2[i]
		if r in y1:
			count+=1
		i = i+1
	return count


def valid_password(s3):
	y = s3
	i = 0
	m = 0
	n = 0
	o = 0
	p = 0
	if len(y) >= 8:
		for c in y:
			r = y[i]
			if r in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ':
				m = m+1
			i = i+1


		for c in y:
			i = 0
			r1 = y[i]
			if r1 in 'abcdefghijklmnopqrstuvwxyz':
				n = n+1
			i = i+1

		for c in y:
			i = 0
			r2 = y[i]
			if r2.isdigit():
				p = p+1
			i = i+1


		if (m>0) and (n>0)and (p>0):
			return 'True'
		else:
			return "False"
	else:
		return "False"