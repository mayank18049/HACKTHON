#name: Tejas Dubhir
#roll number: 2018110
#setion A
#group 6



def count_matchingChars(s1,s2):
	k=0
	for x in s1:
		r = s1.count(x)
		
		for y in s2:
			if x == y:
				k = k+1


	return k



def valid_password(s3):
	k = 0
	n = 0
	m = 0
	z = 0
	if len(s3)>= 8:
		
		for x in s3:
			if ('A'<=x) and (x<='Z'):
				k = k+1
		for x in s3:
			if ('0'<=x) and (x<='9'):
				n=n+1
		for x in s3:
			if (x == '_') or (x == '@') or(x == '$'):
				m= m+1
		for x in s3:
			l = s3.find(x)
			if x == s3[len(s3) - l -1]:
				z = z+1

	if (k>=1) and (n>=1) and (m>=1) and (z != len(s3)):
		v = True
	else:
		v = False
	return v

print('no. of matching characters are' + str(count_matchingChars('aabcdddef1112@','bb221111@k55')))
print('Password check returns value' + str(valid_password('Aaa12@21aaA')))

