#Midterm Lab Exam Set 3- 2018	
#Name: Pabitra Bansal
#Roll Number: 2018060
#Section: A
#Group: 4
#Date: 23/09/2018
def count_matchingChars(s1,s2):
	count=0
	l1=len(s1)
	l2=len(s2)
	u=s1.capitalize()
	v=s2.capitalize()
	if(l1>=l2):
		for i in range(l1):
			if(v.find(u[i])>=0 and not(u.find(u[i])<i)):
				count+=1
	else:
		for i in range(l2):
			if(u.find(v[i])>=0 and not(v.find(v[i])<i)):
				count+=1
	return count



def valid_password(s3):
	upper=0
	digit=0
	special=0
	l=len(s3)
	if(l<8):
		return False
	else:
		for i in s3:
			if (i>='A' and i<='Z'):
				upper+=1

			if(i>='0' and i<='9'):
				digit+=1
			if(i=='_' or i=='@' or i=='$' ):
				special+=1
		le=0
		ri=l-1
		f=0
		while(le<ri and f==0):
			if(s3[le]!= s3[ri]):
				le+=1
				ri-=1
			else:
				f=1
		if(upper>0 and digit>0 and special>0 and f==0):
			return True
		else:
			return False

print("No. of matching characters are "+str(count_matchingChars("aabcdddek1112@","bb221111@k55")))			
print("Password check returns value "+str(valid_password("Aaa12@21aaA")))
			
