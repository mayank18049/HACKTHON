def count_matchingChars(s1,s2):
	s1=str(s1)
	s2=str(s2)
	s1=s1.lower()
	s2=s2.lower()
	count=0
	for k in s1:
		if s2.count(k)>0:
			count=count+1
		s2=s2.replace(k,'')
	return count
def ayush(a):
	a=str(a)
def ayush(a):
	for k in a:
	if k==a[-find(k) -1] 



def valid_password(s3):
	s3=str(s3)
	if len(s3)<8:
		return False
	for k in s3:
		alpha=0
		num=0
		sp=0
		if 'A'<=k<='z':
			alpha=alpha+1
		if '0'<=k:
			num=num+1
		if k=='_' or k=='@' or k=='$':
			sp=sp+1
	if alpha>0 and num>0 and sp>0:
		return True
	else: 
		return False

print("No.of matching characters are " +str(count_matchingChars("aabcdddek1112@","bb221111@k55")))
print("Password check return value " +str(valid_password("Aaa12@21aaA")))
