# Midterm Lab Exam Set 3 - 2018
# Name:anunay yadav
# Roll Number: 2018021
# Section:A
# Group:05
# Date:23/09/2018

def count_matchingChars(s1,s2):
	l = []
	s1=s1.lower()
	s2=s2.lower()
	count = 0
	for i in range(len(s1)):
		if s1[i] not in l and s2.find(s1[i])>=0:
			l.append(s1[i])
			count += 1
	return count

def valid_password(s3):
	flag_uppercheck = 0
	flag_digitcheck = 0
	flag_char = 0
	flag_palindrome = 0
	if s3!=s3[::-1]:
		flag_palindrome = 1
		if len(s3)>=8:
			for i in s3:
				if i.isupper():
					flag_uppercheck = 1
				if i.isdigit():
					flag_digitcheck = 1
				if i == '_' or i == '@' or i == '$':
					flag_char = 1
	if flag_palindrome == 1 and flag_digitcheck == 1 and flag_char == 1 and flag_uppercheck == 1:
		return True
	else:
		return False
	
print("No. of matching characters are " + str(count_matchingChars("aabcdddek1112@","bb221111@k55")))
print("Paassword check returns value " + str(valid_password("Aaa12@21aaA")))



