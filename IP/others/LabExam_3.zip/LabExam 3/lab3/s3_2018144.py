def count_matchingChars(s1,s2):
	count=0
	i=0
	for i in range(len(s1)):
		for j in range(len(s2)):
			c=s1[i]
			if s2.find(c)!=-1:
				if s2[j]!=s2[j-1]:
					count = count + 1
	return count


def valid_password(s3):
	count=0
	if len(s3)>=8:
		count=count+1
	for i in range(len(s3)):
		if s3[i].isupper():
			count=count+1
			break;
	for i in range(len(s3)):
		if s[i].isdigit():
			count=count+1
			break;
	for i in range(len(s3)):
		if s[i]=='_' or s[i]=='@' or s[i]=='$':
			count=count+1
			break;
	

	if count==5:
		return True
	else:
		return False
	
