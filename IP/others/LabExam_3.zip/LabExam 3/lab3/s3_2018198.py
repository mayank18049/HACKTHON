#Souvik Das
#Group 6
#Section A
#Roll 2018198
def count_matchingChars(s1,s2):
	x=len(s1)
	y=len(s2)
	count=0
	s1=s1.lower()
	s2=s2.lower()
	for a in range(x):
		for b in range(y):
			if s1[a]==s2[b]:
				if s1[a-1]!=s1[a]:
					count+=1
				break
	print (count)




def valid_password(s3):
	x=len(s3)
	q=int(x/2)
	r=1
	n=1
	e=1
	if x<8:
		return False
	else:
		i=0
		for i in range (x):
			if s3[i]>="A" and s3[i]<="Z":
				r=0
			elif s3[i]>="0" and s3[i]<="9":
				n=0
			elif s3[i]=='_' or s3[i]=='@' or s3[i]=='$':
				e=0
		if r==0 and n==0 and e==0:
			for u in range(q):
				if s3[i+u]!=s3[x-u]:
					return True
				else:
					return False
		else:
			return False
if __name__=='__main__':
	print("No. of matching characters are " + str(count_matchingChars("adfergh","fergbc")))
	print("Password check returns value " + str(valid_password("Aaa12@21aaA")))


		



