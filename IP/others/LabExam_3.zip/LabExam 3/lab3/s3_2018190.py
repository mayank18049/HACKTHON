#Midterm Lab Exam Set 3 - 2018
#Name : Setu Gupta
#Roll Number : 2018190
#Section : A
#Group : 6
#Date : 23/9/18
def count_matchingChars(s1, s2):
	count = 0
	s1 = s1.lower()
	s2 = s2.lower()
	for index in s1:
		if(s2.find(index) > -1):
			count = count + 1
			s2 = s2.replace(index, '')
	return count

def valid_password(s3):
	if len(s3) < 8:
		return False
	cap = False
	num = False
	schar = False
	pal = True
	for index in s3:
		if index.isupper():
			cap = True
		if index.isdigit():
			num = True
		if ((index == '_') or (index == '@') or (index == '$')):
			schar = True
	for index in range(len(s3)//2):
		if	s3[index] != s3[len(s3) - 1 - index]:
			pal = False
	return cap and num and schar and not pal

print("No. of matching character are " + str(count_matchingChars("aabcdddek1112@", "bb221111@k55")))
print("Password check returns value " + str(valid_password("Aaa12@21aaA")))