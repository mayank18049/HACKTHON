#Midterm lab exam set 3
#MADHAV
#2018046
#a
#6
def count_matchingChars(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	lis=[s1[0]]
	length=len(s1)
	count=0
	if len(s1)>len(s2):
		s1 = temp
		s1= s2
		s2=temp

	for l in range(length):
		if l<len(s1) and s1[l] in s1[l:]:
			s1=s1.replace(s1[l],'')+s1[l]
			print(s1)
	
	'''for i in range(len(s1)):
		if s1[i]!=s1[i+1]:
			lis.append(s1[i+1])
	print (lis)'''

	length=len(s2)
	for l in range(length):
		if l<len(s2) and s2[l] in s2[l:]:
			s2=s2.replace(s2[l],'')+s2[l]
	for i in s2:
		if i in s1:
			count=count+1

	

count_matchingChars("hdwgdgf","h")
def valid_password(s3):
	if len(s3)>8 and ('_' in s3 or "@" in s3 or '$' in s3):
		

print ("No. of matching characters are "+str(count_matchingChars("aabcdddek","bb22111@k55")))
print ("passsword check returns false")