#Midterm lab Exam Set 3 - 2018
#Name:Rohan Agarwal
#Roll Number:2018181
#Section:A
#Group:5
#Date:23-09-2018


def count_matchingChars(s1,s2):
	
	s=str(s1)
	q=str(s2)
	r=len(s1)
	o=len(s2)
	c=0

	for i in s1:
		if i in s2:
			c=c+1
			

	
	
	return c


#z=count_matchingChars("abce","bcdhe")
#print(z)


def valid_password(s3):
	from string import ascii_letters,digits,punctuation
	b=False
	c=False
	d=False
	e=False
	f=False


	a=str(s3)
	r=len(s3)
	if len(a)>=8:
		b=True

	for i in range(r):
		if a[i]>='a' and a[i]<='z'or a[i]>='A' and a[i]<='Z':
			c=True
		

	m=ascii_letters
	if m in a:
		d=True
	

	p=digits
	if p in a:
		e=True


	q=punctuation
	if q in a:
		f=True

	if b and c and d and e and f:
		return True

	else:
		return False

#z=valid_password("ASDF12@23")
#print(z)





