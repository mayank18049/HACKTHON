#Midterm lab exam set 3- 2018
#Name: siddhant yadav
#Roll number: 2018196
#section: A
#group: 4
#date: 23sep 2018

def count_matchingChars(s1,s2):
    k=0
    for ch in 'qwertyuioplkjhfdsazxcvbnm1234567890!@#$%^&*()_+':
        for i in s1:
            if i==ch:
                break
        for j in s1:
            if j==i:
                k=k+1
    return k
        
        


def valid_password(s3):
    n=0
    k=0
    m=0
    j=0
    s4=''
    if len(s3)>=8:
        n=1
    if n==1:
        for ch in s3:
            if ch.isupper():
                k=k+1
        if k>=1:
            n=1
        else:
            n=0
    
    if n==1:
        for ch in s3:
            if ch.isdigit():
                j=j+1
        if j>=1:
            n=1
        else:
            n=0
    if n==1:
        for ch in s3:
            if ch=='_' or ch=='@' or ch=='$':
                m=m+1
        if m>=1:
            n=1
        else:
            n=0
    if n==1:
        for ch in s3:
            s4=ch+s4
        if s4==s3:
            n=0
        else:
            n=1
    if n==1:
        return True
    else:
        return False
                
        
        
    
