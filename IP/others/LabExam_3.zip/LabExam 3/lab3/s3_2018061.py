# Midterm Lab Exam Set 3 - 2018
# Name : Pankil Kalra
# Roll No: 2018061
# Section: A
# Group: 5
# Date: 23/09/2018
def count_matchingChars(s1,s2):
	count=0
	p1=''
	p2=''
	p3=''
	m=int(len(s1))
	n=int(len(s2))
	for c in range(m):
		if s1[c].islower():
			p1=p1+s1[c].upper()
		else:
			p1=p1+s1[c]			
	for c in range(n):
		if s2[c].islower():
			p2=p2+s2[c].upper()
		else:
			p2=p2+s2[c]		
	for c in p1:
		if p3.find(c)==-1:
			p3=p3+c
	for c in p3:
		if p2.find(c)==-1:
			continue
		count=count+1
	return count
def valid_password(s3):
	countu=0
	countd=0
	counto=0
	rev=''
	if len(s3)<8:
		return False
	for c in s3:
		if c.isupper():
			countu=countu+1	
		if c.isdigit():	
			countd=countd+1
		if c=='_' or c=='@' or c=='$':
			counto=counto+1			
	if countu==0 or countd==0 or counto==0:
		return False
	for c in s3:
		rev=c+rev
	if(s3==rev):
		return False
	return True	



