#Midterm Lab Exam Set 3 - 2018
#Name : Dhruv Diwan
#Roll Number : 2018031
#Section : A
# Group : 7
# Date : 23/09/18


#function1
def count_matchingChars(s1,s2):
		s1=s1.lower()
		s2=s2.lower()		
		n=0 # number of matches		
		s=''
		i=0
		while i<len(s1):
			c=s1[i]
			if c not in s : # i.e if c hasn't been checked already
				j=0
				while j<len(s2):
					S=''					
					if s2[j]==c and s2[j] not in S:
						n+=1
						S=S+c
						break
					else:
						j+=1
				s=s+c
			i+=1 
		return n
			
#function2
def valid_password(s3):
	n=0 # number of conditions satisfied
	if len(s3)>7:
		n+=1
	x=0
	while x<len(s3):
		if s3[x].isupper()==True:
			n+=1			
			break 
		else:
			x+=1
	x=0
	 
	while x<len(s3):
		if s3[x].isdigit()!=-1:
			n+=1
			break
		else:
			x+=1
	x=0
	
	while x<len(s3):
		if s3[x]=='_' or s3[x]=='@' or s3[x]=='$':
			n+=1
			break
		else:
			x+=1 
	x=0 
	
	if s3 != s3[-1:-len(s3)-1:-1]:
		n+=1
	
	if n==5:
		return True
	else:
		return False



print('Number of matching characers are '+ str(count_matchingChars('aabcdddek11112@','bb221111@k55')))
print('Password check returns value '+ str(valid_password('Aaa12@21aaA')))

	

