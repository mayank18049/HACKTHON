#Name     : Mohnish Agrawal
#Roll no. : 2018053
#Section  : A
#Group no.: 5
#Date     : 23rd September 2018

#function1
def count_matchingChars(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	str1=s1[0]
	count=0
	for i in range(len(s1)):
		if(s1[i] not in str1):
			str1=str1+s1[i]
	for i in range(len(str1)):
		if str1[i] in s2:
			count+=1
	return count

#function2
def valid_password(s3):
	if(len(s3)>7):
		val=""
		val2=""
		val3=""
		val4=""
		for i in range(len(s3)):
			if (ord(s3[i])>64 and ord(s3[i])<91):
				val="True"
		if(val!="True"):
			return False
		for f in range(len(s3)):
			str2=s3[f]
			if (str2.isdigit()):
				val2="True"
		if(val2!="True"):
			return False
		for c in range(len(s3)):
			if (s3[c]=="_" or s3[c]=="@" or s3[c]=="$"):
				val3="True"
		if(val3!="True"):
			return False
		for d in range(len(s3)):
			val4=s3[d]+val4
		if(val4==s3):
			return False
		return True
	else:
		return False

#print output
print("No. Of matching characters are "+str(count_matchingChars("aabcdddek1112@","bb221111@k55")))
print("Password check returns value "+str(valid_password("Aaa12@21aaA")))


