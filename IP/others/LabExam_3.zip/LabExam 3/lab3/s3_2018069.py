def count_matchingChars(s1,s2)
	v=s1.casefold()
	x=s2.casefold()
	
	





def valid_password(s3)
	a=s3
	x=len(a)
	if (x>=8):
		for i in range(x):
			if(a[i]>='A' and a[i]<='Z'):
				if(a[i]>='0' and a[i]<='9'):
					if(a[i]=='_' or a[i]=='@' or a[i]=='$'):
						return (True)
						break
	else:
		return (False)
