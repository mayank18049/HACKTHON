#Midterm Lab Exam Set 3 - 2018
#Name:Rajat Prakash
#Roll Number:2018078
#section:A
#Group:6
#Date:23-09-2018

#function1
count=int(0)
def count_matchingChars(s1,s2):
    for k in s1:
        for l in s2:
            if k==l:
                new=new+l
    for a in new:
        count=count+1
        b=new[:count+1] + new[count+2:]
    for cas in b:
        if cas==a:
            v=v+1
    return(v,"are matches")





