'''
Midterm lab exam set 3 - 2018
Name : Parth Chopra
Roll Number : 2018064
Section : A
Group : 8
Date = 23/09/2018
'''

# function 1
def count_matchingChars(s1,s2):
	s = ''
	s1 = s1.lower()
	s2 = s2.lower()
	for j in s2:
		if (j in s1) and not(j in s):
			s = s + j

	return len(s)


# function 2
def valid_password(s3):
	truth_counter = 0
	reverse_string = ''
	c1 = 0
	c3 = 0
	c4 = 0
	c5 = 0
	c6 = 0
	if len(s3) >= 8 :
		c1 = 1
	for x in s3:
		if x.isupper():
			c3 += 1
		if x.isdigit():
			c4 += 1
		if x == '_' or x == '@' or x == '$' :
			c5 += 1
		reverse_string = x + reverse_string

	if s3 != reverse_string:
		c6 += 1
	if c1 > 0 and c3 > 0 and c4 > 0 and c5 > 0 and c6 > 0 :
		return True
	else: 
		return False

