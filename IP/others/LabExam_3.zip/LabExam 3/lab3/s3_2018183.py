#Midterm Lab Exam Set 3 - 2018
#Name:Rounak Saraf
#Roll Number:2018183
#Section:A
#Group:7
#Date:23/09/18

#function1
def count_matchingChars(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	match=0
	i=0
	#print(s1)
	#print(s2)  
	for i in len[s1]:
		if s2.find(s1[i]>=0):
			a=s2.find(s1[i])
			if ((s2.find(s1[i],a)>=0) or (s2.find(s2.find(s1[i],0,a)>=0))):
				i=i+1
			else:
				match=match+1
		b=s1.find(s1[i])	
		if(s1.find(s1[i],b>=0) or s1.find(s1[i],0,b)>=0):	
			i=i+1
	return(match)

#function2
def valid_password(s3):
	i=0
	j=0
	k=int(len(s3-1))
	flag=1
	for i in int(len(s3)):
		if(s3[i]>=0 and s3[i]<=9):
			flag=1
		else:
			flag=0
		if ((s3[i]>=a and s3[i]<=z) and (s3[i]>=A and s3[i]<=Z)):
			flag=1
		else: 
			flag=0
		if(len(s3)>=8):
			flag=1
		else: 
			flag=0
		if(s3[i]=='_' or s3[i]=='@' or s3[i]=='$'):				
			flag=1
		else:
			flag=0
		for j in range(int(len[s3]/2)):
			for k in range(int(len[s3]),int(int(len[s3])-1)):
				if (s3[i]==s3[j]):
					flag=1
				else:
					flag=0
				k=k-1	
	if flag==1:
		return('True')
	else:
		return('False')	

print("Number of matching characters are "+str(count_matchingChars("aabcdddek1112@","bb221111@k55")))
print("Password check returns value"+str(valid_password("Aaa12@21aaA")))						

