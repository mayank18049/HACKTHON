def count_matchingChars(s1,s2):
	s1=s1.upper()
	s2=s2.upper()
	count=0
	for i in range(0,len(s1)):
		if s1[i]!=s1[i-1]:

			for j in range(0,len(s2)):
				if s2[j]!=s2[j-1]:
					if s1[i]==s2[j]:
						count=count+1

	return(count)

#p=count_matchingChars("aabcdddek1112@","bb221111@k55")
#print(p)

def valid_password(s3):
	l=len(s3)
	flupper=0
	fldigit=0
	flspecial=0
	flpalin=0
	count=0
	if l%2==0:
		for i in range(0,int(l/2)):
			if s3[i]==s3[l-1-i]:
				count=count+1
		if count==int(l/2):
			flpalin=1
		else:
			flpalin=0
	else:
		for i in range(0,int(l/2)):
			if s3[i]==s3[l-1-i]:
				count=count+1
		if count==int(l/2):
			flpalin=1
		else:
			flpalin=0	
			
				

	if l>=8:
		for i in range(0,l):
			if 'A'<=s3[i] and s3[i]<='Z':
				flupper=flupper+1
			elif s3[i]>='0' and s3[i]<='9':
				fldigit=fldigit+1
			elif s3[i]=='_'	or s3[i]=="@" or s3[i]=="$":
				flspecial=flspecial+1
	if (l>=8) and (flupper>=1 and flupper<=(l-3)) and (flpalin==0) and (fldigit>=1 and fldigit<=(l-3)) and (flspecial>=1 and flspecial<=(l-3)):

		return(True)
	else:
		return(False)
#a=valid_password("Aaa12@21aaA")
#print(a)

				





