# Midterm Lab Exam Set 3 -  2018
# Name: ADITYA MEHRA
# Section: A
# Group: 6
# Date : 23/09/2018

function1
def count_matchingChars(s1,s2):
	a = len(s1)
	b = len(s2)


#function2
def valid_password(s3):
	l = len(s3)
	for i in range (0,l)
		if s3[i].isupper:
			b = True 
		else: 
			b = False
		if s3[i].find('@') >= 0 or s3[i].find('_') >= 0 or s3[i].find('$') >= 0:
			c = True
		else:
			c= False
		if s3[i].isdigit:
			d = True
		else:
			d = False
		if l >= 8 and b and c and 
			return True
		else :
			return False


		