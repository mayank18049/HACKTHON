"""
Midterm Lab Exam Set 3 - 2018
Name : Aditya Saini
Roll Number : 2018125
Branch : ECE
Section : A
Group : 5
Date : 23.09.2018
"""
import string
#function1

def check_matchingChars(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	i=0
	j=0
	count=0
	x=s1[i]
	y=s2[j]
	while(True):
		
		if s1[i]==s2[j]:
			count=count+1

		i=i+1
		j=j+1

		elif s1[i]!=s2[j]:
			x=s1[i]
			y=s2[j]

		if i>=len(s1) or j >=len(s2):
			return count


#function2
def palin(string):
	i=0
	j=len(string)-1
	while(True):
		if i == j :
			return True
		if string[i] != string[j]:
			return False

		i=i+1
		j=j-1

def valid_password(s3):
	s3=str(s3)

	if len(s3) >= 8:
		flag1 = True
    
	for char in s3:
		if 'a' <= char <= 'z' :
			flag2 = True

	for char in s3:
 		if 'A' <= char <= 'Z' :
 			flag3 = True
 			break


	for char in s3:
 		if char == '_' or char == '@' or char == '$':
 			flag5=True
 			break

	for char in s3:
		if char.isdigit() == True:
			flag4 = True
			break

	if palin(s3) == False:
		flag6 = True
	
	return (flag1) and (flag2) and (flag3) and (flag4) and (flag5) and (flag6)

print(valid_password("cope1234"))
   


 