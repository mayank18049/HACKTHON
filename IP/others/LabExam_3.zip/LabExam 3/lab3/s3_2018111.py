#Midterm Lab Exam Set 3 - 2018
#Name:Uday Gupta
#Roll Number:2018111
#Section:A
#Group:7
#Date:23/09/18

#function1

def count_matchingChars(s1,s2):
	S1=s1.lower()
	S2=s2.lower()
	count=0
	x=0

	for c in S1:
		if((c in S2)and (not(c in S1[:x]))):
			count=count+1

		x=x+1

	return count


#function2

def valid_password(s3):
	v1=False
	v2=False
	v3=False
	v4=False
	v5=True
	
	l=len(s3)

	if(l>=8):
		v1=True

	for c in s3:
		if(c.isupper()):
			v2=True
			break

	for d in s3:
		if(d.isdigit()):
			v3=True
			break


	for e in s3:
		if((e=='_')or(e=='@')or(e=='$')):
			v4=True
			break

	s4=s3[-1::-1]
	if(s3==s4):
		v5=False

	if(v1 and v2 and v3 and v4 and v5):
		return True

	else:
		return False


#print output

print("No. of matching characters are "+str(count_matchingChars("aabcdddek1112@","bb221111@k55")))
print("Password check returns value " + str(valid_password("Aaa12@21aaA")))