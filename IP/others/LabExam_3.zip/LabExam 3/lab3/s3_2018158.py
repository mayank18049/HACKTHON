# Midterm Lab Exam set 3 - 2018
# name : mohd huzaifa
# Roll number: 2018158
# section: A
# Group: 6
# Date :23-09-2018
def count_matchingChars(s1,s2):
	count=0
	s1=s1.lower()
	s2=s2.lower()
	for a in s1:
		if(s2.find(a)!=-1):
			count+=1
			s2=s2.replace(a,'')
	return count
#print(count_matchingChars("aabcddek1112@@@@@@","34abffhd@"))
def valid_password(s3):
	k=m=n=j=l=0
	if(len(s3)>=8):
		k=1
	for a in s3:
		if(a.isupper()==True):
			m=1
		if(a.isdigit()==True):
			n=1
		if(a=="_" or a=="@" or a=="$"):
			j=1
	if(s3!=s3[::-1]):
		l=1
	if(l*j*n*m*k==1):
		return True
	else:
		return False
#print(valid_password("Ab12cd@hkjhjkh"))
print("No of matching characters are "+str(count_matchingChars("aabcdddek1112@","bb221111@k55")))
print("Password check returns value " +str(valid_password("Aaa12@21aaA")))
