#midterm lab exam set 3-2018
#name= mukul kumar rajak
#roll no.=2018054
#section=a
#group=6
#date=23/09/2018


def count_matchingChars(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	count=0
	for i in range(len(s1)):
		for j in range(len(s2)):
			if(s1[i]==s2[j]):
				count+=1
				break
	for i in range(len(s1)):
		for j in range(i+1,len(s1)):
			if(s1[i]==s1[j]):
				for d in range(len(s2)):
					if(s1[i]==s2[d]):
						count-=1
						break
			break



	return count
def valid_password(s3):
	b=False
	u=False
	d=False
	c=False
	if(len(s3)>=8):
		b=True
	for i in s3:
		if(i.isupper()):
			u=True
		elif(i.isdigit()):
			d=True
		elif((i=='_')or (i=='@') or (i=='$')):
			c=True
	if(s3[0]==s3[-1]):
		return False
	if(b and u and d and c):
		return True
	else:
		return False

print("No. of matching strings are "+str(count_matchingChars("aabcddek1112@","bb221111@k55")))
print("Password check returns value "+ str(valid_password("Aaa12@21aaA")))

