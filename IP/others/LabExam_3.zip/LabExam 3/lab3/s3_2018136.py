#Midterm Lab Exam Set 3- 2018
#Name: Chavisha Arora
#Roll number: 2018136
#section : A
#Group: 8
#Date: 23/09/2018

#function1

from string import *
def count_matchingChars(s1,s2):
	s2=s2.lower()
	s1=s1.lower()
	s2=list(s2)
	s1=list(s1)
	for x in s2:
		y=s1.count(x)
		y=y+1
		return (y)
	else:
		return(0)
	

#print(count_matchingChars("abcdeft","sdddgfhn"))

#function2
def valid_password(s3):
	y=len(s3)
 	z=s3[::-1]
 	for x in s3:
 		if x.isalpha()==True and (y>=8):
 			return("true")
 		else:
 			return("false")
	for x in s3:
 		if x.isupper()==True and z!=3:
 			return ("true")
 		else:
 			return ("false")
 	for x in s3:
 		if x.isdigit()==True:
 			return ("true")
 		else:
 			return ("false")
 	for x in s3:
 		if x=='_' or x=='@' or x=='$':
 			return ("true")
 		else:
 			return("false")				

print(valid_password("abc124A@"))

 	