def count_matchingChars(s1,s2):
	s1 = s1.lower()
	s2 = s2.lower()
	n = 0
	for c in s1:
		if c in s2:
			n=n+1
		s2 = s2.replace(c,'')
	if n == 0:
		return 0
	else:
		return n

def valid_password(s3):
	uc = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
	dg = '1234567890'
	sc = '_@$'
	lc = 'abcdefghijklmnopqrstuvwxyz'
	n = 0
	for c in s3:
		if c in uc:
			for x in s3:
				if x in dg:
					for y in s3:
						if y in sc:
							t = ''
							for a in s3:
								t = a+t
							if t != s3:
								return 1					
		else:
			return 0					