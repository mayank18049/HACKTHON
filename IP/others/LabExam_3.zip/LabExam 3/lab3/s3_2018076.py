#Midterm Lab Exam Set 3 - 2018
#Name: Raghav Gupta
#Roll Number: 2018076
#Section: A
#Group: 4
#Date: 23/09/18


#function1
def count_matchingChars(s1, s2):
	s1 = s1.lower()
	s2 = s2.lower()

	#Removing Duplicates
	t1 =""
	t2 =""
	for i in range(len(s1)):
		if t1.find(s1[i]) == -1:
			t1 = t1 + s1[i]

	for i in range(len(s2)):
		if t2.find(s2[i]) == -1:
			t2 = t2 + s2[i]

	match = 0

	for i in range(len(t1)):
		if t2.find(t1[i]) != -1:
			match +=1
	return match


#function2
def valid_password(s3):
	if(len(s3)<8):
		return False

	UpperCase = False
	Number = False
	Special = False

	for i in range(len(s3)):
		if 'A' <= s3[i] <= 'Z':
			UpperCase = True
		elif '0' <= s3[i] <= '9':
			Number = True
		elif s3[i] == '_' or s3[i] == '@' or s3[i] == '$':
			Special = True

	if(not UpperCase or not Number or not Special):
		return False

	start = 0
	end = len(s3)-1
	isPal = True

	while start < end:
		if s3[start] != s3[end]:
			isPal = False
		start +=1
		end -=1

	if(isPal):
		return False

	return True

print("No. of matching characters are " + str(count_matchingChars("aabcdddekl112@","bb221111@k55")))
print("Password check returns value " + str(valid_password("Aaa12@21aaA")))