# Midterm Lab Exam Set 3 - 2018
# Name : Divyam Gupta
# Roll Number : 2018032
# Section : A
# Group : 8

def count_matchingChars(s1,s2):
	## converting to lowercase as comparison is case- insensitive
	s1 = s1.lower()
	s2 = s2.lower()

	## Removing all repeated characters from the strings for comparison
	for i in s1:
		if s1.count(i) > 1:
			s1 = s1.replace(i, '', s1.count(i)-1)
	for i in s2:
		if s2.count(i) > 1:
			s2 = s2.replace(i, '', s2.count(i)-1)

	count = 0 ## dummy count variable

	# comparing strings for number of matching characters
	for i in s1:
		for j in s2:
			if i==j:
				count += 1
	
	return count

def valid_password(s3):
	## condition  #1
	if len(s3) < 8:
		return False

	## condition #6
	if s3[::-1] == s3:
		return False

	## condition #3
	count = 0
	for i in s3:
		if i.isupper():
			count+=1
	if count == 0:
		 return False

	## condition #4
	count = 0
	for i in s3:
		if i.isdigit():
			count+=1
	if count == 0:
		return False

	## condition #5
	count = 0
	for i in s3:
		if i == '_' or i == '@' or i == '$':
			count+=1
	if count == 0:
		return False

	return True