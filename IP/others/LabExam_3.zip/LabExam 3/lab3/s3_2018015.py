# name: amit maurya
# roll number:2018015
#section:a
#group:7
#date:23/09/2018


def count_matchingChars(s1,s2):
      
    a=s2[0]

    if(a.islower()):
        t=char(ord(a)-32)

    elif(a.isupper()):
        t=char(ord(a)+32)


    k=s2[1:]
    i=0

    for x in k:
        
        if(!((x==t) or (x==a[i]))): 	
            
            a=a+x

    for q in range(0,len(a)-1):
        
        c=0 
    	count=0
    	if(a[c].find(s1)>=0):
            
            count+=1
        c+=1

    return(count)     

















def valid_password(s3):
	if(len(s3)==8):
		uppercount=0
        digitcount=0
		somespec=0
        palidrom=0

		for x in s3:
			if(x.isalpha()):
				if(x>=ord("A")) and(x<=ord("Z")):
					uppercount+=1
		

			elif(x.isdigit()):
                digitcount+=1
            
            if(!(x>=ord('a') and x<=ord('z') ) or (x>=ord('A') and x<=ord('Z')) or (x>="0" and x<="9") or (x=='_' or x=='@' or x=="$")):
                return(False) 

        if(("_" in a) or ("@" in a) or ("$" in a)):
            somespec+=1 

    
    k=s3[::-1]

        if(k==s3):
        	palindrom=1


        if(palindrom==0 and uppercount>=1 and digitcount>=1 and somespec>=1):
        	return(True)

    else:
    	return(False)



 if('__name__'=='__main__'):

 	print("no. f characters matched:")
 	print(count_matchingChars("aabcdddek1112@","bb22111@k55"))

 	print("the password check return:",valid_password('Aaa12@21aaA'))