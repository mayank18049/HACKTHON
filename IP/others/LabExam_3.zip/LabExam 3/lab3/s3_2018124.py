#Aditya garg
#2018124
#Section-A
#Group-4

def count_matchingChars(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	count=0
	for i in s2:
		if(s1.count(i)>0):
			s1=s1.replace(i,'')
			count=count+1
	return count


def valid_password(s3):
	count=0
	a=len(s3)
	count2=0
	if(len(s3)>=8):
		z=s3.lower()
		if(z==s3):
			return False
		for i in s3:
			if(i.isdigit()==True):
				count=count+1
		if(count<1):
			return False
		for j in s3:
			if(j=='_' or j=='@' or j=='$'):
				count2=count2+1
		if(count2<1):
			return False
		if(s3==s3[::-1]):
			return False
		return True
	else:
		return False






































