# midterm lab exam set 3 - 2018
# Priyanshu
# 2018175
# A
# 7
# 23.09.2018


# function 1
def count_matchingChars(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	y=0
	for c in s2:
		z=s2.rfind(c)
		s3= s2[:z]
		if s1.find(c)>=0 and s3.find(c)<=0:
			y=y+1
		
	return y
	

count_matchingChars("bbbbba","Abbb")

#function 2
def valid_password(s3):
	y=len(s3)
	c=0
	for d in s3:
		if d.isdigit():
			c=c+1
	a=0
	for d in s3:
		if (d=="_"):
			a=a+1
		elif d=="@":
			a=a+1
		elif d=="$":
			a=a+1
	t=0
	if s3[::1]==s3[::-1]:
		t=1
	for s in s3:
		if ord(s)>=65 and ord(s)<=90:
			b=0
	for x in s3:
		if c>0 and y>=8 and a>0  and t!=1 and b==0:
			o="True"
		else:
			o="False"
	
	return o


print("no. of matching characters are: "+ str(count_matchingChars("aabcdddek1112@","bb221111@k55")))
print("passsword check returns value: "+ str(valid_password("Aaa12@21aaA")))



