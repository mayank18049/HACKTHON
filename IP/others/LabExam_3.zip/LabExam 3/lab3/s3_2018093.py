# Sandeep Sharma
#2018093
# A
# 5
# 23.09.18
def count_matchingChars(s1,s2):
	a=s1.lower()
	b=s2.lower()
	n=0
	c=len(a)
	d=len(b)
	i = ""
	if (c<d):
	    for k in a:
		    if ((b.find(k)!=-1) and (i!=k)):
			    n=n+1
			    i=k
		    else:
			    n=n
	else:
		a,b=b,a
		for k in a:
		    if ((b.find(k)!=-1) and (i!=k)):
			    n=n+1
			    i=k
		    else:
			    n=n
	return n

print(count_matchingChars('bbbbbbbba','Abbbb'))
print(count_matchingChars('aabcdddek1112@','bb221111@k55'))
print(count_matchingChars('abc','defx'))


# Sandeep Sharma
#2018093
# A
# 5
# 23.09.18
def valid_password(s3):
	a=len(s3)
	n=0
	s=0
	t=0
	u=0
	q=0
	for k in range(s3):

		if (k.isdigit()):
			n=n+1
		elif (97<=ord(k)<=122):
			s=s+1
		elif (65<=ord(k)<=90):
			t=t+1
		elif (((ord(k)==95) or (ord(k)==64)) or (ord(k)==36)):

			u=u+1
		elif (((a[0]==a[-1]) and (a[1]==a[-2])) and (((a[2]==a[-3]) and (a[3]==a[-4])) and (a[4]==a[-5]))):

			q=q+1
		else:
		    v=""	

    if (((n>=1) and (a>=8)) and (((t>=1) and (u>=1)) and (q==0))):
    	    x = "True"
    else:
    	    x = "False"
    return x

print(valid_password("aaac1@SD"))
print(valid_password("ASDF12@23"))
print(valid_password("cope1234"))
print(valid_password("Aaa12@21aaA"))

