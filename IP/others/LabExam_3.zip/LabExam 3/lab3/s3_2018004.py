# Midterm Lab Exam Set 3 - 2018\
# Name: Abhinava Phukan
# Roll Number: 2018004
# Section: A
# Group: 4
# Date: 23-09-2018

#function1
def count_matchingChars(s1,s2):
    """ Returns the count of matching characters in s1,s2 considering the single count for the character which have duplicates in the strings. Computation is case-insensitive. If there is not even a single char matching returns 0.
    Exampls:
    1. count_matchingChars("bbbbbbba","Abbb") -> 2
    2.coutn_m
    """
    s1 = s1.lower()
    s2 = s2.lower()
    i=0
    tempx1 =''
    for x1 in s1:
        tempx1 =tempx1 + x1
        if x1 in s2:
            if tempx1.count(x1)==1:
                i=i+1
    return i
#function2
def valid_password(s3):
    n=len(s3)
    atup,dig,spec=0,0,0
    if n >=8:
        for x in s3: 
            if x.isupper():
                atup=atup+1
            elif x>='0' and x<='9':
                dig = dig+1
            elif not(x.isalnum()):
                spec = spec+1
        trev = s3[::-1]
        if trev == s3:
            return False
        elif (atup>0 and dig>0 and spec >0):
            return True
        else:
            return False
    else:
        return False

#print output
print("No. Of matching characters are "+ str(count_matchingChars("aabcdddek1112@","bb221111@k55")))
print("Password check returns value "+ str(valid_password("Aaa12@21aaA")))
