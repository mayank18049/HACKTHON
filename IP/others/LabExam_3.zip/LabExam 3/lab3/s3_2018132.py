#Midterm Lab Exam Set 3 _ 2018
#Name        : Anushrut Shokeen
#Roll Number : 2018132
#Section     : A
#Group       : 4
#Date        : 23 September 2018
"""
def count_matchingChars(str1, str2):
	count=0
	i=0
	if len(str2)>len(str1):
		x=str2
		y=str1
	else:
	    x=str1
	    y=str2
	for i in range(len(x)):
		char=x[i]
		if y.find(x[i])!=-1:
			count=count+1
			i=i+1	
	print(count)

count_matchingChars("bbbba","Ab")	
"""


def valid_password(s3):
	if len(s3)<8:
		return False
	else:
		x= False
		for i in range(len(s3)):
			if s3[i]>='A' and s3[i]<='Z':
				x= x or True
			else:
			    x= x or False
			i=i+1    
			
		y=False		
		for j in range(len(s3)):

			if s3[j].isdigit():
				y=y or True
			else:
			    y= y or False	
			j=j+1

		string=''
		for k in range(len(s3)):
			string= string+s3[len(s3)-(k+1)]
		if string==s3:
			c=False
		else:
			c=True	
		
		z=False		
		for l in range(len(s3)):
			if s3[l]=='_' or s3[l]=='@' or s3[l]=='$':
				z= z or True
			else:
			    z= z or False	
			j=j+1

	ans=(x and y and z and c)		
	return(ans)
	

