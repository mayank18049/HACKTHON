#midterm Lab Exam Set 3 - 2018
#name: Ashmit Dassi
#rollno. 2018024
#section A
#group 8
#date : 23/09/18
from string import *
def_countmatchingChars(s1,s2):
	


def valid_password(s3):
	length = len(s3)
	if length < 8:
		return False
	a=False
	b=False
	c=False
	d=False
	for p in range(length):
		if (s3[p]>='0') and (s3[p]<='9'):
			a = True
			
	for p in range(length):
		if (s3[p]>='A') and (s3[p]<='Z'):
			b = True
	
	for p in range(length):
		if (s3[p]=='_') or (s3[p]=='@') or (s3[p]=='$'):
			c = True
	
	for p in range(length):
		if (s3[p]==s3[p-length]):
			d = True
	
	if a  and b  and c  and d:
		return True
	
	else:
		return False
			
print("Password check returns value " +str(valid_password("aA10@21Aa")))




 