# Mid Term Lab Exam Set 3 - 2018
# Name : Sandeep Kumar
# Roll Number : 2018092
# Section : A
# Group : 4
# Date : 23/09/2018

def count_matchingChars(s1,s2):
	list1= []
	list2 = list(s2)
	for i in s1:
		if(i not in list1):
			list1.append(i)
	count = 0;
	for i in list1:
		if(i in list2):
			count+=1
	return count

def valid_password(s3):
	list1 = list(s3)
	rev = s3[::-1]

	if(s3 == rev):
		return False
	if(len(list1)<8):
		return False
	alpha = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_@$'
	cap = 'ABCDEFGHIJKLMONPQRSTUVWXYZ'
	digit = '0123456789'
	other = '@_$'
	small = 'abcdefghijklmnopqrstuvwxyz'
	a = False
	c = False
	d = False
	o = False
	s = False
	temp = list(alpha)
	for i in list1: 
		if(i not in temp):
			return False
		if(i in alpha):
			a = True
		if(i in cap ):
			c = True
		if(i in digit):
			d = True
		if(i in other):
			o = True

	return (a and c and d and o ) 

if __name__ == '__main__':
	print('No. of matching characters are ' + str(count_matchingChars("abcc","aaaababababccbabbabddfhshkdhfkjs")))
	print('Password check return value ' + str(valid_password("aaac1@SD")))
	print('Password check return value ' + str(valid_password("ASDF12@23")))
	print('Password check return value ' + str(valid_password("cope1234")))
	print('Password check return value ' + str(valid_password("Aaa12@21aaA")))