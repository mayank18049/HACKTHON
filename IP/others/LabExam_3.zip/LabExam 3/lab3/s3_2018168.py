'''
Name: Pragyan Mehrotra
Roll no: 2018168
Section: A
group: 8
'''

def count_matchingChars(s1,s2):
	s1= s1.lower()
	s2=s2.lower()
	n_s1=''
	n_s2=''
	c=0
	for i in s1:
		if i not in n_s1:
			n_s1+=i
	for i in s2:
		if i not in n_s2:
			n_s2+=i
	if len(n_s1) > len(n_s2):
		for i in n_s1:
			if i in n_s2:
				c += 1
	else:
		for i in n_s2:
			if i in n_s1:
				c += 1
	return c
		
def valid_password(s3):
	c=0
	d=0
	e=0
	ch = '_@$'
	if len(s3)<8:
		return False
	elif s3 == s3[::-1]:
		return False
	for i in s3:	
		if i in ch:
			d+=1
		if i.isdigit():
			c+=1
		if i.isupper():
			e+=1
	if c ==0 or d==0 or e==0:
		return False
	return True

