#function2
def valid_password(s3):
	if len(s3)< 8:
		return False
	
	elif s3[::]==s3[::-1]:
		return False
	else:
		
		flag=0
		for x in s3:
			
			if x==('_' or '@' or '$'):
				flag=1
		
			
		
		count=0
		for x in s3:
			if ord('0')<=ord(x)<=ord('9'):
				count=1
		
		

		
		mark=0
		for x in s3:
			if ord('A')<=ord(x)<=ord('Z'):
				mark=1
		
			

		if count==0 and mark==0 and flag==0:
			return True
		else:
			return False
	




def count_matchingChars(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	x1=s1[0]
	x2=s2[0]
	s1new= s1[0]
	s2new=s2[0]
	for x in s1:
		
		if x==x1:
			s1new=s1new
		else:
			s1new=s1new+x
			x1=x
	for x in s2:
		
		if x==x2:
			s2new=s2new
		else:
			s2new=s2new+x
			x2=x
	count=0
	for x in s1new:
		
		if x in s2new:
			count+=1
	return(count)
