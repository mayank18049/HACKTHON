#midterm lab exam set 3-2018
#mohd naki
#roll no.=2018052
#secA
#GROUP 4


def valid_password(s3):
	if (lens(s3)>=8)and('a'<=s3<='z')and(for k in s3:
		'A'<=k<='Z')and(0<=s3<=9)and(('_'in s3)or('@'in s3)or('$'in s3)):
			return True
	else:
		return False
		

def count_matchingChars(s1,s2):
	a=s1.lower()
	b=s2.lower()
	c=0
	for k in s1:
		if k in s2:
			c=c+k
	return (c)
		else:
	return (0)




