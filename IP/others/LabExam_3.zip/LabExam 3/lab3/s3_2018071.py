#Name: Praphull Dass
#Roll No.: 2018071
#Section: A
#Group: 7
def valid_password(s3):
	x=str(s3)
	if len(x)<8:
		return(False)
	else:
		A='ABCDEFGHIJKLMNOPQRSTUVWXYZ'
		for i in A:
			c=0
			if x.find(i):
				c=1
			else:
				c=0
		if c==0:
			return(False)
		else:
			y=(x.find('_'))or(x.find('@'))or(x.find('$'))
			if y==-1:
				return(False)
			else:
				p=x[::-1]
				if p==x:
					return(False)
				else:
					B='123456789'
					for i in B:
						count=0
						if x.find(i):
							count=1
						else:
							count=0
					if count==0:
						return(False)
					else:
						return(True)
def count_matching(s1,s2):
	count=0
	a=str(s1)
	b=str(s2)
	for i in b:
		x=a.find(i)
		while x!=-1:
			y=b.find(i)
			z=b.find(i)
			if z==-1:
				count=count+1
			else:
				count=count
			x=-1
	print(count)



