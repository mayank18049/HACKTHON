#shikhar tiwari,2018100,A,4
def valid_password(s3):
	ch=0
	df=0
	for c in s3:
		if c==c.upper():
			ch=ch+1
	for c in s3:
		if (c=='_') or (c=='@') or (c=='$'):
			df=df+1
	if (len(s3)<=8):
		if(ch>0):
			if(df>0):
				if(s3!=s3[::-1]):
					return(True)
				else:
					return(False)
			else:
				return(False)
		else:
			return(False)
	else:
		return(False)

def count_matchingChars(s1,s2):
	count=0
	s1=s1.lower()
	s2=s2.lower()
	for c in s1:
		for d in s2:
			if(c==d):
				count=count+1
	
count_matchingChars('aA','BbAaa')



