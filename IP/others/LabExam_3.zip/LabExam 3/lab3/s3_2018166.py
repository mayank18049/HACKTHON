#midterm lab exam set 3 - 2018
#name - pakhi mangoli
#rollno - 2018166
# section  - A
# group - 6


#function 1
def count_matchingchars(s1,s2) :
	s1 = s1.lower()
	s2 = s2.lower()
	a = len(s1)
	b = len(s2)
	s = 0
	d = 0
	if a >= b:
		s = 1

	if s == 1 :		 
		for i in range(len(s1)):
			w = s1[i]
			p = 0
			q = 0
			for z in range(len(s2)) :
				if w == s2[p] :
					q = 1
				p = p + 1
			if q == 1:
				d = d + 1
		
	else:
		for i in range(len(s2)):
			w = s2[i]
			p = 0
			q = 0
			for z in range(len(s1)) :
				if w == s1[p] :
					q = 1
				p = p + 1
			if q == 1:
				d = d + 1 			
	return d			
#function 2
def valid_password(s3) :
	if len(s3) >= 8:
		p = 0
		q = 0
		s = 0
		z = 0
		for i in range (len(s3)):
			if 'A' <= s[i] and s[i] <= 'Z':
				p = p + 1
		for i in range (len(s3)):
			if '0'<= s[i] and s[i] <= '9':
				q = q + 1	
		for i in range (len(s3)):
			if s[i] == '_' or s[i] == '@' or s[i] == '$':
				s = s + 1
		for i in range (len(s3)/2):
			if s[i] != s[-(i+1)]:
				z = z + 1
	if len(s3) >= 8 and p >= 1 and q >= 1 and s >= 1 or z == 0 :
		return True
	else :
		return False
