#Midterm Lab Exam Set 3 - 2018
#Name: Isha Gupta
#Roll Number: 2018040
#Section: A
#Group: 8
#Date: 23.09.2018
def count_matchingChars(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	count=0
	empty=""
	for i in s1:
		if i in s2 and i not in empty:
			count+=1
			empty+=i
	return count
def valid_password(s3):
	s=""
	length=-1*(len(s3)+1)
	for i in range(-1,length,-1):
		s=s+s3[i]
	if (s==s3):
		return False
	if (len(s3)>=8):
		b=c=d=0
		big="ABCDEFGHIJKLMNOPQRSTUVWXYZ"
		num="0123456789"
		special="_@$"
		for j in s3:
			if j in big:
				b=1
			if j in num:
				c=1
			if j in special:
				d=1
		if (b==0 or c==0 or d==0):
			return False
		else:
			return  True
	else:
		return False
