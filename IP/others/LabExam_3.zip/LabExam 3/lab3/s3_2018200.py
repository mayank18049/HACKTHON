#midterm Lab Exam Set 3-2018
#name: Tanmaya Gupta
#Roll Number: 2018200
#Section:A
#group: 8
#date: 23/09/18


#function1
#def count_matching(s1,s2):
#	for i in s1:

from string import *
def count_matchingChars(s1,s2)
	s1=s1.lower()
	s2=s2.lower()
	j=0
	for x in s2:
  		if (s1[x]==s2[j]):
  			c=c+1
  			j=j+1
  			




def valid_password(s3):
	if(len(s3)>=8 and s3!=s3[::-1]):
		j=0
		for j in s3:
			if ord(j)>64 and ord(j)<91:
				continue
			elif ord(j)>47 and ord(j)<58:
				continue
			elif s3[j]=='_' or s3[j]=='@' or s3[j]=='$':
				continue
			else:
				return False()	
	else:
		return False
x=input("enter string")
t=valid_password(x)
print(t)	



				

		

