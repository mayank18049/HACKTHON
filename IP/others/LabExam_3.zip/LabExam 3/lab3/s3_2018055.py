# Midterm Lab Exam Set 3 - 2018
# Name: Naman Tyagi
# Roll Number : 2018055
# Section : A
# Group: 7
# Date: 23 September 2018


#function1
def count_matchingChars(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	l1,l2="",""
	count=0
	for i in s1:
		if i not in l1:
			l1=l1+i
	for i in s2:
		if i not in l2:
			l2+=i
	for i in l1:
		if i in l2:
			count+=1
	return count

#function2
def valid_password(s3):
	countA,digit,countd,counts,special=0,"0123456789",0,0,"_@$"
	for i in s3:
		if "A"<=i<="Z":
			countA+=1
	for i in s3:
		if i in digit:
			countd+=1
	for i in s3:
		if i in special:
			counts+=1
	if len(s3)>=8:
		if s3[0:]!=s3[::-1]:
			if countd>0 and counts>0 and special>0:
				return True
			else:
				return False
		else:
			return False
	else:
		return False

print ("No. Of matching characters are " + str(count_matchingChars("aabcdddek1112@","bb221111@k55")))
print ("Password check returns value " + str(valid_password("Aaa12@21aaA")))