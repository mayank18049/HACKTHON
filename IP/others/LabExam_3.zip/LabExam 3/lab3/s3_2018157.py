"""Mayank Gupta
2018157
A5
"""
def count_matchingChars(s1,s2):
	i=0
	j=0
	x=len(s2)
	s1=s1.lower()
	s2=s2.lower()
	while j<x:
		for a in range(x-1):
			if s2[j]==s1[a]:
				i=i+1
			break
		j=j+1
	return(i)
#count_matchingChars("bbbbbaacdres","Abbb")
def valid_password(s3):
	cn=len(s3)
	y=cn//2
	a=0
	b=0
	c=0
	d=0
	e=0
	if cn>=8:
		for i in s3:
			if 'a'<=i<='z':
				a=1
		for i in s3:
			if 'A'<=i<='Z':
				b=1	
		for i in s3:
			if '0'<=i<='9':
				c=1
		for i in s3:
			if i=='_' or i=='@' or i=='$':
				d=1
		for x in range(y):
			if s3[x]== s3[(cn-1)-x]:
				e=1
		if a==1 and b==1 and c==1 and d==1 and e==0:
			return('True')
		else:
			return('False')
	else:
		return('False')