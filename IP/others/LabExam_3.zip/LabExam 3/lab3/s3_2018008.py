# Midterm Lab Exam Set 3 - 2018 
# Name : Aditya Vardhan Anand 
# Roll no.: 2018008
# Section : A
# Group No.: 8
# Date : 23.09.18 
 def count_matchingChars(s1,s2):
 	count=0:
 	flaggg=0:
 	for m in s1:
 		for p in range(0,m):
 			if s1[p]==m:
 				flaggg=1
 				break
 		if flaggg==1:
 			flaggg==0
 			continue
 	    for n in s2:
 	    	if m==n:
 	    		count+=1
 	    		break
 	return count 

 def valid_password(s3):
 	ucaseFlag=False
 	chFlag=False
 	digFlase=False
 	if len(s3)<8:
 		return False
 	for m in S3:
 		if ord('A')<=ord(m)<=('Z'):
 			ucaseFlag =True
 	    if ord('0')<=ord(m)<=ord('9')
 	        didFlag= True
 	    if m==' ' or m =='@'m =='$'
 	        chFlag = True
