# Midterm Lab Exam Set 3 - 2018
# Name : Vrinda Narayan
# Roll Number : 2018120
# Section : A
# Group : 8
# Date : 23 September 2018
import string
def count_matchingChars(s1,s2):
	count=0
	t=0
	x=0
	string=''
	l1=len(s1)
	while t<l1 and x1=0:

		for c in s2:
				if s1[t].isalpha():
					if s1[t]==c.upper() or s1[t]==c.lower():
						x=1
						string=string+c.upper()+c.lower()
				if x==1:
					count=count+1
					x=0
				else:
					if s1[t]==c:
						x=1
						string=string+c
				if x==1:
					count=count+1
					x=0
		t=t+1
		while t<l1:
			t=t+1
			for c in string:
				if s1[t-1]==string:
					t=t+1
	return count

def valid_password(s3):
	x=True
	if len(s3)<8:
		x=False
	t1=0
	t2=0
	t3=0
	l=len(s3)
	for c in s3:
		if c=='_' or c=='@' or c=='$':
			t1=1
		if c<='9' and c>='0':
			t2=1
		if c<='Z' and c>='A':
			t3=1
	if t1==0 or t2==0 or t3==0:
		x=False
	flag=0
	for a in range(len(s3)):
		if s3[a]!=s3[l-a-1]:
			flag=1
	if flag==0:
		x=False
	return x



