# Midterm Lab Exam Set 3 - 2018
# Name: Gaurav Khurana
# Roll Number: 2018142
# Section: A
# Group: 6
# Date: 23/09/2018

#function1
def count_matchingChars(s1,s2):
	c=0
	i=0
	s1=s1.upper()
	s2=s2.upper()
	while i<256:
		if(s1.find(chr(i))!=-1 and s2.find(chr(i))!=-1):
			c=c+1
		i=i+1
	return c

#function2
def valid_password(s3):
	f1=False
	f2=False
	f3=False
	f4=False
	if(len(s3)<8):
		return False
	if(s3==s3[::-1]):
		return False
	for ch in s3:
		if(ord(ch)>=65 and ord(ch)<=90):
			f1=True
		elif(ord(ch)>=47 and ord(ch)<=57):
			f2=True
		elif(ch=='_' or ch=='@' or ch=='$'):
			f3=True
		elif(ord(ch)>=97 and ord(ch)<=122):
			f4=True
		else:
			return False
	if(f4==False):
		f4=True
	x=f1 and f2 and f3 and f4
	return x

#print output
print("No. of matching characters are "+ str(count_matchingChars("aabcdddek1112@","bb221111@k55")))
print("Password check returns value "+str(valid_password("Aaa12@21aaA")))