# Midterm Lab Exam Set 3 - 2018
# Name       : Sidhant S Sarkar
# Roll Number: 2018102
# Section    : A
# Group      : 6
# Date       : 23/09/2018

import string

#function1
def count_matchingChars(s1,s2):
	t1 = s1.lower()
	t2 = s2.lower()
	s=''
	for x in t1:
		if(s.find(x) != -1):
			continue
		else:	
			for y in t2:
				if(x==y):
					s+=x
					break
	return len(s)

def helper(s3,par1):
	'''
		Helper Function
		Returns: True if any character in s3 is found in par1, else False.
	'''
	for x in s3:
		if (x in par1):
			return True
	return False

#function2
def valid_password(s3):
	if (len(s3) < 8) or (not helper(s3,string.digits)) or (not helper(s3,string.ascii_uppercase)) or (not helper(s3,'_@$')) or (s3==s3[::-1]):
		return False
		
	for x in s3:
		if(not x.isalnum())and(not helper(x,'_@$')):
			return False
	return True

# print output
print("No. of matching characters are " + str(count_matchingChars("aabcdddekll12@","bb22llll@k55")))
print("Password check returns value "+str(valid_password("Aaa12@21aaA")))



