# IP Mid-Sem Lab Exam Set-2
# Name - Raghav Agarwal
# Roll No.- 2018177
# Sec.- A   Group- 1
# Date - 23/09/2018

# function 1
def end_begin_other(s1,s2):
	l1=len(s1)
	l2=len(s2)
	t=s1.index('a')
	y=s1.index('B')
	u=s1.index('C')
	if t=="a" and y=="B" and u=="C" :
		return True
	else:
		return False
print(str("function1",end_begin_other("abc","aBCabXabc")))


# function2
def valid_password(s3):
	a=len[s3]
	t=0
	for t in range(a):
		i
	print

	