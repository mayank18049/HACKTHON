#Midterm Lab Exam Set 2
#Name Parul
#Roll No:2018065
#sectin:A
#Group:1
#Date:23/09/2018
#function1
import string
def end_begin_other(s1,s2):
	#s1=input("enter string:")
	#s2=input("enter another string:"
	l1=len(s1)
	l2=len(s2)
	diff=l1-l2*2
	if l2<l1:
		y=s1.find(s2)
		if y!=-1:
			a1=s1[l2+diff:]
			x=a1.find(s2)
			if x!=-1:
				return True

	elif l1<l2:
		y=s2.find(s1)
		if y!=-1:
			a1=s2[l1+diff:]
			x=a1.find(s1)
			if x!=-1:
				return True

	else:
		return False
if __name__ == '__main__':
	value=end_begin_other('abc','abchiabc')
	print value
	value=end_begin_other('ABC','ABChiabc')
	print value
	value=end_begin_other('abchiabc','abc')
	print value
#function2
def valid_password(s3):
	#s3=input("enter password:")
	l=len(s3)
	if l==8:
		for i in range(l):
			if ((48<=ord(s3[i])<=57) or (97<=ord(s3[i])<=122) or (65<=ord(s3[i])<=90) or s3[i]=='_' or s3[i]=='@' or s3[i]=='$'):
				return True
			else: 
				return False

if __name__ == '__main__':
	print("funtion returns"+str(valid_password("ASDF123@23")))