#Name: Pragya Sethi
#Roll no: 2018067
#Section: A
#Group:	3
#Date: 22/9/2018

#Function1
def end_begin_other(s1,s2):
	if(len(s1)>=len(s2)):
		A=s1.upper()		#A is the bigger string containing smaller string B
		B=s2.upper()
	else:
		A=s2.upper()		#Upper casing the strings in order to make them case insensitive
		B=s1.upper()
	l1=len(A)
	l2=len(B)
	if(A[:l2]==B and A[l1-l2:]==B):		#Finding B in A from the beginning and the ending using string slicing
		return True
	else:
		return False

#Function2
def valid_password(s3):
	alpha=0
	UpperCase=0
	digit=0
	sp_char=0
	if(len(s3)>=8):				#Checks for the minimum character length of the password
		for x in s3:
			if(x.isdigit()):	#Checks if a digit is present in the password
				digit=digit+1
			if(x=='_' or x=='@' or x=='$'):	#Checks for special character
				sp_char=sp_char+1
			if(x.isalpha()):		#Checks for alphabet
				alpha=alpha+1
				if(ord(x)>=65 and ord(x)<=90):		#Checks for upper case alphabets
					UpperCase=UpperCase+1
	else:
		return False
	if(digit>0 and alpha>0 and UpperCase>0 and sp_char>0):		#Returns true if all the checks are positive
		return True
	else:
		return False

#print output
print("Function1 returns " + str(end_begin_other("abc","aBCabXabc")))
print("Function2 returns " + str(valid_password("ASDF12@23")))