# Midterm Lab Exam Set 2 - 2018
# Name: ABHIMANYU JHA
# Roll Number: 2017126
# Section: A
# Group: 2
# Date: 23 September 2018

def end_begin_other(s1,s2):
	l1=len(s1)
	l2=len(s2)
	s1=s1.lower()
	s2=s2.lower()

	#checking if s2 in s1 end/start
	if (s1[:l2]==s2) and (s1[-l2:]==s2):
		return True
	#checking if s1 in s2 end/start	
	elif (s2[:l1]==s1) and (s2[-l1:]==s1):
		return True
	else:
		return False

# print(end_begin_other("AbCHiabc","abc"))
# print(end_begin_other("AbC","ABCHiaBc"))
# print(end_begin_other("abc","aBCabXabc"))
# print(end_begin_other("abc","ACCabXabc"))

def valid_password(s3):
	# print('\n')

	#CONDITION 1
	# print('len',len(s3))
	if len(s3) < 8:
		return False

	#CONDITION 3	
	upper=0
	for i in s3:
		if i in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ':
			upper+=1
	# print('upper',upper)
	if upper==0:
		return False

	#CONDITION 4
	num=0
	for i in s3:
		if i in '0123456789':
			num+=1
	# print('num',num)
	if num==0:
		return False


	#CONDITION 5
	char=0
	for i in s3:
		if i =='@' or i=='_' or i=='$':
			char+=1
	# print('char',char)
	if char==0:
		return False

	#ALL SATISFIED

	return True




# print(valid_password("aaac1@SD"))
# print(valid_password("ASDF12@23"))
# print(valid_password("cope1234"))

#print output

print("Function 1 returns "+ str(end_begin_other("abc","aBCabXabc")))
print("Function 2 returns "+ str(valid_password("ASDF12@23")))
