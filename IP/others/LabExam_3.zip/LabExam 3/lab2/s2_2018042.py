#mid term Lab Exam set-2
#name: ishan kapur
#roll no: 2018042
#section: A
#group: 2
# date: 23/09/2018
def end_begin_other(s1,s2):
	x=len(s1)
	y=len(s2)
	s1=s1.lower()
	s2=s2.lower()
	if y>x:
		z=s2[:x]
		w=s2[y-x:]
		if z==s1 and w==s1:
			return True
		else:
			return False
	elif x>y:
		s=s1[:y]
		r=s1[x-y:]
		if s==s2 and r==s2:
			return True
		else:
			return False

def valid_password(s3):
	x=len(s3)
	r=-1
	n=-1
	e=-1
	if x<8:
		return False
	else:
		i=0
		for i in range (x):
			if s3[i]>'A' and s3[i]<'Z':
				r=0
			elif s3[i]>'0' and s3[i]<'9':
				n=0
			elif s3[i]=='_' or s3[i]=='@' or s3[i]=='$':
				e=0
		if r==0 and n==0 and e==0:
			return True
		else:
			return False
if __name__=='__main__':
	print('function1 returns '+ str(end_begin_other("abc","aBCabXabc")))
	print('function2 returns '+ str(valid_password("ASDF12@23")))
