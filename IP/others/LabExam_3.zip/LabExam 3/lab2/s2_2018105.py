#Mid Term Lab Exam Set 2 - 2018
#Name: Suchet Aggarwal
#Roll Number: 2018105
#Section: A
#Group: 1
#Date: 23.09.2018

import string

#function 1
def end_begin_other(s1,s2):
	#length of both strings
	n=len(s1)
	m=len(s2)
	#Check is case insensitive thus converted both to lowercase
	s1=s1.lower()
	s2=s2.lower()
	#flag variable indicating state of condition
	flag=0
	#Check for s1 in s2	
	if s2[:n]==s1 and s2[m-n:]==s1:
		flag = 1
	#Check for s2 in s1
	elif s1[:m]==s2 and s1[n-m:]==s2: 		
		flag = 1
	#Finally check Flag
	if flag==1:
		return True
	else:
		return False

#function 2
def valid_password(s3):
	#length of the string	
	n=len(s3)
	#Count variables (Accumilators)
	cnt_upper=0
	cnt_digit=0
	cnt_special=0	
	#Check for intermediate conditions	
	for ch in s3:
		#Atleast one Uppercase		
		if ch.isupper():
			cnt_upper+=1
		#Atleast one Digit
		elif ch.isdigit():
			cnt_digit+=1
		#Atleast one of the Special Characters('_' or '@' or '$')
		elif ch=='_' or ch=='@' or ch=='$':
			cnt_special+=1			
	#Final Condtion (ALL MUST BE TRUE)
	if n>=8 and cnt_upper>=1 and cnt_digit>=1 and cnt_special>=1:
		return True
	else:
		return False

#print output
print('Function1 returns '+str(end_begin_other('abc','aBCabXabc')))
print('Function2 returns '+str(valid_password('ASDF12@23')))


