#Midterm Lab Exam Set 2 - 2018
#Name: Pranshu Agrawal
#Roll Number : 2018170
#Section : A
#Group : 2
#Date: 23/09/18
#function1
def end_begin_other(s1,s2):
	sa=s1.lower()
	sb=s2.lower()
	a=len(sa)
	b=len(sb)
	
	if(a>=b):
		c=a-b
		if(sa[0:b]==sb and sa[c:]==sb):
			return True
		else:
			return False
	else:
		c=b-a
		if(sb[0:a]==sa and sb[c:]==sa):
			return True
		else:
			return False

#function2
def valid_password(s3):
	a=len(s3)
	if(a<8):
		return False
	else:
		b=0
		c=0
		d=0
		for i in range(0,a-1):
			if('0'<s3[i]<'9'):
				b=b+1
			if('A'<s3[i]<'Z'):
				c=c+1
			if(s3[i]=='_' or s3[i]=='@' or s3[i]=='$'):
				d=d+1
		if(b>0 and c>0 and d>0):
			return True
		else:
			return False


#print output
print("Function1 returns "+str(end_begin_other("abc","aBCabXabc")))
print("Function2 returns "+str(valid_password("ASDF12@23")))
		
		
























			
