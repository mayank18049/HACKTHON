#Midterm Lab exam Set 2 - 2018
#NAME : MOHAMMAD HAMZAH AKHTAR
#ROLL NUMBER : 2018051
#SECTION : A
#GROUP : 3
#DATE : 23/9/18

#FUNCTION - 1

def end_begin_other(s1,s2):
	s1 = s1.lower()
	s2 = s2.lower()
	length = len(s1)
	begin = s1[0:3]
	end = s1[length-3:]
	if (begin == s2) and (end == s2):
		return True
	else:
		return False

#FUNCTION - 2 
def valid_password(s3):
	length = len(s3)
	if(length < 8):
		y = False
	else: 
		y = True	
	i = 0
	k = 0
	a = False
	while (k<length):
		a =s3[k].isdigit()
		if (a == True):
			break
		k = k+1
	b = False
	z=0
	while (z<length):
		if(s3[z]=='@')or(s3[z]=='_')or(s3[z]=='$'):
			b = True
			break	
		z = z+1
	w = 0	
	c = False
	while (w<length):	
		c = s3[w].isupper()
		if (c == True):
			break
		w = w+1
	solution = y and c and a and b		
	if(solution == True):
		return True
	else: 
		return False			


print("Function1 returns " + str(end_begin_other("abc","aBCabXabc")))
print("Function2 returns " + str(valid_password("ASDF12@23")))


