''' Midterm Lab Exam Set 2- 2018
	Name: Dhruv Sahnan
	Roll Number:2018230
	Section:B
	Group: 7
	Date: 23 September 2018 '''
#function1
def end__begin_other(s1,s2):
	if len(s1)>len(s2):
		s=s2
		b=s1
	else:
		s=s1
		b=s2
	if (b[:len(s)].lower()==s.lower()) and (b[len(b)-len(s):].lower()==s.lower()):
		return True
	else:
		return False

#function2
def valid_password(s3):
	flagu=-1
	flagd=-1
	flags=-1
	if len(s3)>=8:
		for i in range(len(s3)):
			if s3[i].isupper()==True:
				flagu=0
			elif s3[i].isdigit()==True:
				flagd=0
			elif s3[i]=='_' or s3[i]=='@' or s3[i]=='$':
				flags=0
	else:
		return False
	if flagu==flagd and flagd==flags and flagu==0:
		return True
	else:
		return False

#print output
print("Function1 returns "+str(end__begin_other("abc","aBCabXabc")))
print("Function2 returns "+str(valid_password("ASDF12@23")))