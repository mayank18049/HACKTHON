# MidTerm lab Exam Set 2 - 2018
# Name : Vanshika Goel
# Roll Number : 2018202
# Section : A
# Group : 2
# Date : 23-09-2018
def end_begin_other(s1,s2):
    l1 = len(s1)
    l2 = len(s2)
    if l1 > l2:
        i = 0
        ans = True
        while i<l2 and ans != False:
            if s1[i].isupper():
                if ord(s1[i]) == ord(s2[i]) or ord(s1[i])==ord(s2[i])+32:
                   i=i+1
                   ans = True
                else:
                   ans = False
            if s[i].islower():
                if ord(s1[i]) == ord(s2[i]) or ord(s1[i])==ord(s2[i])-32:
                   i=i+1
                   ans = True
                else:
                   ans = False    
        j=l1-l2
        sec_ans=True
        while j<l1 and sec_ans != False:
            if s1[j].isupper():
                if ord(s1[j]) == ord(s2[j]) or ord(s1[j])==ord(s2[j])+32:
                   j=j+1
                   sec_ans = True
                else:
                   sec_ans = False
            if s1[j].islower():
                if ord(s1[j]) == ord(s2[j]) or ord(s1[j])==ord(s2[j])-32:
                   j=j+1
                   sec_ans = True
                else:
                   sec_ans = False
    elif l2>l1:
    	temp=l2
    	l2=l1
    	l1=temp
    	i=0
    	j=l1-l2
    	ans=True
    	sec_ans=True
    	while i<l2 and ans!=False:
            if s1[i].isupper():
                if ord(s1[i]) == ord(s2[i]) or ord(s1[i])==ord(s2[i])+32:
                   i=i+1
                   ans = True
                else:
                   ans = False
            if s[i].islower():
                if ord(s1[i]) == ord(s2[i]) or ord(s1[i])==ord(s2[i])-32:
                   i=i+1
                   ans = True
                else:
                   ans = False
        while j<l1 and sec_ans!=False:
            if s1[j].isupper():
                if ord(s1[j]) == ord(s2[j]) or ord(s1[j])==ord(s2[j])+32:
                   j=j+1
                   sec_ans = True
                else:
                   sec_ans = False
            if s1[j].islower():
                if ord(s1[j]) == ord(s2[j]) or ord(s1[j])==ord(s2[j])-32:
                   j=j+1
                   sec_ans = True
                else:
                   sec_ans = False                          
    if ans and sec_ans:
    	return True
    else:
    	return False
def valid_password(s3):
	l=len(s3)
	i=0
	if l>=8:
		a=True
		while i<l:
			if s[i].isdigit:
				i=i+1
				a=True
			else:
				i=i+1
				a=False
			if s[i].isupper:
				i=i+1
				a=True
			else:
				i=i+1
				a=False
			if 97<=ord(s[i])<=122:
				i=i+1
				a=True
			else:
				a=False
	else:
		a=False
	return a

if __name__=='__main__':
	print("Function1 returns " + str(end_begin_other("abc","aBCabXabc")))
	print("Function2 returns " + str(valid_password("ASDF12@23")))

