#midterm Lab Exam set 2 - 2018
#name: Shekhar
#Roll Number:2018365
#Section:B
#Group:6
#Date: 23/09/2018

#function1
def end_begin_other(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	n1=len(s1)
	n2=len(s2)
	if n1>n2:
		if (s1[0:n2]==s2 and s1[n2:]==s2):
			print(True)
		else:
			print(False)
	elif n2>n1:
		if (s2[0:n1]==s1 and s2(n1:)==s1):
			print(True)
		else:
			print(False)







#function2
def valid_password(s3):
	if s3>=8 and for s3 in range(a,z) and for s3 in range(A,Z) and for s3 in range (0,9) or _ or @ or $:
		print(True)
	else:
		print(False)

#print output
print("Function1 returns " + str(end_begin_other("abc,aBCabXabc")))
print("Function2 returns " + str(valid_password("ASDF12@23")))