#Abinash Pegu
#2018123
def end_beginning_other(s1,s2):
	s1=s1.upper()
	s2=s2.upper()
	a=len(s1)
	b=len(s2)
	if((s1==s2[b-a:] and s1==s2[0:3]) or (s2==s1[a-b:] and s2==s1[0:3])):
		return (True)
	else:
		return (False)
print (end_beginning_other(s1,s2))





