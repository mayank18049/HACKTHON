#NAOREM EDISON SINGH
#2018161
#sec:A
#group:1
def end_begin_other(s1,s2):
	if len(s1)>len(s2):
		if (s2[-int(len(s2)):]==s1[-int(len(s2)):]):
			return('True')
		else:
			return('False')
	elif len(s2)>len(s1):
    	if (s1[-int(len(s1)):]==s2[-int(len(s1)):]):
			return('True')
		else:
			return('False')	

			
print(end_begin_other('abc','aBCabXabc'))			
def valid_password(s3):
	if len(s3)<=8:
		for i in s3:
			if (i >= 'a' and i <= 'z') and (i >= '0' and i <= '9') and (i='@' or i='_' or i='$'):
		return('True')
	else:
		return('False')			
print(valid_password('ASDF12@23'))	

