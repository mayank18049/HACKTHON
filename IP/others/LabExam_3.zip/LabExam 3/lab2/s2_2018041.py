#Midterm Lab Exam Set2-2018
#name: Ishaan Arora
#roll no: 2018041
#section:A
#group:1
#date:23/9/2018



#function1
def end_begin_other(s1,s2):
	x=len(s1)
	y=len(s2)
	if(x>y):
		k=s1.lower()
		k1=s2.lower()
		if(k.find(k1)!=0):
			return False
		else:
			if(k.find(k1,1)==-1):
				return False
			else:
				return True
	else:

		k=s1.lower()
		k1=s2.lower()
		if(k1.find(k)!=0):
			return False
		else:
			if(k1.find(k,1)==-1):
				return False
			else:
				return True





#function2
def valid_password(s3):
	x=len(s3)
	
	if(x<8):
		return False
	else:
		sum0=0
		sum1=0
		sum2=0
		sum3=0
		i=0	
		
		for i in range(x):

			if(s3[i]>='a'and s3[i]<='z'):
				sum3=sum3+1 
			if(s3[i]>='A' and s3[i]<='Z'):
				sum0=sum0+1
			if(s3[i]>='0'and s3[i]<='9'):
				sum1=sum1+1	
			if(s3[i]=='_' or s3[i] =='@' or s3[i]=='$'):
				sum2=sum2+1
			

	if(sum0==0 or sum1==0 or sum2==0 or sum3==0):
		return False

	else:
		return True

				

print("Function1 returns"+ end_begin_other("abc","ABCcdbwjkchabc"))
k=valid_password('aaaac1@Sd')	
print("Function2 returns"+k)			


			