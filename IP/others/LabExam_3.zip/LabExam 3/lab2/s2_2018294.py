#Midterm Lab Exam Set 2 - 2018
#Name: Manan Jain
#Roll Number: 2018294
#section: B
#Group: 7
#Date: 23/09/2018
#function 1
def end_begin_other(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	if len(s1)<len(s2):
		if s1==s2[:len(s1)] and s1==s2[-len(s1):]:
			return True
	elif len(s1)>len(s2):
		if s2==s1[:len(s2)] and s2==s1[-len(s2):]:
			return True
	else:
		if s1==s2:
			return True
	return False
#fuction2
def valid_password(s3):
	if len(s3)<8:
		return False
	special=0
	upper=0
	digit=0
	error=0
	for i in s3:
		if i.isupper():
			upper+=1
		elif i.isdigit():
			digit+=1
		elif i=='_' or i=='@' or i=='$':
			special+=1
		elif not(i.isalpha()):
			error+=1
	if special==0 or upper==0 or digit==0 or error>0:
		return False
	return True
print("Function1 returns "+str(end_begin_other("abc","aBCabXabc")))
print("Function2 returns "+str(valid_password("ASDF12@23")))