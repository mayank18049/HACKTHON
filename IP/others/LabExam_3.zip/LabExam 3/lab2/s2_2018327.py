#Mid Term Lab Exam Set 2 - 2018
#Name	-	Aman Aggarwal
#Roll No-	2018327
#Section-	B
#Group	-	8
#Date	-	23/09/2018
#function1
def end_begin_other(s1,s2):
	"""Returns True if either of the strings appear at the very end and at the very 
	beginning of the other string, ignoring upper/lower case differences, i.e., computation 
	is case-insensitive. Else returns False"""
	if len(s1)<len(s2):
		n1=len(s1)
		n2=len(s2)
		str1=s1
		str2=s2
	else:
		n1=len(s2)
		n2=len(s1)
		str1=s2
		str2=s1
	str2=str2.lower()
	str1=str1.lower()
	first=str2.find(str1)
	last=str2.find(str1,n2-n1)
	if first==0 and last==n2-n1:
		return True
	else:
		return False
#function2
def valid_password(s3):
	"""Returns True when password is valid and False otherwise"""
	n=len(s3)
	if n<8:
		return False
	i=0
	uppercount=0
	digitcount=0
	charcount=0
	while i<n:
		if not(ord(s3[i])>=97 and ord(s3[i])<=122):
			if ord(s3[i])>=65 and ord(s3[i])<=90:
				uppercount+=1
			elif ord(s3[i])>=48 and ord(s3[i])<=57:
				digitcount+=1
			elif s3[i]=='_' or s3[i]=='@' or s3[i]=='$':
				charcount+=1
			else:
				return False
		i+=1
	if uppercount==0 or digitcount==0 or charcount==0:
		return False
	else:
		return True
#print output
print("Function1 returns " + str(end_begin_other("abc","aBCabXabc")))
print("Function2 returns " + str(valid_password("ASDF12@23")))
