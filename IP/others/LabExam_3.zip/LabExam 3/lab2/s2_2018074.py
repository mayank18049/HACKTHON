# Midterm Lab Exam Set 2 - 2018
# Name: Priyesh Kumar Chaurasia
# Roll Number: 2018074
# Section: A
# Group: 2
# Date: 23/09/2018

#function1

def end_begin_other(s1,s2):

	s1=s1.lower()
	s2=s2.lower()

	if len(s1)>=len(s2):
		if s1[len(s1)-len(s2):]==s2 or s1[0:len(s2)]==s2:
			return True
		else:
			return False
	elif len(s2)>len(s1):
		if s2[len(s2)-len(s1):]==s1 or s2[0:len(s1)]==s1:
			return True
		else:
			return False




#function2

def valid_password(s3):

	s3=str(s3)
	
	k=len(s3)
	
	c=False
	a=False
	b=False
	
	
	for q in s3:
	
		if q in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ':
			c = True
		elif q in '0123456789':
			a = True
		elif q == '_' or m == '@' or m == '$':
			b = True
		else:
			return False
			
	If k >= 8 and c and a and b:
		return True
		



#print output

print ("Function1 returns "+ str(end_begin_other("abc","aBCabXabc")))
print ("Function2 returns "+ str(valid_password("ASDF12@23")))


