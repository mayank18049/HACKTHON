#midterms lab exam set 2 -2018
#name-abhishek rana
#roll number: 2018325
#section: b
#group: 6
#date: 23/09/2018
#you need to implement both the functions given in this module.
#function 1
def end_begain_other(s1,s2):
	x=len(s1)
	y=len(s2)
	a=s1.casefold()
	b=s2.casefold()
	if b.find(a)==0 or b.endswith(a):
		return True
	elif a.find(b)==0 or a.endswith(b):
		return True
	else:
		return False
#function2
def valid_password(s3):
	a=len(s3)
	if a<8:
		return False
	elif a<8 and a.isalpha()==True:
		return False
	elif a<8 and a.digit()==True:
		return False
	else:
		return True

#print output
print("function1 returns" + str(end_begain_other("abc,aBCabXabc")))
print("function2 returns" + str(valid_password("ASDF12@23")))


