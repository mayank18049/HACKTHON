#Midterm Lab Exam Set 2 - 2018
#Name: Shivang Saigal
#Roll Number:2018310
#Section:B
#Group:07
#Date:23/09/2018
def end_begin_other(s1,s2):
	s1=str(s1)
	s2=str(s2)
	s1=s1.lower()
	s2=s2.lower()

	if (s1[0:3]==s2):
		return True
	elif(s1[-3:]==s2):
		return True
	elif (s2[0:3]==s1):
		return True
	elif (s2[-3:]==s1):
		return True
	else:
		return False


print("Function1 returns " + str(end_begin_other("abc,aBCabXabc")))

def valid_password(s3):
	SH=False
	XY=False
	ZX=False
	a=len(s3)
	if a>=8:
		for i in s3:
			if i.isupper()==True:
				SH=True
			if i.isalpha()==True:
				XY=True
			if i.isdigit()==True:
				ZX=True
		if XY==ZX==SH==True:
			return True
	else:
		return False

print("Function2 returns " + str(valid_password("ASDF12@23")))









