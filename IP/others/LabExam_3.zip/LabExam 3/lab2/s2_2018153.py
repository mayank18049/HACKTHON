# Midterm Lab Exam Set 2 - 2018
# Name:Kartikeya Gupta
# Roll Number:2018153
# Section:A
# Group:1
# Date:23-09-2018

def end_begin_other(s1,s2):
    l1 = len(s1)
    l2 = len(s2)
    if l1 == l2:
        if s1.lower() == s2.lower():
            return True
        else:
            return False
    if l1 > l2:
        if (s1[0:l2].lower() == s2.lower() and (s1[-l2:-1].lower+s1[-1]).lower() == s2.lower()):
            return True
        else:
            return False
    if l1 < l2:
        if (s2[0:l1].lower() == s1.lower() and (s2[-l1:-1].lower()+s2[-1]).lower()) == s1.lower():
            return True
        else:
            return False
        
def valid_password(s3):
    l = len(s3)
    if l >= 8:
        for i in range(l):
            if "0"<=s3[i]<="9":
                cnum = 1
            if "A"<=s3[i]<="Z":
                ccap = 1
            if s3[i]=="_" or s3[i]=="@" or s3[i]=="$":
                cspe = 1
    if cnum == 1 and ccap == 1 and cspe == 1:
        return True
    else:
        return False


print ("Function return " + str(end_begin_other("abc","aBCabXabc")))
print ("Function returns " + str(valid_password("ASDF12@23")))
        
