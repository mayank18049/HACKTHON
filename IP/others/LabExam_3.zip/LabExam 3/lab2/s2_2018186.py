#Midterm Lab Exam Set 2 - 2018
#Name: Saksham Dhull
#Roll number:2018186
#Section: A
#Group: 2
#Date: 23.09.2018

def end_begin_other(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	l1=len(s1)
	l2=len(s2)
	if l1>=l2:
		d=s1.rfind(s2)
		a=s1[d:]
		d1=s1.find(s2)
		if a==s2 and d1==0:
			v=True
		else:
			v=False
	else:
		d=s2.rfind(s1)
		a=s2[d:]
		d1=s2.find(s1)
		if a==s1 and d1==0:
			v=True
		else:
			v=False
	return v


def valid_password(s3):
	count=0
	if len(s3)>=8:
		for i in range (64,90):
			i=chr(i)
			find=s3.count(i)
			count=count+find
		if count>=1:
			for d in range(0,9):
				find1=s3.count("d")
				count1=count+find1
			if count1>=1:
				f=s3.find("_")
				g=s3.find("@")
				h=s3.find("$")
				if f==-1 and g==-1 and h==-1:
					r=False
				else:
					r=True
			else:
				r=False

		else:
			r=False

	else:
		r=False
	return r
print("Function1 returns"+" "+str(end_begin_other("abc","aBCabXabc")))
print("Function2 returns"+" "+str(valid_password("ASDF12@23")))












