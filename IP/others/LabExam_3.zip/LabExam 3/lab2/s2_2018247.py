#Midterm Lab Exam Set 2- 2018
#Name: Nandesh Singhal
#Roll Number: 2018247
#Section: B
#Group: 8
#Date: 23/09/2018

#function1
def end_begin_other(s1,s2):
	if len(s1)>len(s2):
		str1=s1[:len(s2)].lower()
		str2=s1[len(s1)-len(s2):].lower()
		s2=s2.lower()
		if str1==s2 and str2==s2:
			return True
		else:
			return False
	else:
		str1=s2[:len(s1)].lower()
		str2=s2[len(s2)-len(s1):].lower()
		s1=s1.lower()
		if str1==s1 and str2==s1:
			return True
		else:
			return False

#function2
def valid_password(s3):
	flag1=0
	flag2=0
	flag3=0
	if len(s3)>=8:
		for i in s3:
			if i.isupper():
				flag1=1
			if i.isdigit():
				flag2=1
			if i=='_' or i=='@' or i=='$':
				flag3=1 
	else:
		return False
	if flag1==0 or flag2==0 or flag3==0:
		return False
	else:
		return True
#print output
print('Function1 returns'+ str(end_begin_other('abc','aBCabXabc')))
print('FUnction2 returns'+ str(valid_password('ASDF12@123')))

		
