#mirriam phiri roll number 2018050
def end_begin_other(s1='ACD',s2='tseacd'):
s1=list[0:3]
s2=list[o:6]
if s1[0:3]==s2[3:6]:
	print(str(s1 + s2))
else:
	print(false)



def valid_password('jeNara3@'):
y=list['jeNara3@']
if len(y)>=8:
for int in range(0,9):
	print (int>2<4)







