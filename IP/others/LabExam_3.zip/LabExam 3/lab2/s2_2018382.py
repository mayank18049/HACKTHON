"""
Mid sem lab exam set 2
Name: Anmol Kumar
Roll no. 2018382
Section: B
Group:7
Date: 23-09-2018
"""

import string

def end_begin_other(s1, s2):
	len1=len(s1)
	len2=len(s2)
	s1=s1.lower()
	s2=s2.lower()
	if( s1[0:len2]==s2 and s1[(len1-len2):]==s2 or s2[0:len1]==s1 and s2[(len2-len1):]==s1):
		return True
	else:
		return False

def valid_password(s3):
	if len(s3)>=8:
		a=0
		caps=0
		num=0
		sym=0
		for i in s3:
			if i in string.letters:
				a=1 
			if i in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
				caps=caps+1
			elif i in "0123456789":
				num=num+1
			elif i in "_@$":
				sym=sym+1
		if ( a==1 and caps>0 and num>0 and sym>0):
			return True
		else:
			return False




print("Function1 returns" + str(end_begin_other("abc","aBCabAabc")))
print("Function2 returns" + str(valid_password("ASDF12@23")))
