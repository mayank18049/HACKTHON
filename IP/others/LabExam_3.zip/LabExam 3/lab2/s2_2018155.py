#Lavanya Verma
#2018155
#Section A3

def end_begin_other(s1,s2) :
	s1=s1.lower()
	s2=s2.lower()
	if len(s1)>len(s2):
		m2=len(s2)
		nstart=s1[:m2]
		m1=len(s1)
		nend = s1[m1-m2:]
		if nstart==s2 or nend==s2:
			return True
		else:
			return False
	elif s1==s2:
		return True
	elif len(s2)>len(s1):
		m1=len(s1)
		m2=len(s2)
		nstart=s2[:m1]
		nend=s2[m2-m1:]
		if nstart==s1 or nend==s1:
			return True
		else:
			return False
	else :
		return False 
def valid_password(s3):
	l=len(s3)
	if l<8 :
		return False
	if not ('A' in s3 or 'B' in s3 or "C" in s3 or 'D' in s3 or 'E' in s3 or 'F' in s3 or "G" in s3 or 'H' in s3 or 'I' in s3 or 'J' in s3 or "K" in s3 or 'L'in s3 or "M" in s3 or "N" in s3 or "O" in s3 or "P" in s3 or 'Q' in s3 or 'R' in s3 or 'S' in s3 or 'T' in s3 or 'U' in s3 or 'V' in s3 or 'W' in s3 or 'X' in s3 or "Y" in s3 or "Z" in s3 ):
		return False
	if not( '1' in s3 or '2' in s3 or '3' in s3 or '4' in s3 or '5' in s3 or '6' in s3 or '7' in s3 or '8' in s3 or '9' in s3 or '0' in s3):
		return False
	if not ('_' in s3 or '@' in s3 or '$' in s3 ):
		return False
	return True
		
		
