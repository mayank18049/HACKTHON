# Midterm Lab Exam Set 1 -2018
# Name: Himanshu Yadav
# Roll Number: 2018286
# Section: B
# Group: 7
# Date: 23 sep 2018
# You need to implement both the functions given in this module.
#function1
def end_begin_other(s1,s2):

	a=s1.lower()
	b=s2.lower()
	l1=len(s1)
	l2=len(s2)
	if a.find(b)==(l1-l2) or a.find(b)==0:
		return True
	elif b.find(a)==(l2-l1) or b.find(a)==0:
		return True
	else:
		return False


#function2
def valid_password(s3):
	h1 = False
	h2 = False
	h3 = False


	if len(s3) >= 8:
		for c in s3:
			if c.isdigit():
				h1=True

				if ('A'<=c<='Z'):
					h2=True

					if(c=='_'or c=='$' or c=='@'):
						h3=True
		if (h1 and h2 and h3):
			return True 


	return False	



print("Function1 returns "+str(end_begin_other("abc","aBcabXabc")))
print("function2 returns "+str(valid_password("ASDF12@23")))					