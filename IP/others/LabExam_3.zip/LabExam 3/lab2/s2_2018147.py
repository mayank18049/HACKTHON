"""NAME=HIMANSHU
ROLL NO 2018147
GROUP NO. 3
SECTION A"""
#function1
def end_begin_other(s1,s2):
	if len(s1)>len(s2):
		a=s1[:3]
		b=s1[-1:-4]
		a.lower()
		b.lower()
		if a==s2 and b==s2:
			return True
		else:
			return False
	else:
		a=s2[:3]
		b=s2[-1:-4]
		a.lower()
		b.lower()
		if a==s1 and b==s1:
			return True
		else:
			return False
#function2
def valid_password(s3):
	if len(s3)<8 :
		return False
	else:
		a= True
	for i in range(len(s3)):
		if s3[i].isalpha() :
			c=True
	n=0
	for s in s3:
		s.isupper()
		n=n+1
	if n==0 :
		return False
	else:
		d=True
	t=0
	for s in s3:
		s.isdigit()
		t=t+1
	if t==0 :
		return False
	else:
		j=True
	u=0
	for s in s3:
		if s=='_' or s=='@' or s=='$' :
			u=u+1
	
	if u==0 :
		return False
	else:
		g=True
	if g and a and d and j and c :
		return True
print("Function1 return"


