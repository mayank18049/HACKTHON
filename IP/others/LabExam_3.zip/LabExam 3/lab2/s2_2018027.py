#Midterm Lab Exam Set 2 - 2018
#Name: Atul Verma
#Roll Number: 2018027
#Section: A
#Group: 3
#Date: 23/09/2018

#function1

def end_begin_other(s1,s2):
	"""Returns True if either of the strings appear at the very end and at the very beginning of thr other string, ignoring upper/lower cxase differences, i.e., computation is case-insensitive. Else returns False."""
	#LENGTH OF STRING s1
	l1=len(s1)
	#LENGTH OF STRING s2
	l2=len(s2)
	if l2>l1:
		if s1.lower()==s2[:l1].lower() and s1.lower()==s2[l2-l1:].lower():
			return True
		else:
			return False		
	else:
		if s2.lower()==s1[:l1].lower() and s2.lower()==s1[l1-l2:].lower():
			return True
		else:
			return False

#function2

def valid_password(s3):
	"""Returns True when password is valid and False otherwise."""
	if len(s3)<8:
		return False
	else:
		countdigit=0
		countcaps=0
		countspecial=0
		for i in s3:
			if i.isdigit():
				countdigit+=1
			if i.isalpha():
				if i.isupper():
					countcaps+=1
			elif i in ('_','$','@'):
				countspecial+=1
		if countcaps>0 and countspecial>0 and countdigit>0:
			return True
		else:
			return False

#print output
print("Function1 returns " + str(end_begin_other("abc","aBCabXabc")))
print("Function2 returns " + str(valid_password("ASDF12@23")))