# Midterm Lab Exam Set 2 - 2018
# Name: Pranav Sharma
# Roll Number: 2018169
# Section: A
# Group: 1
# Date: 23/09/2018

#function1
def end_begin_other(s1,s2):
	if(len(s1)>len(s2)):
		return s1[-len(s2):].upper()==s2.upper()
	else:
		return s2[-len(s1):].upper()==s1.upper()

#function2
def valid_password(s3):
	p1=p2=p3=p4=0
	for i in range(len(s3)):
		if(ord(s3[i]) in range(ord("A"),ord("Z")+1)):
			p1+=1
		elif(ord(s3[i]) in range(ord("0"),ord("9")+1)):
			p2+=1
		elif(ord(s3[i]) in (ord("_"),ord("@"),ord("$"))):
			p3+=1
		else:
			p4+=1
	if(p4>0 or min(p1,p2,p3)==0 or len(s3)<8):
		return False
	else:
		return True

#print output
print("Function1 returns " + str(end_begin_other("abc","aBCabXabc")))
print("Function2 returns " + str(valid_password("ASDF12@23")))