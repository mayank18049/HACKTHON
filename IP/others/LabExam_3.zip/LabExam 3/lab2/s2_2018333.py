#Midterm Lab Exam Set 2 - 2018
#Name: Bhavya Chopra
#Roll Number: 2018333
#Section: B
#Group: 6
#Date: 23-SEPTEMBER-2018


#function1
def end_begin_other(s1,s2):
	l1 = len(s1)
	l2 = len(s2)
	if l1>l2:
		if s1[0:l2].lower()==s2.lower() and s1[-l2:].lower()==s2.lower():	#checks if s2 is present at beginning and end of s1
			return True
		else:
			return False
	elif l2>l1:
		if s2[0:l1].lower()==s1.lower() and s2[-l1:].lower()==s1.lower():	#checks if s1 is present at beginning and end of s2
			return True
		else:
			return False

#function2
def valid_password(s3):
	l3 = len(s3)
	length_flag = 0
	allowed_alphabets = 0
	count_ucase = 0
	count_digit = 0
	count_splch = 0
	if l3>=8:																							#checks if length of password is sufficient 
			length_flag = 1
	for i in s3:
		if 65<=ord(i)<=90:																				#Checks if capital letter is present
			count_ucase+=1
		if 48<=ord(i)<=57:																				#checks if a digit is present
			count_digit+=1
		if i=='_' or i=='@' or i=='$':																	#checks if either of ! or @ or $ is present
			count_splch+=1
		if 65<=ord(i)<=90 or 48<=ord(i)<=57 or i=='_' or i=='@' or i=='$' or 97<=ord(i)<=122:			#checks that only valid characters are used
			allowed_alphabets+=1
		else:
			allowed_alphabets=0
	if allowed_alphabets==l3 and length_flag and count_ucase>=1 and count_digit>=1 and count_splch>=1:	#checks if all the given conditions are met or not
		return True
	else:
		return False

#print output
print("Function1 returns " + str(end_begin_other("abc","aBCabXabc")))
print("Function2 returns " + str(valid_password("ASDF12@23")))


