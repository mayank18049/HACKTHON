def end_begin_other(s1,s2):
	if len(s1) >= len(s2):
		x=s2[:].lower()
		y=s1[:len(s2)].lower()
		z=s1[:len(s2):-1].lower()
		if y==x or z==x:
			return ('True')
		else:
			return('False')
	else:
		x=s1[:].lower()
		y=s2[:len(s1)].lower()
		z=s2[:len(s1):-1].lower()
		if y==x or z==x:
			return ('True')
		else:
			return('False')


def valid_password(s3):
	count = 0
	a = s3[0]
	if len(s3)>=8 and a==a.upper() and 0<=a<=9 and (a=="_" or a == "@" or a == "$"):
		while a == str(a).upper() and 0<=a<=9 and (a=="_" or a == "@" or a == "$"):
			a= s3[count+1]
			return('True')
	else:
		return('False')
if __name__ == '__main__':
#	print(end_begin_other("ABCHiabc","abc"))
#	print(end_begin_other("ABC","ABCHiabc"))
#	print(end_begin_other("abc","abcabXabc"))
#	print(end_begin_other("abc","aCCabXabc"))
	print(valid_password("aaac1@sd"))
	print(valid_password("ASDF12@23"))
	print(valid_password("cope1234"))
#	print("Function1 returns " + str(end_begin_other("abc,aBCabXabc")))
#	print("Function2 returns" + str (valid_password("ASDF12@23")))