#Midterm Lab Exam set 2 - 2018
#Name: Sonali Supriya
#Roll no: 2018318
#Section: B
#Group: 7
#Date: 23-09-18
from math import *
def end_begin_other(s1,s2):
	x = "abc" or "ABC" or "Abc" or "aBc" or "abC" or "ABc" or "aBC" or "AbC"
	a = s1.find(x)
	b = s1.rfind(x)
	c = s2.find(x)
	d = s2.rfind(x)
	if ( s1[:3] == a ) and ( s1[:3:-1] == b ) and ( s2[:3] == c ) and (s2[:3:-1] == d ) :
		print (True)
	else :
		print (False)

def valid_password(s3):
	x = ASCII(s3) >=45 and ASCII(s3)<= 54
	y = "_" or "@" or "$"
	if len(s3) == 8 :
		if (ASCII(s3) >= 60 and ASCII(s3) <=85) or (ASCII(s3) >= 97 and ASCII(s3) <= 122):
			if s3.find(x) == x :
				if s3.find(y) == y :
					print ("valid")
	else :
		print (False)
