#Midterm Lab Exam Set 2 - 2018
#Name: RAHUL KUKREJA
#Roll Number:2018254
#Section: B
#Group: 7
#Date: 23/09/2018
import string

def end_begin_other(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	n1=len(s1)
	n2=len(s2)
	if n1>n2:
		if (s1[0:n2]==s2 and s1[-n2:]==s2):
			return True
		else:
			return False	
	if n2>n1:
		if (s2[0:n1]==s1 and s2[-n1:]==s1):
			return True
		else:
			return False	

#end_begin_other('AbCHiabc','abc')
#end_begin_other('AbC','ABCHiabC')
#end_begin_other('abc','aCCabXabc')


def valid_password(s3):
	c=0
	x=0
	y=0
	n3=len(s3)
	a1='_'
	a2='@'
	a3='$'
	if n3>=8:
		c=c+1
	for k in s3:
		if k.isalpha():
			if k.isupper():
				x=x+1
		if k.isdigit():
			y=y+1
	if x>=1 and y>=1:
		c=c+1
	if (a1 in s3) or (a2 in s3) or (a3 in s3):
		c=c+1

	if c==3:
		return True
	else:
		return False


#valid_password('aaac1@SD')
#valid_password('cope1234')
print('Function1 returns '+ str(end_begin_other('abc','aBCabXabc')))


print('Function2 returns '+ str(valid_password('ASDF12@23')))