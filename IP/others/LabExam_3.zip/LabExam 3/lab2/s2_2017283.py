# Midterm Lab Exam Set 2 - 2018
# Name: ASHISH TEEGALAPALLY
# Roll Number: 2017283
# Section: B
# Group: 6
# Date: 23/09/18

#function1
def end_begin_other(s1,s2):
	a=len(s1)
	b=len(s2)
	if a<b:
		if (s1 in s2[:a]) and (s1 in s2[b-a:]):
			return True
		else:
			return False
	elif b<a:
		if (s2 in s1[:b]) and (s2 in s1[a-b:]):
			return True
		else:
			return False
	


#function2
def valid_password(s3):
	l=len(s3)
	a=0
	b=0
	c=0
	if l>=8:
		for x in s3:
			if x.isupper():
				a=1
		for x in s3:
			if x.isdigit():
				b=1
		for x in s3:
			if (x=='_') or (x== '@') or (x=='$'):
				c=1
		if (a==1) and (b==1) and (c==1):
			return True
		else: 
			return False	
	else:
		return False






 

print("Function1 returns "+str(end_begin_other("abc",'abcabXabc')))
print("Function2 returns "+str(valid_password("ASDF12@23")))