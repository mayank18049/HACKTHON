#Midterm Lab Exam Set 2 - 2018
#Name : Pidatala Anvesh Kiran
#Roll n.o : 2018066
#Section : A
#Group : 2
#date : 23-09-2018


#function 1:


def end_begin_other(s1,s2):
    s1=str(s1)
    s2=str(s2)
    l1=len(s1)
    l2=len(s2)
    s1=s1.lower()
    s2=s2.lower()
    if l1>l2 :
        if s1[-l2:]==s2 and s1[:l2]==s2:
            return"True"
        else:
            return"False"
    if l1<l2 :
        if s2[-l1:]==s1 and s2[:l1]==s1:
            return"True"
        else:
            return"False"
    if l1==l2 :
        if s1==s2:
            return"True"
        else:
            return"False"
        

#function 2:
        
def valid_password(s3):
    s3=str(s3)
    n=range(97,123)
    m=range(65,91)
    p=range(48,58)
    if len(s3)==8 :
        for c in s3:
            if c==chr(n) and c==chr(m) and c==chr(p) and (c==chr(95) or c==chr(64) or c==chr(36)) :
                return "True"
            if c==chr(m) and c==chr(p) and (c==chr(95) or c==chr(64) or c==chr(36)) :
                return "True"
            else :
                return "False"
    else :
        return "False"











        

