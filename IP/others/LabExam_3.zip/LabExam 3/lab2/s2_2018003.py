# Midterm Lab Exam Set 2 - 2018
# Name: Abhinav Suresh Ennazhiyil
# Roll Number: 2018003
# Section: A
# Group: 3
# Date 22/09/2018

#function1
def end_begin_other(s1,s2):
	if len(s1)>len(s2):
		a1 = s1.upper()
		a2 = s2.upper()
	else:
		a1 = s2.upper()
		a2 = s1.upper()
	if a1.find(a2)==0 and a1[-len(a2):]==a2:
		return True
	else:
		return False

#function2
def valid_password(s1):
	b1 = len(s1)>=8
	b2 = False
	b3 = False
	b4 = False
	for i in s1:
		if i.isupper():
			b2 = True
		elif i.isdigit():
			b3 = True
		elif i=="_" or i=="@" or i=="$":
			b4 = True
		else:
			return False
	if b1 and b2 and b3 and b4:
		return True
	else:
		return False
print("Function1 returns " + str(end_begin_other("abc","aBCabXabc")))
print("Function2 returns " + str(valid_password("ASDF12@23")))