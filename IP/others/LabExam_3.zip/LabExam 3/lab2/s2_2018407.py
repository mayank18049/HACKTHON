#Midterm lab exam set2
#Name: Ritvik Gupta
#roll. no: 2018407
#Section:B
#Group: 8
#DAte: 23/09/18

def end_begin_other(s1,s2):
	x=str(s1)
	y=str(s2)
	a=len(x)
	b=len(y)
	if y==x[:a] or y==x[(b-a):]:
		return(True)
	elif x==y[:b] or x==y[(a-b):]:
		return(True)
	else:
		return(False)


def valid_password(s3):
	h=str(s3)
	k=h.count('_')+h.count('@')+h.count('$')
	if len(h)>7 and h.islower()==True and h.isupper()==True and h.isdigit()==True and (k>0) :
		return(True)
	else:
		return(False)

print('Function1 returns'+str(end_begin_other('abc','aBCabXabc')))
print('Function2 returns'+str(valid_password('ASDF12@23')))


	
