#Midterm Lab Exam Set 2 - 2018
#Name:Pragya Gandhi
#Roll Number:2018357
#Section:B
#Group:6
#Date:23.09.2018
s1=input()
s2=input()
a=str(s1)
b=str(s2)
x=len(s1)
y=len(s2)
def end_begin_other(s1,s2):
	if x < y:
		if s1 == a[:b] + a[y+1:x-(y+1)] + a[b:]:
			print("True")
	elif y>x:
		if s2==b[:a]+s[x+1:y-(x+1)]+b[a:]:
			print("True")
		else:
			print("False")
end_begin_other(s1,s2)

s3=input()
t=str(s3)
x=len(t)
def valid_password(s3):
	if x>8:
		a=t.isalnum()
		b=t.find("_" or "@" or "$")
		if a and b:
			print("True")
		else:
			print("False")
valid_password(s3)