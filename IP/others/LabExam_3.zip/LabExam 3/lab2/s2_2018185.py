#name=sahil yadav
#roll no.=2018185

def end_begin_other(s1,s2):
 x1=len(s1)
 x2=len(s2)
 if (x1>x2):
    for i in range(x2-1):
        if (s2[i]==s1[x1-x2+i]):
           print("True")
        else:
           print("False")
 else:
    for i in range(x2-x1+i):
        if s1[i]==s2[x2-x1+i])
           print("True")
        else:
           print("False")

def valid_password(s3):
 x=len(s3)
 if (x>=8):
      for i in range(x):
          if(s3[i].isupper()):
              if(s3[i].islower()):
                 if(s3[i].isdigit()):
                    if(s3[i]=="_"or s3[i]=="@"or s3[i]=="$"):
                        print("True")
 else:
     print("False")         
