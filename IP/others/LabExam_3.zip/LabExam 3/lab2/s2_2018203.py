#Midterm Lab Exam set 2 - 2018
#Name - Varun Kumar
#Roll Number - 2018203
#Section - A
#Group - 3
#Date - 23/09/18
#function1
def end_begin_other(s1,s2):
	s1=s2.isupper
	s1=s2.islower
	n=s1.find(s2)
	



#function2
def valid_password(s3):
	if((len(s3)>=8) and (isalpha(s3)>=a and isalpha(s3)<=z)):
		if((s3==isalphanum(s3)) and s3==isupper(s3)):
			return true
	else:
		return false
print("function2 returns " + str(end_begin_other("abc,aBCabXabc")))
print("function2 returns " + str(valid_password("ASDF12@23")))