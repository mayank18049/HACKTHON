#name = Ramesh
#roll no = 2018081
#SECTION = A
#GROUP = 1
	
#Function2
def valid_password(s3):
	n = len(s3)
	if n>=8:
		if s3.isalpha():
			if s3.uppercase():
				if s3.isdigit():
					if s3.find([_ or @ or $):
						return True
else:
	return False
	
print("Function2 returns " + str(valid_password("ASDF12@23")))


#function1 
def end_begin_other(s1,s2):
	if s1.endswith(s2):
		return True
	if s1.startswith(s2):
		return True
	if s2.endswith(s1):
		return True
	if s2.startswith(s1):
		return True
	else:
		return False
		
