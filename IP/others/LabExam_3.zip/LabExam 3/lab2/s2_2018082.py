#Midterm Lab Exam Set 2 - 2018
# Name : Rhythm Gupta
# Roll No : 2018082
# Section : A
# Group : 2
# Date : 23/9/2018
#function1
def end_begin_other(s1,s2):
	a = s1.lower()
	b = s2.lower()
	
	if  len(b) > len(a):
		a,b = b,a
	m = len(a)
	n = len(b)
	k = a.find(b)
	if k<0:
		return(False)
	else:
		j = a.find(b,k+1)
		if k == 0 and j == (m-n):
			return(True)
		else:
			return(False)
#function2
def valid_password(s3):
	if len(s3) > 7:
		if s3.find('_') > 0 or s3.find('@') or s3.find('$'):
			g = 0
			for i in s3:
				if 'A'<=i<='Z':
					g = 1
			if g == 1:
				k = 0
				for i in s3:
					if '0'<=i<='9':
						k = 1
				if k == 1:
					return(True)
	else :
		return(False)

#print output
print("Function1 returns " + str(end_begin_other("abc","aBCabXabc")))

print("Function2 returns " + str(valid_password("ASDF12@23")))
				


	
