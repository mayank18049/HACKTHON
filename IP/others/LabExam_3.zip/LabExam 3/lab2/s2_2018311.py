#midterm lab exam set-2 2018
#name-Shourya Pathak
#roll number: 2018311
#section:B
#group:8
#date:23-09-18

#function 1


def end_begin_other('s1,s2):			
	a=len('s1')
	b=len('s2')
	if a>b:
		a=int(s2.find(s1))
		if a!=-1:
			print('true')
	elif b>a:
		b=int(s1.find(s2))
		if b!=-1:
			print('true')
		
	
	else:
		return true 
		print('true')
    





















#function2
  
def valid_password(s3):
	k=len(s3)
  for i in range (0,len(s3))
		if s3[i]=='$,

