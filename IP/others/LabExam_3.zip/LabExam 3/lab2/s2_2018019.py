# name - ankit mishra
#roll no. 2018019
#section - A
#group - 3
def end_begin_other(s1,s2):
	l1 = len(s1)
	l2 = len(s2)
	s1 = s1.lower()
	s2 = s2.lower()
	if(l1>l2):
		if(s1[-(l2):]== s2 and s1[:l2]== s2):
			return True
	if(l2>l1):
		if(s2[-(l1):]== s1 and s2[:l1]== s1):
			return True
	if(l1==l2):
		if(s1==s2):
			return True
	else:
		return False

def valid_password(s3):
	l3 = len(s3)
	x =0
	y=0
	z=0
	if(l3>=8):
		for i in range(l3):
			if(s3[i]== '_' or s3[i]== '@' or s3[i]=="$"):
				x+=1
			if(s3[i].isalpha()==True):
				if(s3[i].isupper()==True):
					z+=1
			if(s3[i].isdigit()==True):
				y+=1
	if(x>0 and y>0 and z>0):
		return True
	else:
		return False

x = input().split()
y = input()
print("Function1 returns "+str(end_begin_other(x[0],x[1]))) 
print('Function2 returns '+str(valid_password(y)))