#Midterm Lab Exam Set 2 - 2018
#Name: Nitish Gupta
#Roll Number: 2018351
#Section: B
#Group: 8
#Date: September 23, 2018


import string


#function1
def end_begin_other(s1,s2):
	l1 = len(s1)
	l2 = len(s2)
	m1 = (s1[-1:-(l2+1):-1])[-1::-1]
	m2 = (s2[-1:-(l1+1):-1])[-1::-1]
	if (s1[0:l2].lower()==s2.lower() and m1.lower()==s2.lower()) or (s2[0:l1].lower()==s1.lower() and m2.lower()==s1.lower()):
		return True
	else:
		return False
#a = end_begin_other("ABC","AbCabXabc")
#b = end_begin_other("AbCHiabc","abc")
#c = end_begin_other("abc", "abc")
#d = end_begin_other("abc", "aCCabXabc")
#print (a) --- True
#print (b) --- True
#print (c) --- True
#print (d) --- False


#function2
def valid_password(s3):
	j=0
	k=0
	l=0
	h=0
	if len(s3)>=8:
		for i in s3:
			if i in string.ascii_letters:
				h+=1
			if i in string.ascii_uppercase:
				j+=1
			if i.isdigit()==True:
				k+=1
			if i in "_" or i in "$" or i in "@":
				l+=1
		if j>0 and k>0 and l>0 and h>0:
			return True
		else:
			return False
	else:
		return False
#print(valid_password("aaaac1@SD")) --- True
#print(valid_password("cope1234")) --- False


#print output
print ("Function returns " + str(end_begin_other("abc","aBCabXabc")))
print ("Function returns " + str(valid_password("ASDF12@23")))
	
