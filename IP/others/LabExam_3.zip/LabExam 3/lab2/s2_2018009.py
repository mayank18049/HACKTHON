#name:ajit singh
#section:a
#roll no:2018009
#group no:1
#midterm lab exam set 2
#function1 
def end_begin_other(str1,str2):
	lenstr1=len(str1)
	lenstr2=len(str2)
	str1=str1.upper()
	str2=str2.upper()
	if lenstr1>lenstr2:
		flag1=str1.find(str2)
		flg2=str1.rfind(str2,flag1)
		if flag1==0 and flag2==lenstr1-lenstr2:
			return True
		else :
			return False
	if lenstr2>lenstr1:
		flag1=str2.find(str1)
		flag2=str2.rfind(str1,flag1)
		if flag1==0 and flag2==lenstr2-lenstr1:
			return True
		else :
			return False

print('Function1 returns '+str(end_begin_other("abc","aBCabXabc")))


#function2
def valid_password(str3):
	lenstr3=len(str3)
	upcnt=0
	digitcnt=0
	lowcnt=0
	speclcnt=0
	avoidchar=0
	for i in range(lenstr3):
		if str3[i].islower():
			lowcnt=lowcnt+1
		if 	str3[i].isupper():
			upcnt=upcnt+1
		if str3[i]>='0' and str3[i]<='9':
			digitcnt=digitcnt+1
		if str3[i]=='_' or str3[i]=='@' or str3[i]=='$':
			speclcnt=speclcnt+1
		else:
			avoidchar=1	
	if upcnt!=0 and digitcnt!=0 and speclcnt!=0 and lenstr3>=8:
		return True
	else :
		return False
print('function2 returns '+ str(valid_password("ASDF12@23")))				


