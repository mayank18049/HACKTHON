#Akash Sarkar

def end_begin_other(s1,s2):
      x=s1.lower()
      y=s2.lower()
      if(len(x)>len(y)):
          if((x.find(y)==0) or (x.find(y)==len(x)-1)):
                return True
          else:
                return False
      else:
          if((y.find(x)==0) or (y.find(x)==len(x)-1)):
                return True
          else:
                return False
def valid_password(s3):
     if((len(s3)>=8):
           for i in range (0,len(s3)-1):
                  if( (isdigit(i)==0) or (isupper[i]==0) or (s3[i]=='_') or (s3[i]=='@') or (s3[i]=='$'))
                        return True
                  else:
                        return False
                     

