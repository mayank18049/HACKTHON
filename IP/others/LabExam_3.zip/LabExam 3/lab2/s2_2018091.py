# MidTerm Lab Exam Set 2 - 2018
# Name : Sanchit Trivedi
# Roll Number : 2018091
# Section : A
# Group : 3
# Date : 23 September 2018

# Function 1
def end_begin_other(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	s1r=s1[::-1]
	s2r=s2[::-1]
	if s1.find(s2)==0 and s1r.find(s2r)==0:
		return True
	elif s2.find(s1)==0 and s2r.find(s1r)==0:
		return True
	else:
		return False

# Function 2
def valid_password(s3):
	if len(s3)>=8 :
		c1=0
		c2=0
		c3=0
		c4=0
		for i in s3:
			if i.isalpha():
				c1+=1
			if i.isupper():
				c2+=1
			if i.isdigit():
				c3+=1
			if i in '_@$':
				c4+=1
		if c1!=0 and c2!=0 and c3!=0 and c4!=0:
			return True
		else :
			return False
	else:
		return False

# OUTPUT

print('Function1 returns '+str(end_begin_other('abc','aBCabXabc')))
print('Function2 returns '+str(valid_password('ASDF12@23')))



