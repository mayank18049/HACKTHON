#Midterm Lab Exam Set 2- 2018
#Name:Shikhar Sheoran
#Roll No:2018099
#Section:A
#Group: 3
#Date: 23/9/2018
#function1
def end_begin_other(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	ls1=len(s1)
	ls2=len(s2)
	if ls1>ls2:
		if s1[:ls2]==s2 and s1[ls1-ls2:]==s2:
			return True
		else:
			return False
	elif ls2>ls1:
		if s2[:ls1]==s1 and s2[ls2-ls1:]==s1:
			return True
		else:
			return False



#function2
def valid_password(s3):
	ls3=len(s3)
	if ls3>=8:
		for i in range(ls3):
			if s3[i].isalpha()==True and (ord(s3[i])>=65 and ord(s3[i])<=90) and (ord(s3[i])>=48 and ord(s3[i])<=57) and (s3[i]=="_" or s3[i]=="@" or s3[i]=="$"):
				return True
			else:
				return False

			
	else:
		return False

#print output
print("Function1 returns " + str(end_begin_other("abc","abCabXabc")))
print("Function2 returns " + str(valid_password("cope1234")))




