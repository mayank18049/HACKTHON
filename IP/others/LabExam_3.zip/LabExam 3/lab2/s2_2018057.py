nikhil dahiya
2018057
A
1
23/9/18


def end_begin_other(s1,s2)
	x=len(s1)
	y=len(s2)
	if(x>y)
		for  in range(y):
			if(s1[i]=s2[i] and s1[x-1-i]=s2[i])
				return True
			else:
				return False
	else:
		for  in range(x):
			if(s2[i]=s1[i] and s2[x-1-i]=s1[i])
				return True
			else:
				return False



def valid_password(s3):
	x=len(s3)
	if(x>=8):
			for i in range(x):
				if(s3[i].isupper()):
					if(s3[i].isdigit()):
						if(s3[i]=='_' or s3[i]=='@' or s3[i]=='$'):
							return True
						else:
							return False
					else:
						return False		
				else:
					return False
	else:
		return False
		


