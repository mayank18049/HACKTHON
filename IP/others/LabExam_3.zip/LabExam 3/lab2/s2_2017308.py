#midterm lab exam set2-2018
# name rakshita anand
# 2017308
#section B
# group 7
#date 23/09/2018
'''
def valid_password(s3):
	i=len(s3)
	for j in range( 0,len(s3)):
		x=s3[j].isupper()
		y=s3[j].isdigit()
		q=s3[j].islower()
		if((i>=8)and(x)and(y)and(z)):
		#if((i>=8)and(q==True)):
			return True
		else:
			return False
print(str(valid_password("gjhgcwkHGJ34KHA")))
'''

'''import string
def valid_password(s3):
	sep=s3.split()

	leng=len(s3)
	print(leng)
	k=s3.find('g')

	#l=s3.find('A' to 'Z')
	#m=s3.find('a' to'z')

	if (s3.isalpha())and(leng>=8)and(k):
		return True

print(str(valid_password("gjhgcwkH01GJKHA")))


def end_begin_other(s,g):
	#k=s1[1]==s2[1]
	#l=s1[2]==s2[2]
	#m=s1[3]==s2[3]
	
	#if((k)and(l)and(m)):
	if((s[0]==g[0])and (s[1]==g[1])and(s[2]==g[2])):
		return True
	else:
		return False
end_begin_other("abchoh","abcjhghabc")

print(str(end_begin_other("abchfdh","abcjkhcrhabc")
'''
def end_begin_other(s,g):
	for i in range(0,3):
		if((s[0]==g[0])and(s[1]==g[1])and(s[2]==g[2])and((s[2]==g[-1])and s[0]==g[-3] and s[1]==g[-2]))or((s[-1]==g[2])and (s[-3]==g[0]) and (s[-2]==g[1]))):
			return True
		else:
			return False


print(end_begin_other("abcfhja","abcjijabc"))





































