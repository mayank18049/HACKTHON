#Midterm Lab Exam Set 2-2018
#Name    : Arnav Kumar
#Roll No.: 2018375
#Section : B
#Group   : 08
#Date    :23/09/2018
#function1

def end_begin_other(s1,s2):
	if len(s1)<len(s2):
		l1=len(s1)
		l2=len(s2)
		str1=l1
		str2=l2
		s1=str1.lower()
		s2=str2.lower()		

#function2
def valid_password(s3):
	"""Returns True when password is valid and False otherwise."""
	l=len(s3)
	if(l<8):
		return False
	



#print output
print("Function1 returns"+str(end_begin_other("abc","aBCabXabc")))
print("Function2 returns"+str(valid_password("ASDF12@23")))
