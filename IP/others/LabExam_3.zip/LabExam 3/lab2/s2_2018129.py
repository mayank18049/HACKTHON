# Midterm Lab Exam Set 2 - 2018
# Name: Anmol Kaushik
# Roll Number: 2018129
# Section: A
# Group: 1
# Date:

#function1

def end_begin_other(s1,s2):
   l=len(s)
   i=0
   s1=(input("enter string1"))
   s2=(input("enter string2"))
   for i in range(0,2):
         if(s1.s2 or s2.s1):
          return 1
         else:
          return 0
print("Function1 returns "+ str(end_begin_other(s1,s2)))



