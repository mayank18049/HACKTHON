#mid term lab exam set 2
#Vrinda Singhal
#2018421
#section B
#group 6




#funtion1
def end_begin_other(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	boo=True
	if s1.startswith(s2):
		if s1.endswith(s2):
			return True
		else: 
			boo=False

	if s2.startswith(s1):
		if s2.endswith(s1):
			return True
		else:
			boo= False
	else:
		return False

	if boo==False:
		return False

#function2
def valid_password(s3):
	special=False
	number=False
	upper_case=False
	if len(s3) > 7:
		for i in s3:
			if i.isdigit():
				number= True
			elif i in "_@$":
				special= True
			elif i.isupper():
				upper_case=True
			elif i.isalpha():
				v=True
			else:
				return False
		if special and number and upper_case:
			return True
		else:
			return False
	else:
		return False


print ("Function1 returns " + str(end_begin_other("abc","aBCsfdsdabc")))
print ("Function2 returns " + str(valid_password("ASDF@1234")))
