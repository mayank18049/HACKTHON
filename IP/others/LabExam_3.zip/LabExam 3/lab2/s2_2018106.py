# Midterm Lab Exam Set 2 - 2018
# NAME : SUMANYU BHATIA
# ROLL NUMBER : 2018106
# SECTION : A
# GROUP : 2
# DATE : 23/09/2018

# function1
def end_begin_other(s1, s2):
	s11 = s1.lower()
	s22 = s2.lower()
	n1 = len(s11)
	n2 = len(s22)
	if (s11[:n2]==s22 and s11[-(n2):]==s22) or (s22[:n1]==s11 and s22[-(n1):]==s11): 
		return True
	else:
		return False

#function2
def valid_password(s3):
	if len(s3)>=8:
		if('_' or '@' or '$') in s3:
			
			for i in range(0, len(s3)):
				if 48<=ord(s3[i])<=57:
		
					for j in range(0, len(s3)):
						if 65<=ord(s3[j])<=90:
							return True
	elif len(s3)>=8:
		if('_' or '@' or '$') in s3:
			
			for i in range(0, len(s3)):
				if 48<=ord(s3[i])<=57:
		
					for j in range(0, len(s3)):
						if 65<=ord(s3[j])<=90:
							
							for k in range(0, len(s3)):
								if ord(s3[k])<=122:
									return True	

	else:
		return False


#print output
print("Function1 returns" + str(end_begin_other("abc", "aBCabXabc")))
print("Function2 returns" + str(valid_password("ASDF12@23")))	




