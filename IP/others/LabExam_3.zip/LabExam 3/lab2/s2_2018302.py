# Midterm Lab Exam Set 2 - 2018
# Name: Rachit Mittal
# Roll Number: 2018302
# Section: B
# Group: 7
# Date: 23/09/2018

#function 1
def end_begin_other(s1,s2):
	x = s1.lower()
	y = s2.lower()
	n = len(x)
	m = len(y)
	if n > m:
		if y == x[:m]:
			b = True
		else:
			b = False
		if y == x[n-m:]:
			c = True
		else:
			c= False
			
	elif n < m:
		if x == y[:n]:
			b = True
		else:
			b = False
		if x == y[m-n:]:
			c = True
		else: 
			c = False
	if n == m:
		if x == y:
			b = True
			c = True
		else:
			b = False
			c = False
	if b and c:
		return True
	else:
		return False


#function 2
def valid_password(s3):
	if len(str(s3))<8:
		return False
	digits = 0
	upper = 0
	special = 0
	alpha = 0
	for i in str(s3):
		if i.isdigit():
			digits +=1
		elif i.isupper():
			upper +=1
		elif i == "_" or i=="@" or i == "$":
			special +=1
		elif i.isalpha():
			alpha +=1
		else:
			return False		
	if digits == 0 or upper == 0 or special == 0:
		return False
	return True	


#print output
print("Function1 returns " + str(end_begin_other("abc","aBCabXabc")))
print("Function2 returns " + str(valid_password("ASDF12@23")))
