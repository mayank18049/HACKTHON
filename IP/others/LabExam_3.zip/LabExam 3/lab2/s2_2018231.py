#Name: Dhruv Umesh
#Roll No: 2018231
#Section: B
#Group: 8
#Date: 23 September 2018
import string
def end_begin_other(s1, s2):
	s1=s1.lower()
	s2=s2.lower()
	if (s1 in s2):
		if(s1[0]==s2[0] or s1[-1]==s2[-1]):
			return True
	else:
		return False
	if (s2 in s1):
		if(s1[0]==s2[0] or s1[-1]==s2[-1]):
			return True
	else:
		return False

def valid_password(s3):
	flag=False
	count_caps=0
	count_digit=0
	count_special=0
	if len(s3)<8:
		return flag
	for a in s3 :
		if(a.isupper()):
			count_caps+=1
		if(a.isdigit()):
			count_digit+=1
		if(a=='_' or a=='@' or a=='$'):
			flag=True
			count_special+=1

	if count_special==0 or count_digit==0 or count_caps==0:
		flag=False

	return flag




print("Function1 returns " + str(end_begin_other("abc", "aBCabXabc")))
print("Function1 returns " + str(valid_password("ASDF12@23")))
