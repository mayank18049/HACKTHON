from string import *
#Midterm Lab Exam Set 2-2018
#Name: Daksh Thapar
#Roll Number: 2018137
#Section: A
#Group: 1
#Date: 23/09/2018

def end_begin_other(s1,s2):
	
	if(len(s1)<len(s2)):
		s1=s1.lower()
		s2=s2.lower()
		

		i=s2.rfind(s1[0])
		j=s2.find(s1[0])
		
		s=s1[-1::-1]
		#s4=s2[-1::-1]
		
		if ((s[0:]==s2[-1:i-1:-1]) or (s1[0:]==s2[0:len(s1)])):
			return True
		else:
			return False

	elif(len(s2)<len(s1)):
		s1=s1.lower()
		s2=s2.lower()
		

		i=s2.rfind(s1[0])
		j=s2.find(s1[0])
			
		s=s2[-1::-1]
		#s4=s2[-1::-1]
			
		if ((s[0:]==s1[-1:i-1:-1]) or (s2[0:]==s1[0:len(s2)])):
			return True
		else:
			return False




#s1="abc"
#s2="abcXAcbac"
#print(end_begin_other(s1,s2))





def valid_password(s3)	:

	flag=0
	flag5=0
	count1=0
	count2=0

	if len(s3)>=8:
		flag+=1



	for i in range(len(s3)):
		#if i.isalpha() and i in "abcdefghijklmnopqrstuvwxyz":
		#	flag+=1
		s3=str(s3)
		if s3[i] in"abcdefghijklmnopqrstuvwxyz":
			count1+=1
			if count1>=1:
				flag+=1

		elif s3[i] in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
			flag5+=1
			flag+=1

		#else s3[i].isupper():
		#			flag5=1


		
		elif s3[i].isdigit():
			count2+=1
			if count2>=1:
				flag+=1
				count2=0

	

		elif s3[i]=='_' or s3[i]=='@' or s3[i]=='$':
			flag+=1

		i+=1

	if flag==len(s3)+1 and flag5>=1:
		return True
	else:
		return False




print("Function1 returns " + str(end_begin_other("abc,aBCabXabc")))

print("Function2 returns " + str(valid_password("ASDF12@23")))

















