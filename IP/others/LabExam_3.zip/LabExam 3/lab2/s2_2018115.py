"""
Midterm eam Lab Exam Set 2 - 2018
Vaibhav Jindal
2018115
Section : A
Group : 3
Date : 23/09/2018
"""
def end_begin_other(a, b):
	a1 = []
	b1 = []
	for i in a:
		a1.append(i.upper())
	for i in b:
		b1.append(i.upper())
	if(len(b1)>len(a1)):
		a1, b1 = b1, a1
	if(a1[len(a1)-len(b1):] == b1 and a1[:len(b1)] == b1):
		return True
	else :
		return False
def valid_password(s3):
	if(len(s3)>=8):
		flaga = 0
		flags = 0
		flagn = 0
		flagm = 0
		for i in s3:
			if ord(i) < 123 and ord(i) >= 97:
				flags += 1
			if ord(i) >=65 and ord(i) < 91:
				flaga += 1
			if i.isdigit() :
				flagn += 1
			if i == '_' or i == '@' or i == '$':
				flagm += 1
		if (flagn > 0 and flaga >0 and flagm > 0):
			return True
		else:
			return False
	else :
		return False	
if __name__ == "__main__":
	print("Function1 returns " + str(end_begin_other("abc", "aBCabXabc")))
	print("Function2 returns " + str(valid_password("ASDF12@23")))