#Midterm Lab Exam Set2
#Kshitiz Singh
#2018154
#Section A
#Group 2
#Date : 23-09-2018
from string import *
def end_begin_other(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	l1=len(s1)
	l2=len(s2)
	if(l1>l2):
		a=l1-l2
		if(s1[0:l2]==s2) and (s1[a:]==s2):
			return True
		else:
			return False
	elif(l2>l1):
		a=l2-l1
		if(s2[0:l1]==s1) and (s2[a:]==s1):
			return True
		else:
			return False

def valid_password(s3):
	l=len(s3)
	if l<8:
		return False
	a=False
	b=False
	c=False
	d=False
	for i in range(0,l):
		if (s3[i]=='_') or (s3[i]=='@') or (s3[i]=='$'):
			a=True

	for i in range(0,l):
		if (s3[i]>'0') and (s3[i]<='9'):
			b=True
		
	for i in range(0,l):
		if (s3[i]>'A') and (s3[i]<='Z'):
			c=True
	for i in range(0,l):
		if(s3[i]>'A') and (s3[i]<'z'):
			d=True
	if a and b and c and d:
		return True
	else:
		return False

print("Function1 returns"+str(end_begin_other("abc","aBCabXabc")))
print("Function2 returns"+str(valid_password("ASDF12@23")))
