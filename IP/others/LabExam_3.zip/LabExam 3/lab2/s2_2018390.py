#Midterm Lab Exam Set 2 -2018
#NAME:GAVISH GUPTA
#ROLL NUMBER:2018390
#SECTION:B
#GROUP:7
#DATE:23/09/2018
from string import *
#FUNCTION 1
def end_begin_other(s1,s2):
	a=len(s1)
	b=len(s2)
	s3=""
	s4=""
	if(a > b):
		s3=s1.lower()
		s4=s2.lower()
		if(s3[:b] == s4 and s3[a-b:] == s4):
			return(True)
		else:
			return(False)
	else : 
		s3=s1.lower()
		s4=s2.lower()
		if(s4[:a] == s3 and s4[b-a:] == s3):
			return(True)
		else:
			return(False)
#FUNCTION 2
def valid_password(s3):
	a=len(s3)
	i=0
	c=0
	d='ABCDEFGHIJKLMNOPQURSTVWXYZ'
	e='0123456789'
	f='_$@'
	if(a >= 8):
		while i<a:
			if(d.find(s3[i]) >= 0 or e.find(s3[i]) >= 0 or f.find(s3[i]) >= 0):
				c=1
			i=i+1

		if(c == 1):
			return(True)
		else:
			return(False)
	else:
		return(False)

#print output
print("Function1 returns " +str(end_begin_other('abc','aBCabXabc')))
print("Function2 returns " +str(valid_password('ASDF12@23')))	
