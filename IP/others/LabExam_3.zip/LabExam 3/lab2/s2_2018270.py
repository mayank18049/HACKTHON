#name - tanmaiy sethia jain
#section b
#roll number 2018270

from string import *


def end_begin_other(s1,s2):
	s1=s1.upper()
	s2=s2.upper()

	n=len(s1)
	x=len(s2)
	if(s2[0:n-1]==s1 and s1[:x-n-1:-1]==s2):
		return bool(1)

	else:
		return bool(0)


flag=0
glag=0
tlag=0
def valid_password(y):

	n=len(y)
	if(n!=8):

		return bool(0) 

	else:
		for t in range(n):
			if(y[t].isupper()):
				flag=1


			if(y[t].isdigit()):
				glag=1

			if(y[t]!=isalnum() and y[t]!=isdigit()):
				tlag=1



	if(flag==1 and tlag==1 and glag==1):
		return bool(1)
	else:
		return bool(0)

	
print('FUnction1 returns ')+str(end_begin_other("abc,abcasdabc)")				
print('Function2 returns ')+ str(valid_password('ASDG12@12')

