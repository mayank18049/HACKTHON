#Midterm Lab Exam Set 2 - 2018
#Name-Anup kumar Jaiswal
#Roll Number:2018131
#Section: A
#Group-3
#Date-23/09/2018
#function1
def end_begin_other(s1,s2):
	b=lower(s1)
	c=lower(s2)
	









def valid_password(s3):
	a = len(s3)
	if a<8:
		return  False
	for i in range(A,Z):
		s=s3.find(i)
		if s=0:
			return False
	for i in range(0,9):
		s=s3.find(0,9)
    
