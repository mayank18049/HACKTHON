#Name - Dipanshu Aggarwal
#Roll Number - 2018139
#Section - A
#Group - 3
#Date - 23/09/2018

def end_begin_other(s1, s2):
	s1 = str(s1.lower())
	s2 = str(s2.lower())
	if s1.find(s2) == 0:
		s1 = s1[::-1]
		s2 = s2[::-1]
		if s1.find(s2) == 0:
			return True
	elif s2.find(s1) == 0:
		s1 = s1[::-1]
		s2 = s2[::-1]
		if s2.find(s1) == 0:
			return True
	return False

def valid_password(s3):
	s3 = str(s3)
	alpha = False
	capalpha = False
	num = False
	spchar = False
	if len(s3) < 8:
		return False
	else:
		for i in range(len(s3)):
			if s3[i].isdigit():
				num = True
			elif s3[i].isalpha():
				alpha = True
				if s3[i] >= 'A' and s3[i] <= 'Z':
					capalpha = True
			elif s3[i] == '_' or s3[i] == '@' or s3[i] == '$':
				spchar = True
		return (num and alpha and capalpha and spchar)
			
print("Function1 returns " + str(end_begin_other("abc","aBCabXabc")))
print("Function2 returns " + str(valid_password("ASDF12@23")))