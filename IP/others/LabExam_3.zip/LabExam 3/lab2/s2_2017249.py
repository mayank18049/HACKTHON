#NIKHIL KUMAR
#2017249
#B-4
def end_begin_other(s1,s2):
	lens1 = len(s1)
	lens2 = len(s2)
	s1 = s1.lower()
	s2 = s2.lower()
	if(lens1>lens2):
		x = s1[:lens2]
		y = s1[-1-lens2+1:]
		#print(x,y)
		if(x==s2 and y == s2):
			return True 
		else:
			return False	
	elif (lens2>lens1):		
		x = s2[:lens1]
		y = s2[-1-lens1+1:]
		#print(x,y)
		if(x == s1 and y == s1):
			return True 
		else:
			return False
def valid_password(s3):
	if(len(s3)<8):
		return False
	else:
		i=0
		if(s3.isalnum()):
			while((s3[i]<'A' or s3[i]>'Z')):
				if(i<len(s3)-1):	
					i=i+1
				else:
					return False
			j=0		
			while(s3[j]!='_' or s3[j]!='@' or s3[j]!='$'):
				if(j<len(s3)-1):	
					j=j+1
				else:
					return False					
	return True				

if __name__ == '__main__':
	print("Function1 returns " + str(end_begin_other("abc","aBCabXabc")))
	print("Function2 returns " + str(valid_password("ASDF12@23")))
	