#Name yashraj
#Roll Number: 2018422
#Section B
#Group 7
#Date 23/09/2018
def end_begin_other(s1,s2):
	y=False
	m=len(s1)
	n=len(s2)
	q=s1.lower()
	w=s2.lower()
	if (m>n):
		if q[:n]==w and q[m-n:]==w :
			y=True
	elif (n>=m) :
		if w[:m]==q and w[n-m:]==q :
			y=True
	return y
def valid_password(s3):
	X=False
	Y=False
	Z=False
	O=False
	for i in s3 :
		if i.isupper()==True :
			X=True
		elif i.isdigit()==True :
			Y=True
		elif (i=='_' or i=='@' or i=='$') :
			Z=True
	if len(s3)>=8 :
		O=True
	return (X and Y and Z and O)
print("Function1 returns " + str(end_begin_other("abc","aBcabXabc")))
print("Function2 returns " + str(valid_password("ASDF12@23")))








