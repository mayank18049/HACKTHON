#Midterm Lab Exam Set 2- 2018
#Name: Arnav Tandon
#Roll Number: 2018278
#Section: B
#Group: 07
#Date: 23/09/2018


#function1
def end_begin_other(s1,s2):
	a=len(s1)
	b=len(s2)
	c=min(a,b)
	s3=s1.lower()
	s4=s2.lower()
	if s3[:c]==s4[:c]:
		return True
	else:
		return False


def valid_password(s3):
	a=len(s3)
	if a>=8:
		c1=0
		c2=0
		c3=0
		c4=0
		for i in range (0,a):
			if s3[i]>='a' and s3[i]<='z':
			 c1=c1+1

			elif s3[i]>='A' and s3[i]<='Z':
			 c2=c2+1

			elif s3[i]>='0' and s3[i]<='9':
			 c3=c3+1

			elif s3[i]== '_'or'@'or'$':
			 c4=c4+1

		if(c1>=1 and c2>=1 and c3>=1 and c4>=1 and c1+c2+c3+c4==a):
			return True
		else:
		    return False
	
	else:
		return False    



print("Function1 returns " + str(end_begin_other("abc","aBCabXabc")))
print("Function2 returns " + str(valid_password("ASDF12@23")))




