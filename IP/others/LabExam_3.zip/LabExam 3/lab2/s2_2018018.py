# mid term lab exam set 2 -2018
#NAME ankit kumar
#Roll.no 2018018
#sec A
#group 2
#Date 23/9/2018
def end_begin_other(s1,s2):
    l=len(s1)
    n=len(s2)
    if((s1.find("s2")==0)and(s1.find("s2")==(l-n))or(s2.find("s1")==0)and(s2.find("s1")==(n-l))):
        return True
    else:
        return False
def valid_password(s3):
    if(((len(s3)>=8)and(s3[0:4].isalpha()))and((s3[4].isdigit())or(s3[4:6].isdigit())or(s[5]=='_')or(s[5]=='@')or(s[5]=='$'))or((s3[4].isdigit())or(s3[4:6].isdigit())or(s[6]=='_')or(s[6]=='@')or(s[6]=='$'))and((s[-1].isdigit())or(s[-1].isdigit())or(s[-2].isalpha())or(s[-2].isalpha()))):
        return True
    else:
        return False

