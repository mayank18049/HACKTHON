"""
RIA GUPTA
2018405
SEC-B
GROUP 6
DATE- 23/09/18




"""
def end_begin_other(s1,s2):
	s1=s1.lower()
	s2=s2.lower()

	p1=len(s1)
	p2=len(s2)

	if p1> p2:
		if s1.find(s2)==0 and s1[p2:].find(s2)== p1-(2*p2) :
			return True
		else:
			return False

	elif p2>p1:
		if s2.find(s1)==0 and s2[p1:].find(s1)==p2-(2*p1) :
			return True
		else:
			return False



x= end_begin_other("abc","AccABxABC")
print(x)



def valid_password(s3):
	if len(s3)>=8 and s3.find("_")>=0 or s3.find("@")>=0 or s3.find("$")>=0 :
		f=0
	else :
		f=1

	if f==0:
		if s3.count("0")>0 or s3.count("1")>0 or s3.count("2")>0 or s3.count("3")>0 or s3.count("4")>0 or s3.count("5")>0 or s3.count("6")>0 or s3.count("7")>0 or s3.count("8")>0 or s3.count("9")>0 :
			f=0
		else :
			f=1

	if f==0:

		for i in s3:
			if ord(i)>=ord('A') and ord(i)<=ord('Z') :
				f=0
			else:
				f=1

	if f==0:		
		return True

	elif f==1 :
		return False

		


y=valid_password("aaac1@SD")
print(y)