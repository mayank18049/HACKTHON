#Midterm Lab Exam Set 2 - 2018
#Name : Navam Sundriyal
#Roll No. : 2018162
#Section : A
#Group : 2
#Date : September 23, 2018


#function 1
def end_begin_other(s1,s2):
	x = len(s1)
	y = len(s2)
	i = abs(x-y)
	s1 = s1.lower()
	s2 = s2.lower()
	if s1[i:]==s2 or s2[i:]==s1 :
		return True
	elif s1[:y]==s2 or s2[:x]==s1 :
		return True
	else :
		return False

#function 2
def valid_password(s3):
	l = len(s3)
	if l >= 8:
		x1 = True
	if '_' in s3 or '@' in s3 or '$' in s3:
		x2 = True
	else:
		x2 = False
	for i in range(0,l):
		if s3[i].isalpha()== True:
			x3 = True
			break
		else :
			x3 = False
	for j in range(0,l):
		if s3[j].isupper()==True :
			x3 = True
			break
		else :
			False
	for k in range(0,l):
		if s3[k].isdigit()==True:
			x4=True
		else :
			x4 = False

	if x1==x2==x3==x4==True :
		return True
	else :
		return False

#print output
print(end_begin_other("AbC", "ABCdesdr"))
print(valid_password('ASDF12@23'))