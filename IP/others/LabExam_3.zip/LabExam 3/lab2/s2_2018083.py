# Midterm Lab Exam Set 2 - 2018
# Name: Rhythmkumar Patel
# Roll Number: 2018083
# Section: A
# Group: 3
# Date: 23 September 2018

#function1 

def end_begin_other(s1,s2):

	s1=s1.lower()
	s2=s2.lower()

	a=s1.rfind(s2)		#finds the occurence of the string s2 in s1 from the end of the string
	b=s2.rfind(s1)

	if ((s1[a:len(s1)]==s2) or (s2[b:len(s2)]==s1)) and ((s1[0:len(s2)]==s2) or (s2[0:len(s1)]==s1)):
		return True
	else:
		return False	

#function2
def valid_password(s3):
	
	a=0
	b=0
	c=0
	if len(s3)>=8:
		for i in s3:
			if i.isupper():
				a=1
			if i.isdigit():
				b=1
			if i=='_' or i=='@' or i=='$':
				c=1	

		if a==1 and b==1 and c==1:
			return True
		else:
			return False	

	else:
		return False

print ("Function1 returns " + str(end_begin_other("abc","aBcabXabc")))
print ("Function2 returns " + str(valid_password("ASDF12@23")))