#Midterm Lab Exam Set 2 -2018
#Name - Tanmay
#Roll Number - 2018271
#Section - B
#Group - 8 
#Date - 23/09/2018

#function1

def end_begin_other(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	flag=True
	
	if len(s1)==len(s2):
		if s1==s2:
			return True
		else:
			return False
	elif len(s1)>len(s2):
		big=s1
		small=s2
	elif len(s2)>len(s1):
		big=s2
		small=s1

	if big.find(small)!=0:
		return False

	big=big[::-1]
	small=small[::-1]

	if big.find(small)!=0:
		return False

	return True

#function2
def valid_password(s3):
	
	#length condition
	if len(s3)<8:
		return False

	#Atleast one uppercase
	Case_flag=False

	for x in s3:
		if x.isupper():
			Case_flag=True
			break

	if not Case_flag:
		return False

	#Atleast one digit
	Num_flag=False

	for x in s3:
		if x.isnumeric():
			Num_flag=True
			break

	if not Num_flag:
		return False

	#Atleast one special chr ie _ or @ or $
	S_flag=False

	for x in s3:
		if x in ('_','@','$'):
			S_flag=True
			break

	if not S_flag:
		return False

	#returns true since all conditions are satisfied
	return True

#print output
print("Function1 returns " + str(end_begin_other("abc","aBCabXabc")))
print("Function2 returns " + str(valid_password("ASDF12@23")))