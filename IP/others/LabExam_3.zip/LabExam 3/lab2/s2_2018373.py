'''Name = Yatharth Chauhan
Section = B
Group = 6
Roll Number = 2018373
System Number = L317-PC43'''


def end_begin_other(s1,s2):
	result = False
	s1=s1.lower()
	s2=s2.lower()
	lenS1=len(s1)
	lenS2=len(s2)
	sEnd = ""
	sBeg = ""
	diff = abs(len(s1)-len(s2))
	if lenS1 >= lenS2:
		sEnd = s1[diff:len(s1)]
		sBeg = s1[0:lenS2]
		if sEnd == s2 and sBeg==s2:
			result = True
	else:
		sEnd = s2[diff:len(s2)]
		sBeg = s2[0:lenS1]
		if sEnd == s1 and sBeg == s1:
			result = True
	return result

def valid_password(s3):
	result = False
	countLowerCase = 0
	countUpperCase = 0
	countNumber = 0
	countCharacter = 0
	if len(s3)>=8:
		for char in s3:
			a = ord(char)
			if (a>=65 and a<=90):
				countUpperCase=countUpperCase+1				
			elif (a>=97 and a<=122):
				countLowerCase=countLowerCase+1
			elif a>=48 and a<=57:
				countNumber=countNumber+1
			else:
				countCharacter=countCharacter+1
	if (countUpperCase>0 and countLowerCase>0 and countNumber>0 and countCharacter>0):
		result = True
	return result

print("Function1 returns " + str(end_begin_other("abc","aBCabXabc")))
print("Function2 returns " + str(valid_password("ASDF12@23")))
