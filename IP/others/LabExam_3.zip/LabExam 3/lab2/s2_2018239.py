#Midterm Lab Exam Set 2-2018
#Name:KINSHUK CHOPRA
#Roll Number:2018239
#Section: B
#Group: 8
#Date:23/09/2018


#function1
def end_begin_other(s1,s2):
	n1=len(s1)
	n2=len(s2)
	s2=s2.upper()             #convert both the strings to upper case for it tob compared as case insensitive
	s1=s1.upper()
	
	if (s1[0:n2]==s2 and s1[n1-n2:]==s2) or (s2[0:n1]==s1 and s2[n2-n1:]==s1): #if either string appears in the pother string 
		return True
	else:
		return False


#function2
def valid_password(s3):
	if len(s3)<8:                     #to return false if it has less then 8 characters

		return False
	d=0
	u=0
	ch=0
	for c in s3:
		if c.isdigit():              #to check if a number is present
			d=d+1
		elif c.isalpha():            #to check if ALPHABETS ARE PRESENT
			if c.isupper():          #to checl for uppercase alphabet
				u=u+1
			
		elif c=='_' or c=='@' or c=="$":
			ch=ch+1                   # tocheck for presence of special character
		else:
			return False               #returns false if neither of the required characters are present
	if d>=1 and u>=1 and ch>=1:
		return True                   
	else:
		return False




#print output
print("Function1 returns  "+str(end_begin_other("abc","aBCabXabc")))
print("Function2 returns  "+str(valid_password("ASDF12@23")))
