#Midterm Lab Exam Set 2 -2018
#Name : Ansh Kumar Sharma
#Roll Number : 2018130
#Section : A
#Group : 2
#Date : 23.09.2018

def end_begin_other(s1,s2):
	l1=len(s1)	#length of string1
	l2=len(s2)	#length os string2
	if l1>l2:	#comparing length of strings to check which one to traverse -- 1
		if s2.lower()==s1[:l2].lower() and s2.lower()==s1[l1-l2:].lower():	#matching strings according to the conditions -- 2
			return True
		else:
			return False
	elif l2>l1:	# -- 1	
		if s1.lower()==s2[:l1].lower() and s1.lower()==s2[l2-l1:].lower():	# -- 2
			return True
		else:
			return False
	else:
		if s1.lower()==s2.lower():	#when both strings are of same length, True is returned if they are same
			return True
		else:
			return False



def valid_password(s3):
	if len(s3)<8:	#checking condition1
		return False
	else:
		countcaps=0	#counter for upper case
		countdigit=0	#counter for numbers
		countspecial=0	#counter for special characters
		for i in s3:
			if i.isalpha():
				if i.isupper():
					countcaps+=1	
			elif i.isdigit():
				countdigit+=1
			elif i in (" ","@","$"):
				countspecial+=1
		if countcaps>0 and countdigit>0 and countspecial>0:	#applying conditions 3,4,5 simultaneously
			return True
		else:
			return False

#print output
print("Function1 returns " + str(end_begin_other("abc","aBCabXabc")))
print("Function2 returns " + str(valid_password("ASDF12@23")))

