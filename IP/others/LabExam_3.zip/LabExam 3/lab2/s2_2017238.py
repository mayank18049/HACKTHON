# Midterm Lab Exam Set- 2- 2018
# Name : Ishan Chandra
# Roll No. : 2017238
# Section : B
# Group : 8
# Date : 23/09/2018

# function 1
def end_begin_other(s1,s2):
	a = s1.lower()
	b = s2.lower()
	k1 = a[0:len(b)-1]
	k2 = a[len(a)-len(b):len(a)]
	k3 = b[0:len(a)-1]
	k4 = b[len(b)-len(a): len(b)]
	if len(a)>len(b) and (k1==b) and (k2==b):
		return True
	elif len(b)>len(a) and (k3==a) and (k3==a):
		return True 
	else :
		return False





# function 2  
def valid_password(s3):
	if (len(s3)>8) and (s3 in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ') and (s3 in '0123456789') and (s3=='@'or s3=='_' or s3=='$'):
		return True
	else :
		return False

