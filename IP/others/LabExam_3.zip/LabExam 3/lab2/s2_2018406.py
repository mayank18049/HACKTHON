# Midterm Lab Exam Set 2 - 2018
# Name : Ritik Malik
# Roll No.: 2018406
# Section : B
# Group : 7
# Date : 23 Sept 2018


def end_begin_other(s1,s2):
    count1=0
    count2=0
    l1=len(s1)
    l2=len(s2)
    if l1>l2:
        for x in s2:
            if s2[x]==s1[x]:
                (count1)+=1
            elif s1[l1-l2]==s2[x]:
                (count2)+=1
    coun1=0
    coun2=0
    if l2>l1:
        for x in s1:
            if s1[x]==s2[x]:
                (coun1)+=1
            elif s1[x]==s2[l1-l2+1]:
                (coun2)+=1

    if count1>l2-2 or count2>l2-2 or coun1>l1-2 or coun2>l1-2:
        return True
    else:
        return False


def valid_password(s3):
    alpha=0
    alphanum=0
    num=0
    if len(s3)<8:
        return False
    for x in s3:
        if x.isalpha()==1:
            alpha+=1
        elif s3.isalphanum():
            alphanum+=1
        elif s3.isnum():
            num+=1
    if alpha>0 and alphanum>0 and num>0:
        return True
    else:
        return False



print('Function 1 returns '+str(end_begin_other("abc,aBCabXabc")))
print('Function 2 returns '+str(valid_password("ASDFAdasg")))















