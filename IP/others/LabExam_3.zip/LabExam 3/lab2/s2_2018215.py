# Midterm Lab Exam Set 2 -2018
# Nme:Ajay Prakash
# Roll Number:2018215
# Sectioin:B
# Group :8
#Date: 23 September 2018
def end_begin_other(s1,s2):
	s2=s2.lower()
	s1=s1.lower()
	a=len(s2)
	b=len(s1)
	if a>b:
		if s2[:b]==s1 and s2[-b:]==s1:
			return True
		else:
			return False
	else:
		if s1[:a]==s2 and s1[-a:]==s2:
			return True
		else:
			return False

def valid_password(s3):
	s=0
	if len(s3)>=8:s+=1
	c=0
	for i in s3:
		if i.isupper():
			c+=1
	if c>0:
		s+=1
	c=0
	for i in s3:
		if i.isdigit():
			c+=1
	if c>0:
		s+=1
	if s3.count('_')>0 or s3.count('@')>0 or s3.count('$')>0:
		s+=1
	if s!=4:
		return False
	else:
		return True

print("Function1 returns "+str(end_begin_other('abc','aBCabXabc')))
print("Function2 returns "+str(valid_password('ASDF12@23')))