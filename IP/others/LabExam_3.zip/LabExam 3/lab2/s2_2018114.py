#midterm lab exam set2
#name - Utkarsh Sharma
#roll no. - 2018114
#section A
#group 2

#function1
def end_begin_other(s1,s2):
	if len(s1) > len(s2):
		string1 = s1
		string2 = s2
	else:
		string1 = s2
		string2 = s1
	string1end = string1[-3:]
	string1start = string1[:3]
	if string1end.lower() == string1start.lower() == string2:
		a = True
	else:
		a = False
	return a

#function2
def valid_password(s3):
	test = ""
	if len(s3) > 7:
		test = test + "D"
	for i in s3:
		if i == '0' or i == '1' or i == '2' or i == '3' or i == '4' or i == '5' or i == '6' or i == '7' or i == '8' or i == '9':
			test = test + "A"
	for i in s3:
		if i == '_' or i == '@' or i == '$':
			test = test + "B"
	for i in s3:
		if i == 'A' or i == 'B' or i == 'C' or i == 'D' or i == 'E' or i == 'F' or i == 'G' or i == 'H' or i == 'I' or i == 'J' or i == 'K' or i == 'L' or i == 'M' or i == 'N' or i == 'O' or i == 'P' or i == 'Q' or i == 'R' or i == 'S' or i == 'T' or i == 'U' or i == 'V' or i == 'W' or i == 'X' or i == 'Y' or i == 'Z':
			test = test + "C"
	if (("A" in test) and ("B" in test) and ("C" in test) and ("D" in test)) == True:
		answer = True
	else:
		answer = False
	return(answer)

#print output
print("function1 returns" + str(end_begin_other('s1','s2')))
print("function2 returns" + str(valid_password('s3'))