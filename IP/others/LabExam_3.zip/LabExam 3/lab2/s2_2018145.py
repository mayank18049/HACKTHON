#harshit
#2018145
#midsem_2_2018145
def end_begin_other(s1,s2):
	s1=input("enter the 1st string:")
	s2=input("enter the 2nd string:")
	first=0
	second=0
	while(s1>=0):
		i+=1
		first=first+s1
		while(s2>=-1):
			j+=1
			second=second+s2
			if(first==second):
				return True
			else:
				return False
	print("function1 returns"+str(end_begin_other(s1,s2)))
def valid_password(s3):
	s3=input("Enter a password:")
	a=len(s3)
	if(len==8):
		if(s3>=a and s3<=z and s3>=A and s3<=Z and s3>=0 and s3<=9):
			if(s3="_"or s3="@"or s3=="$"):
				return True
	else:
		return False
	print("function2 returns"+str(valid_password(s3)))

		
