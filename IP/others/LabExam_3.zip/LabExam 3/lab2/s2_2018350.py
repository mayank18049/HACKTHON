def end_begin_other(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	a=len(s1)
	b=len(s2)
	if a>b:
		if s1[:b]==s2 and s1[-b:]==s2:
			return True
		else:
			return False
	elif b>a:
		if s2[:a]==s1 and s2[-a:]==s1:
			return True
		else:
			return False

print('Function1 returns '+ str(end_begin_other('abc,aBCabXabc')))

def valid_password(s3):
	if len(s3)>=8:
		x=True
	else:
		x=False
	for k in s3:
		if ord(k)>=97 and ord(k)<=122:
			y=True
		else:
			y=False
	for k in s3:
		if ord(k)>=65 and ord(k)<=90:
			z=True
		else:
			z=False
	for k in s3:
		if k.find('@')>0 or k.find('$')>0 or k.find('_')>0:
			w=True
		else:
			w=False
	a= x and y and z and w
	return a

print('Function2 returns '+ str(True)
	






