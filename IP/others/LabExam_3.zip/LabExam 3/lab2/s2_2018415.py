#Midterm Lab Exam Set 2-2018
#Name:Shreeya Garg
#Roll Number:2018415
#Section-B
#Group-8
#Date-23/09/2018
#You need to implement both the functions given in this module.
#function1
from math import *
def end_begin_other(s1,s2):
	if (s1[-len(s2):].lower()==s2.lower() and s1[:len(s2)].lower()==s2.lower()) or (s2[-len(s1):].lower()==s1.lower() and s2[:len(s1)].lower()==s1.lower()):
		return True
	else:
		return False

def valid_password(s3):
	digit=0
	specchar=0
	upper=0
	alpha=0	
	if len(s3)>8 or len(s3)==8:
		for i in range(len(s3)):
			if s3[i].isdigit():
				digit+=1
			elif s3[i].isupper():
				upper+=1
			elif s3[i].isalpha():
				alpha+=1
			else:	
				specchar+=1
		if (digit>1 or digit==1) and (upper>1 or upper==1) and (specchar>1 or specchar==1):	
			return True
		else:
			return False	
	else:
		return False

print("Function1 returns"+str(end_begin_other("abc","aBCabXabc")))
print("Function2 returns"+str(valid_password("ASDF12@23")))	



