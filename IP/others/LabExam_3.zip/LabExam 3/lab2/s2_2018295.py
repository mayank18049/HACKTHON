
#Midterm Lab Exam Set 2 - 2018
#Name - Manavjeet Singh
#Roll number - 2018295
#Section - B
#Group - 8
#Date - 23/09/2018

import string

#function1
def end_begin_other(s1,s2):
    if len(s1)>len(s2):
        t1 = s1
        t2 = s2
    elif len(s1)<len(s2):
        t1 = s2
        t2 = s1
    else:
        t1 = s1
        t2 = s2

    t1 = t1.upper()
    t2 = t2.upper()
   #print (t1,t2)
   

    if t1[0:len(t2)]==t2 and t1[-1:-1*(len(t2))-1:-1] == t2[-1::-1] :
        return True
    else:
        return False
#function2
def valid_password(s3):
    value = False
    value1 = False
    value2 = False
    value3 = False
    value4 = False
    char_str = "_@$"
    if len(s3)<8:
        return value
    else:
        for i in s3:
            for x in string.ascii_lowercase:
                if i==x:
                    value1 = True
            if value1 == True:
                 break
        for j in s3:
            for y in string.ascii_uppercase:
                if j==y:
                    value2 = True
            if value2 == True:
                 break
        for k in s3:
            for z in string.digits:
                if k==z:
                    value3 = True
            if value3 == True:
                 break
        for l in s3:
            for a in char_str:
                if l==a:
                    value4 = True
            if value4 == True:
                 break
        value = value1 and value2 and value3 and value4
        return value



#output
print("Function1 returns " + str(end_begin_other("abc","aBCabxabc")))
print("Function2 returns " + str(valid_password("ASDF12@23")))