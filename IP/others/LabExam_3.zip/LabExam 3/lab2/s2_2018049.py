#MIDTERM LAB EXAM SET 2 -2018
# NAME : MAYANK RAWAT
# ROLL NUMBER :2018049
# SECTION : A
# GROUP : 1
# DATE : 23/09/2018
# FUNCTION 1

def end_begin_other(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	if(len(s1)<len(s2)):
		return False
	req_len=len(s2)
	check1=s1[0:req_len]
	check2=s1[-1:-(req_len+1):-1]
	print(check2,check1)
	if((check1==s2) and (check2[::-1]==s2)):
		return True
	else :
		return False
#FUNCTION 2
def valid_password(s3):
	flag1=0
	flag2=0
	flag3=0
	flag4=0
	if len(s3)<8:
		return False
	for i in s3:
		if i=='$' or i == '_' or i=='@':
			flag1=1
		elif(i.isupper()):
			flag2=1
		elif(i.islower()):
			flag3=1
		elif(i.isdigit()):
			flag4=1
		else :
			continue
	if (flag1==1) and (flag2==1) and (flag3==1) and (flag4==1):
		return True
	else:
		return False

print("Function1 returns " + str(end_begin_other("abc","aBCabXabc")))
print("Function2 returns " + str(valid_password("ASDF12@23")))