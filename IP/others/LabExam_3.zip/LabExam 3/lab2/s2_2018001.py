#midterm lab exam set 2-2018
#name:abhinandan kainth
#roll number: 2018001
#section: A
#Group: 1
#Date: 23 september 2018
#you need to implement both the functions given in the module




#function1

def end_begin_other(s1,s2):
	if(len(s1)>len(s2)):
		s1,s2=(s2,s1)
	flag=1
	s1=s1.lower()
	s2=s2.lower()
	for i in range(len(s1)):
		if(s1[-(i+1)]!=s2[-(i+1)]):
			flag=0
			print(s1[-(i+1)],s2[-(i+1)])
		if(s1[i]!=s2[i]):
			flag=0
	if (flag==1):
		return True
	else:
		return False






#function2


def valid_password(s3):
	flag1=0
	flag2=0
	flag3=0
	flag4=0
	flag5=0
	abc='ABCDEFGHIJKLMNOPQRSTUVWXYZ'
	if(len(s3)>=8):
		flag1=1
	if(s3.find('_')>=0 or s3.find('@') or s3.find('$')):
		flag5=1
	for s in s3:
		if(s.isdigit()):
			flag4=1
		if(s.isalpha()):
			flag2=1
		if(abc.find(s)>=0):
			flag3=1
	flag=flag1*flag2*flag3*flag4*flag5
	if(flag==1):
		return True
	else:
		return False 

#print output
print("Function1 returns " + str(end_begin_other("abc","aBCabXabc")))
print("Function2 returns " + str(valid_password("ASDF12@23")))
