#midterm lab exam set2 2018
name anu kanojia
#roll no 2018383
#sec b 
#GRP 8



def end_begin_other(s1,s2):
	a=s1.lower()
	b=s2.lower()
	if a[-len(b):]==b:
		return True
	elif b[-len(a):]==a:
		return True
	else:
		return False
print(end_begin_other('anu','u'))
print(end_begin_other('ab','gjkavjhjabhkab'))	





#qus2
def valid_password(s3):
r=''
alp=0
digit=0
uppr=0
splchar=0
	if len(s3)>8 and len(s3)==8:
		for i in range(len(s3)):
			if s3[i].isalpha():
				alp+=1
			elif s3[i]==i.upper():
				r=r+1
			elif s3[i].isdigit():
				digit+=1
			elif s3[i]==@:
				return True
print(def valid_password(fhyj35578@3))
