# Midterm Lab Exam Set 2 - 2018
# Name: Shubhi Singhal
# Roll Number: 2018195
# Section: A
# Group: 3
# Date: 23rd Sep 2018

#function1

def end_begin_other(s1,s2):
    a=len(s1)
    b=len(s2)
    if s1[:b]==s2 and s1[a-b:]==s2:
        return True
    elif s2[:a]==s1 and s2[b-a:]==s1:
        return True
    else:
        return False

def valid_password(s3):
    b=len(s3)
    a1=a2=a3=0
    if b<8:
        return False
    else:
        for c in s3:
            if c.isupper():
                a1+=1
            if c.isdigit():
                a2+=1
            if c=="_" or c=="@" or c=="$":
                a3+=1
        if a1==0 or a2==0 or a3==0:
            return False
        else:
            return True

print("Function1 returns " + str(end_begin_other("abc","abcabXabc")))
print("Function2 returns " + str(valid_password("ASDF12@23")))
