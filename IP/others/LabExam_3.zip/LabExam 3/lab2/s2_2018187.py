# Midterm Lab Exam Set 2 -  2018
# Name: Saksham Jain
# Roll Number: 2018187
# Section: A
# Group: 3
# Date: 23/09/2018
#function1
def end_begin_other(s1,s2):
    l1=len(s1)
    l2=len(s2)
    if(l1<l2):
        return s1.lower()==s2[0:l1].lower() and s1.lower()==s2[l2-l1:l2].lower()
    elif(l1>l2):
        return s2.lower()==s1[0:l2].lower() and s2.lower()==s1[l1-l2:l1].lower()
    else:
    	return False
#function2
def valid_password(s3):
    if(len(s3)<8):
        return False
    else:
    	count=0
        for i in range(0,len(s3)):
            if(s3[i] in ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']):
                count+=1
        if(count<1):
            return False
        else:
            count=0
            for i in range(0,len(s3)):
        	if(s3[i] in [0,1,2,3,4,5,6,7,8,9]):
        	    count+=1
            if(count<1):
                return False
            else:
                count=0
        	for i in range(0,len(s3)):
        	    if(s3[i] in ['_','@','$']):
        	        count+=1
        	if(count<1):
        	    return False
#print output
print("Function1 returns " + str(end_begin_other("abc","aBCabXabc")))
print("Function2 returns " + str(valid_password("ASDF12@23")))
