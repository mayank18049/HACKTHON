#Midterm Lab Exam Set 2 - 2018
#Name:Mohit
#Roll Number: 2018343
#Section - B
#Group - 8
#Date: 23/09/2018

#function 1 
def end_begin_other(s1,s2):
						if s1[0]==s2
							else s1[-1]==s2
							else s2[0]==s1
							else s2[-1]==s1
						print (True)
						else print(False)
#function 2
#def valid_password(s3):
	if:
		len(s3)>7
		s3.find()

#print output
print ("Function1 returns"+str(end_begin_other("abc,aBCabXabc")))
print ("Function2 returns")