#name:ADITI SONI
#ROLL NO-2018326
#sec-B
#group-7
#date-23-09-2018

def end_begin_other(s1,s2):
	import string
	s12=s1.upper()
	s21=s2.upper()
	p=len(s12)
	x=len(s21)
	k=s12[0:x+1]
	b=s12[-1:x+1]
	v=s21[0:p+1]
	q=s21[-1:p+1]
	if (k==s21 and b==s21) or (v==s12 and q==s12):
		return True
	else:
		return False	
#function 2
def valid_Password(s3):
	import string
	f=0
	m=0
	l=0
	k=0
	n=len(s3)
	for i in s3:
		if    s3>=chr(65) or s3<=chr(90):
			f+=1
		elif  s3>chr(90)  or s3<=chr(116):
			m+=1
		elif  int(i)>=0  and int(i)<=9:
			l+=1 		
		elif  i=='_' or i=='@' or i=='$':
			k+=1
		else:
			y=0	

	if f!=0 and m!=0 and l!=0 and k!=0:
		return True
	else:
		return False
	
	
		
print("func2 ans",str(valid_Password("ASDF12@23")))
print("func1 ans",str(end_begin_other("abc","aBCabXabc")))					
