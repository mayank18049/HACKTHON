import string
def end_begin_other(s1,s2):
	if len(s1)>len(s2):
		a=s1.upper()
		b=s2.upper()
	else:
		a=s2.upper()
		b=s1.upper()

	m=len(a)
	n=len(b)
	if a[0:n]==b and a[m-n:m]==b:
		return True
	else:
		return False


def valid_password(s3):
	if len(s3)<7:
		return False
	c1=0
	c2=0
	c3=0
	for x in s3:
		if 65<=ord(x)<=91:
			c1+=1
		elif x in '0123456789':
			c2+=1
		elif x in '_@$':
			c3+=1
	if c1*c2*c3==0:
		return False
	else:
		return True
		
print("Function1 returns "+ str(end_begin_other("abc","aBCabXabc")))
print("Function2 returns "+str(valid_password("ASDF12@23")))