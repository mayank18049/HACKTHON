#Midterm Lab Exam Set 2 - 2018
#Name: Adnan Ali
#Roll Number: 2018214
#Section: B
#Group: 7
#Date: 23rd September 2018

#Function1
def end_begin_other(s1,s2):
	s1 = s1.lower()
	s2 = s2.lower()
	l1 = len(s1)
	l2 = len(s2)
	if s1[l1-3:] == s2[:3]:
		return (True)
	else:
		return (False)



#Function 2
def valid_password(s3):
	p = 0
	q = 0
	r = 0
	s = 0
	l = len(s3)
	if l >= 8:
		for i in s3:
			if i.isdigit():
				p = 1
		for j in s3:
			if j == '_' or j == '@' or j == '$':
				q = 1
		for m in s3:
			if m.isupper():
				r = 1
		for n in s3:
			if n.isalpha():
				s = 1
	if p == 1 and q == 1 and r == 1 and s ==1:
		return(True)
	else:
		return(False)

#print output
print('Function1 returns' + str(end_begin_other('abc','aBCabXabc')))
print('Function2 returns' + str(valid_password('ASDF12@23')))