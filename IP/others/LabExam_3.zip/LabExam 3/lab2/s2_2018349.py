def end_begin_other(s1,s2):
	ls1 = len(s1)
	ls2 = len(s2)
	import string
	if (ls1>ls2):
		big = s1.lower()
		small = s2.lower()
		l = ls1
	else:
		big = s2.lower()
		small = s1.lower()
		l = ls2
	flag=0
	if (big[0:3] != small):
		flag+=1
	if (big[l-3:l] != small):
		flag+=1
	if (flag==0):
		return True
	else:
		return False


def valid_password(s3):
	ls = len(s3)
	length = 0
	capital = 0
	special = 0
	digit = 0
	import string
	if ls<8:
		length+=1
	for c in s3:
		if c.isupper():
			capital+=1
		if c.isdigit():
			digit+=1	
		if (c=="@") or (c=="_")	or (c=="$") :
			special+=1
	if (length==0) and (capital>=1) and (special>=1) and (digit>=1):
		return True
	else:
		return False