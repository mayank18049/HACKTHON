#Midterm Lab Exam Set 2 -2018
#Name: Sarthak Pal
#Roll Number: 2018412
#Section: B
#Group: 5
#Date: 23/09/2018


from string import *

def end_begin_other(s1,s2):
    l1 = len(s1)
    l2 = len(s2)
    if l1<=l2:
        x = s2[:l1].lower()
        y = s2[(l2 - l1):].lower()
        if (s1.lower() == x and s1.lower() == y):
            return True

        else:
            return False

    else:
        x = s1[:l1].lower()
        y = s1[(l2 - l1):].lower()
        if (s2.lower() == x and s2.lower() == y):
            return True

        else:
            return False

    
def valid_password(s3):
    l = len(s3)
    count_upper = 0
    count_digit = 0
    count_special = 0
    i = ''
    for i in s3:
        if i.isupper():
            count_upper += 1
        if i.isdigit():
            count_digit += 1
        if i == '_' or i == '@' or i == '$':
            count_special += 1

    if (l >= 8 and count_upper>0 and count_special>0 and count_digit>0):
        return True

    else:
        return False
     

#print output
print("Funtion1 returns " + str(end_begin_other("abc","aBCabXabc"))) #True 
print("Funtion2 returns " + str(valid_password("ASDF12@23"))) #True
