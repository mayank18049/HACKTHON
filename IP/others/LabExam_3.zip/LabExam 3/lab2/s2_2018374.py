#Midterm Lab Exam
#Name: Tano roxane
#roll number : 2018374
#Section: B
#Group: 7
#Date : 22/09/2018
def end_begin_other(s1,s2):
if end_begin_other("AbCHiabc",abc)
print(True)
elif: end_begin_other()
print(True)
elif: end_begin_other()
print(True)
else: return false

#function2
def valid_password(s3)
if s3 <= 8
return :True
else: False
len =a-s



#print output
print("Function1 returns " + str(end_begin_other("abc,aBCabXabc")))
print("Function2 returns " + str(valid_password("ASDF12@23"))