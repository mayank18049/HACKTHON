# Midterm Lab Exam Set 2- 2018
# Name: Rishabh Devgon
# Roll Number: 2018303
# Section: B
# Group: 8
# Date: 23.09.2018
# You need to implement both the functions given in this module.

# function1
def end-begin-other(s1,s2):
    st1=s1
    for i in len(s1):
        y=s1[i]
        z=y.upper()
    
    for j in len(s2):
        x=s1[j]
        a=x.upper()
        a=a+a
        
        
        












# function2
def valid_password(s3):
    s3=str(s3)
    if len(s3)<8:
        return False
    c=0
    for i in range (0,len(s3)):
        if s3[i]<='Z' and s3[i]>='A':
            c=c+1
    if c<=0:
        return False
    b=0
    for i in range (0,len(s3)):
        if s3[i]<='z' and s3[i]>='a':
            b=b+1
    if b<=0:
        return False
    d=0
    for j in range (0,len(s3)):
        if s3[j]<='9' and s3[j]>='0':
            d=d+1
    if d<=0:
        return False
    for k in range (0,len(s3)):
        if s3[k]=='_' or s3[k]=='@' or s3[k]=='$':
            d=d+1
    if d<=0:
        return False
    else:
        return True
    
    
    
    
        
