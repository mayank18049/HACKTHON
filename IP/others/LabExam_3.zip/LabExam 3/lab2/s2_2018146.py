#midterm lab exam set 2
#name: Himanshu Aggarwal
#roll no: 2018146
#section: A
#group: 2
#date: 23/09/2018
#function_1
def end_begin_other(s1,s2):
	if(len(s1)>len(s2)):
		a= s1.lower()
		b= s2.lower()
		a1= a[:len(b)]
		a2= a[len(a)-len(b):]
		if(b==a1 and b==a2):
			return True
		else:
			return False

	else:
		a= s1.lower()
		b= s2.lower()
		b1=b[:len(a)]
		b2=b[len(b)-len(a):]
		if(a==b1 and a==b2):
			return True
		else:
			return False

#function_2
def valid_password(s3):
	if(len(s3)>=8):
		count_1=0
		count_2=0
		count_3=0
		count_4=0
		for i in s3:
			if (ord(i)>=65 and ord(i)<=90):
				count_1+=1
			elif (ord(i)>=48 and ord(i)<=57):
				count_2+=1
			elif (i=='_' or i=='@' or i=='$'):
				count_3+=1
			elif(ord(i)>=97 and ord(i)<=122):
				count_4+=1

		if(count_1>=1 and count_2>=1 and count_3>=1 and ((count_1 +count_2+count_3+count_4)==len(s3))):
			return True
		else:
			return False

	else:
		return False


#print output
print("function_1 returns "+str(end_begin_other("abc","ABcabXabc")))
print("function_2 returns "+str(valid_password("ASDF12@23")))


 
