# Midterm Lab Exam Set 2 - 2018
# Name: Shekhar Shukla
# Roll Number: 2018414
#Section: B
# Group: 7
# Date:23-9-2018

def end_begin_other(s1,s2):
	l1 = len(s1)
	l2 = len(s2)

	if (l1==l2):
		if s1==s2:
			return True
		else:
			return False

	elif l1>l2 :
		s2 = s2.upper()
		m = l1-l2
		if ( s1[0:3].upper() == s2) and  ( s1[m:].upper() == s2):
			return True
		else:
			return False
	
	elif l2>l1 :
		s1 = s1.upper()
		m = l2-l1
		if ( s2[0:3].upper() == s1) and  ( s2[m:].upper() == s1):
			return True
		else:
			return False

def valid_password(s3):
	l = len(s3)
	a=b=c=0
	s = '_@$'
	if l>=8 :
		for i in range(l):
			if s3[i].isalpha() and s3[i].isupper():
				a+=1
			elif s3[i].isdigit() :
				b+=1
			elif s3[i] in s:
				c+=1
	if a>=1 and b>=1 and c>=1 :
		return True
	else:
		return False

print("Function1 returns " + str(end_begin_other('abc','aBCabXabc')))
print("Function2 returns " + str(valid_password('ASDF12@23')))
