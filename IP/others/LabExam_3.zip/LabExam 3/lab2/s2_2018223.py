def end_begin_other(s1,s2):
	x=len(s1)
	y=len(s2)
	z=min(s1,s2)
	k=max(s1,s2)
	
	return True

def valid_password(s3):
	x=len(s3)
	if x>=8:
		for i in s3:
			if (i=='0' or i=='1' or i=='2' or i=='3' or i=='4'  or i=='5' or i=='6' or i=='7' or i=='8' or i=='9'):
				y=True
			if (i=='_' or i=='@' or i=='$'):
				y=True
			if i==i.isupper():
				y=True
			if (i==i.islower):
				y=True
	return y
			







if __name__=='__main__':
	print("Function1 returns "+ str(end_begin_other("abc","aBCabXabc")))
	print("Function2 returns "+ str(valid_password("ASDF12@23")))



