# arka sarkar
# roll no-2018222
# section-B, group-7

#function1
def end_begin_other(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	l1=len(s1)
	l2=len(s2)
	if len(s1)>len(s2):
		if s1[0:l2]==s2 and s1[l1-l2:l1]==s2:
			return True
		else:
			return False
	if len(s1)<len(s2):			
		if s2[0:l1]==s1 and s2[l2-l1:l2]==s1:
			return True
		else:
			return False

		
		
		
		
		
		
#function2

def valid_password(s3):

	if len(s3)<8:
		return False

	n1=s3.find('_')
	n2=s3.find('@')
	n3=s3.find('$')
	n4=s3.find('1') or s3.find('2') or s3.find('3') or s3.find('4') or s3.find('5') or s3.find('6') or s3.find('7') or s3.find('8') or s3.find('9') or s3.find('0')

	# elif len(s3)>=8:

	if n1==n2==n3==False:
		return False
	elif s3.isupper()==True and (n1==True or n2==True or n3==True) :
		return True
	else:
		return False	












print('Function1 returns'+ str(end_begin_other('abc','aBCabXabc')))
print('Function2 returns'+ str(valid_password('ASDFf')))





