#Midterm Lab Exam Set 2 - 2018
# Name: MEHUL DOKANIA
# Roll Number: 2018246
# Section: B
# Group: 7
# Date: 23/09/2018

#function1

def end_begin_other(s1,s2):
	if(len(s1)<len(s2)):
		temp = s1
		s1 = s2
		s2 = temp  # idk if i can write s1,s2 = s2,s1
			
	#s1 is the bigger string and s2 is the smaller string or they are both equal

	n = len(s2)

	#getting rid of case sensitivity
	s1 = s1.lower()
	s2 = s2.lower()


	if(s1[:n] == s2 and s1[len(s1)-n:] == s2):
		return True 
	
	return False	


#function 2

def valid_password(s3):

	b1 = False
	b2 = False
	b3 = False

	if len(s3)>=8:
			
		for char in s3:
			
			if("A"<=char<="Z"):
				b1 = True	

			if(char.isdigit()):
				b2 = True

			if(char == '_' or char == '@' or char == '$'):
				b3 = True	

		if(b1 and b2 and b3):
			return True		
		

	return False		


print("Function1 returns " + str(end_begin_other("abc","aBCabXabc")))
print("Function1 returns " + str(valid_password("ASDF12@23")))
