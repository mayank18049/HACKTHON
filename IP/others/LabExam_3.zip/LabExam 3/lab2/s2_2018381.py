def end_begin_other(s1,s2):
	a= len(s1)
	b= len(s2)
	if s1[0:b]== s2 or s1[-b:]== s2 :
		return("True")
	elif s2[0:a]== s1 or s2[-a:]== s1 :	
		return("True")
	else:
		return("False")	
	print("Function1 returns" + str(end_begin_other("abc,aBCabXabc")))	

def valid_password(s3):
	p= str(s3)
	a = len(s3)
	if "A"<p<"Z" :
		print("true")
	elif a>=8:
		print("True")	
	elif "a"<p<"z":
		print("true")	
	else:
		print("False")	
	print("")	




