"""
Mifterm Lab Exam Set 2 - 2018
Name - PRASHAM NARAYAN
Roll no - 2018359
Section - B
Group - 8
Date - 23/08/2018
"""
def end_begin_other(s1,s2):
	from string import *
	a1 = len(s1)
	a2 = len(s2)
	s1 = lower(s1)
	s2 = lower(s2)
	if a1>a2:
		s3 = s1[0:a2]
		s4 = s1[a1-a2:]
		if s3 == s2 and s4 == s2:
			z = True
		else:
			z = False
	else:
		s3 = s2[0:a1]
		s4 = s2[a2-a1:]
		if s3 == s1 and s4 == s1:
			z = True
		else:
			z = False
	return z
def valid_password(s3):
	l = len(s3)
	flag = 0
	dig = 0
	upp = 0
	ch = 0  
	if l<8:
		flag = 1
	i = 0
	while (i<l):
		if s3.isupper():
			upp = upp + 1
		if s3[i]=="_" or s3[i]=="@" or s3[i]=="$":
			ch = ch +1
		if s3[i]=="0" or s3[i]=="1" or s3[i]=="2" or s3[i]=="3" or s3[i]=="4" or s3[i]=="5" or s3[i]=="6" or s3[i]=="7" or s3[i]=="8" or s3[i]=="9":
			dig = dig + 1
		i = i + 1
	if flag == 0 and upp>0 and dig>0 and ch>0:
		return True
	else:
		return False
#print output
print ("Function1 returns "+ str(end_begin_other("abc","aBCabXabc")))
print ("Function2 returns "+ str(valid_password("ASD12@23"))) 

