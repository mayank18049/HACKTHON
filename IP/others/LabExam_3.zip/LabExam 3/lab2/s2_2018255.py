def valid_password(s3):
	if len(s3) < 9:
		if ((int(s3)>=65 and (int(s3)<=91) and (int(s3)>=0 and (int(s3)<=9)):
																			return True 
		else:
			return False
def end_begin_other(s1,s2):
	u=len(s1)
	v=len(s2)
	s1=islower()
	s2=islower()
	if u-v>0 or v-u>0:
		if (s1[len(s1)-(u-v):] == s2 and s1[0:len(s1)-(u-v)] == s2) or (s2[len(s2)-(u-v):] == s1 and s2[0:len(s2)-(u-v)] == s1) or (s1[len(s1)-(v-u):] == s2 and s1[0:len(s1)-(v-u)] == s2) or (s2[len(s2)-(v-u):] == s1 and s2[0:len(s2)-(v-u)] == s1):
														return True
		else:
				return False
