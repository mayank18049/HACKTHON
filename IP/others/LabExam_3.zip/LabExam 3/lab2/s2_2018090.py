#Midtemr lab exam set 2 - 2018
'''
name = Samik Prakash
Roll number = 2018090
Section = A
Group = 2
Date = 23/09/2018
'''
def end_begin_other(s1,s2):
	s1 = s1.lower()
	s2 =s2.lower()
	if len(s1)>len(s2):
		if s1[:len(s2)] == s1[-len(s2):] and s1[:len(s2)] == s2 and s1[-len(s2):] == s2:
			return True
		else:
			return False
	elif len(s2)>len(s1):
		if s2[:len(s1)] == s2[-len(s1):] and s2[:len(s1)] == s1 and s2[-len(s1):] == s1:
			return True
		else:
			return False

def valid_password(s3):
	if len(s3)>=8:
		upper = 0
		special = 0
		number = 0
		for i in range(len(s3)):
			if s3[i].isdigit():
				number = number+1
			elif s3[i].isalpha() and s3[i].isupper():
				upper = upper+1
			elif s3[i].isalnum() == False:
				special = special+1
		if number != 0 and special != 0 and upper != 0:
			return True
		else:
			return False

	else:
		return False

print('Function1 returns ' + str(end_begin_other("abc","aBCabXabc")))
print('Function2 returns '+str(valid_password("ASDF12@23")))


