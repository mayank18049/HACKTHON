#Midterm Lab Exam Set 2 - 2018
#Name: DUSHYANT PANCHAL
#Roll Number: 2018033
#Section: A
#Group: 1
#Date: 23-09-2018

def end_begin_other(s1,s2):
	"""Returns True if either of the strings appear at
	the very end and at the very beginning of the other
	string, case-insensitively. Else returns False."""

	temp1=s1.lower()	#Convert to lower case
	temp2=s2.lower()	#Convert to lower case
	
	rev1=temp1[::-1]	#Get reversed string
	rev2=temp2[::-1]	#Get reversed string

	if(temp1.find(temp2)==0 and rev1.find(rev2)==0):
		return True		#if s2 at beg and end of s1

	elif(temp2.find(temp1)==0 and rev2.find(rev1)==0):
		return True		#else if s1 at beg and end of s2
	else:
		return False	#Otherwise False


def valid_password(s3):
	"""Returns True when the password is valid and False otherwise.
	1. Minimum 8 characters
	2. Alphabet must be between [a-z]
	3. Atleast one alphabet in [A-Z]
	4. Atleast one digit [0-9]
	5. Atleast one character from [_ or @ or $]"""
	num=False
	alpha=False
	ALPHA=False
	char=False

	length=(len(s3)>=8)	#Check for length

	for i in s3:
		if(i in '0123456789'):	#Check for digits
			num=True
		if(i in 'abcdefghijklmnopqrstuvwxyz'):	#Check small letters
			alpha=True
		if(i in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'):	#Check capital letters
			ALPHA=True
		if(i in '_@$'):		#Check allowed special characters
			char=True

	return (num and alpha and ALPHA and char and length)
		#true if all conditions satisfied


#print output
print("Function1 returns " + str(end_begin_other("abc","aBCabXabc")))
print("Function2 returns " + str(valid_password("ASDF12@23")))