#b7bV@8=M

""" Mid Term Lab Exam - 2018
Name 		- Ujjwal Singh
Roll Number 	- 2018113
Section 	- A
Group 		- 1 
Date 		- 23 September 2018
"""
def end_begin_other(s1,s2):
	a=len(s1)
	b=len(s2)
	s1=s1.lower()
	s2=s2.lower()
	if(a>b):
		f=a-b
		if(s1[:b]==s2 or s2[f:]==s1):
			print("True")
		else:
			print("False")
	elif(b>a):
		g=b-a
		if(s2[:a]==s1 ):
			print("True")
		else:
			print("False")
	else:
		print("True")
def valid_password(s3):
	c=len(s3)
	d=0
	e=0
	f=0
	g=0
	if(c>=8):
		v=1
	else:
		v=0
	for i in s3:
		if(i.islower()):
			d=d+1
		elif(i.isupper()):
			e=e+1
		elif(i.isdigit()):
			f=f+1
		elif(i=="_" or i=="@" or i=="$"):
			g=g+1
		else:
			n=0
	#print(d,e,f,g)   for Debugging Purpose(Not output)
	if(d>=1 and e>=1 and f>=1 and g>=1 and v==1):
		print("True")
	else:
		print("False")
	
s1="abc"
s2="aCCabXabc"
s3="cope1234"	
end_begin_other(s1,s2)
valid_password(s3)

