'''
NAME - GARVITA JAIN
SECTION - A
GROUP - 2
ROLL NO = 2018034 '''
def end_begin_other(s1,s2):
	s1=s1.upper()
	s2=s2.upper()
	x1=len(s1)
	x2=len(s2)
	ans='False'

	if x1>x2:
		y=s1.find(s2)
		z=s1.rfind(s2)
		if y==0 and z==x1-x2:
			ans='True'
	else:
		y=s2.find(s1)
		z=s2.rfind(s1)
		if y==0 and z==x2-x1:
			ans='True'

	return ans

def valid_password(s3):
	length=len(s3)
	

	if length>=8:
		big=0
		small=0
		digit=0
		sc=0
		for i in range(0,length):
			x=ord(s3[i])
			if x>64 and x<91:
				big+=1
			elif x>96 and x<123:
				small+=1
			elif x>47 and x<58:
				digit+=1
			elif s3[i]=='_' or s3[i]=='@' or s3[i]=='$':
				sc+=1

	if big!=0 and digit!=0 and sc!=0:
		return True
	else:
		return False

def output():
	print("Function 1 returns "+str(end_begin_other('abc','aBCabXabc')))
	print("Function 2 returns "+str(valid_password("ASDF12@23")))

if __name__ == '__main__':
	output()

