#Midterm Lab Exam Set 2 - 2018
#Name-shivam
#Roll Number- 2018309
#Section - B
#Group -6
#Date- 23 sep 2018

def end_begin_other(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	n=len(s2)
	m=len(s1)
	if s1[0:n]==s2 and s1[-n:]==s2:
		return True
	elif  s2[0:m]==s1 and s2[-n:]==s1:
		return True
	else:
		return False
#function2
def valid_password(s3):
	n= len(s3)
	if n>=8:
		for s in s3:
			if s in ['_','@','$']:
				for s in s3:
					if s in range(10):
						for s in s3:
							if ord(s) in range(ord('A'),ord('Z')+1):
								return True
	
	return False      		       
print ("Function1 returns " + str(end_begin_other("abc","aBCabXabc")))
print ("Function2 returns " + str(valid_password("ASDF12@23")))

