def end_begin_other(s1,s2):
    s1="abc"
    s2='"aBCabXabc"
print("end_begin_other(s1,s2)" + str(end_begin_other("abc,aBCabXabc")))

def valid_password(s3):
s3=input("enter valid password of 8 char:")
if s3==s3[0:9]
s3=asci("97" and "123")
s3=asci("65" and "91")
s3=asci("0" 
