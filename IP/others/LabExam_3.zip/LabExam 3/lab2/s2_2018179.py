def end_begin_other(s1,s2):
   s1=s1.lower()
   s2=s2.lower()
   y=len(s1)
   z=len(s2)
   if y>z:
   	 d=s1[:z]
   	 g=s1[y-z:]
   	 if d==s2 and g==s2:
   	  	  return True
   	 else:
   	  	  return False
   elif z>y:
   	d=s2[:y]
   	g=s2[z-y:]
   	if d==s1 and g==s1:
   	  	 return True
   	else:
   	  	 return False
   elif z==y:
   	if s1==s2:
   	   	return True
   	else:
   	   	return False
   else:
   	return False




def valid_password(s3):
	k=len(s3)
	if k>=8:
		m=s3.find("_")
		n=s3.find("$")
		j=s3.find("@")
		l=s3.isdigit()
		k=s3.isalpha()
		F=j>0 or l>0 or k>0
		if l==True and k==True and F==True:
			return True
		else:
			 return False
	else:
		return False    



	  
print("Function1 returns" +str(end_begin_other("abc","aBcabxabc")))
print("Function2 returns" +str(valid_password("ASDF12@23")))
