# Midterm Lab Exam Set 2 - 2018
# Name : Ishan Sharma
# Roll Number : 2018043
# Section : A
# Group : 3
# Date : 23-09-2018

def end_begin_other (s1,s2) :
	""" Returns True if either of the strings apper at the very end and
	at  the very beginning of the other string, ignoring case-senstivity.
	Else return False. """
	s1 = s1.lower()
	s2 = s2.lower()
	l1 = len(s1)
	l2 = len(s2)
	if l1 > l2 :
		if s1[:l2] == s2 and s1[(l1-l2):] == s2 :
			return True
		else :
			return False	
	else :
		if s2[:l1] == s1 and s2[(l2-l1):] == s1 :
			return True	
		else :
			return False		
		 
def valid_password(s3) :
	""" Returns True when password is valid and False otherwise.
	Password is valid if :
	(1) It has min 8 characters
	(2) At least one alphabet should be UpperCase,i.e. [A-Z]
	(3) At least 1 number or digit between [0-9]
	(4) At least 1 character from [_ or @ or $] """
	c1 = False
	c2 = False
	c3 = False
	c4 = False
	if len (s3) > 7 :
		c1 = True
		for i in s3 :
			if i.isupper() :
				c2 = True
			if i.isdigit() :
				c3 = True
			if i == '_' or i == '@' or i == '$' :
				c4 = True	
	if c1 and c2 and c3 and c4 :
		return True
	else :
		return False	 			

#print output
print("Function1 returns " + str(end_begin_other("abc","aBCabXabc")))	
print("Function2 returns " + str(valid_password("ASDF12@23")))
