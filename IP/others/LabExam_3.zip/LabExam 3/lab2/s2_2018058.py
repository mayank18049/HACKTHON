#Midterm Lab Exam Set2-2018
#Name->Nipun Jain
#Roll number->2018058
#Section->A
#Group->2
#Date->21/09/2018
#function1
def end_begin_other(s1,s2):
	s1=str(input())
	s2=str(input())
	a=len(s1)
	b=len(s2)
	if a<b:
		ch1=a[0:3]
		ch2=a[len(s2)+2:]
		if s1==ch1 and s1==ch2:
			return True
		else:
			return False
	elif a>b:
		ch1=a[0:3]
		ch2=a[len(s1)+2:]
		if s1==ch1 and s1==ch2:
			return True
		else:
			return False
	else:
		return False
#function2
def valid_password(s3):
	ch=str(input())
	if (a<=ch<=z) and (A<=ch<=Z) and (0<=ch<=9) and (ch=='_' or ch=='$' or ch=='@'):
		return True
	else:
		return False
#print output
print("Function1" + str(end_begin_other("abc,aBCabXabc")))
print("Function2" + str(valid_password("ASDF12@23"))