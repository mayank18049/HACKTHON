#Midterm Lab Exam Set 2 - 2018
#Name: Pruthwiraj Nanda
#Roll Number: 2018075
# Section: A
# Group: 3
# Date: 23/09/2018
# Funtion1

def end_begin_other(s1,s2):
	s1=str(s1)
	s2=str(s2)
	x=len(s1)
	y=len(s2)
	s2=s2.lower()
	s1=s1.lower()
	if y>x :
		if (s2.find(s1)==0 and s2.find(s1,x)==y-x):
			return True
		else:
			return False
	else:
		if (s1.find(s2)==0 and s1.find(s2,y)==x-y):
			return True
		else:
			return False

#Function2

def valid_password(s3):
	s3=str(s3)
	y=len(s3)
	if y>=8 :
		char1=0
		char2=0
		char3=0
		char4=0
		for f in s3:
			if f in '$_@':
				char1=char1+1
			if f.isalpha():
				char2=char2+1
			if f.isdigit():
				char3=char3+1
			if f.isupper():
				char4=char4+1
		if char1>=1 and char2!=0 and char3>=1 and char4>=1 :
			return True 
		else:
			return False
	else:
		return False

#print output

print('Function1 returns ' + str(end_begin_other('abc','aBCabXabc')))
print('Function2 returns ' + str(valid_password('ASDF12@23')))





