def valid_password(s3)
s=input()
t=len(s)

if t>8 and ("_".find(s) or "@".find(s) or "$".find(s)) and ("0".find(s) or "1".find(s) or "2".find(s) or"3".find(s) or "4".find(s) or "5".find(s) or"6".find(s) or "7".find(s) or "8".find(s) or"9".find(s)) and s.upper() :
	retun("true")
else:
	return("false") 

print ("Function2 returns "+str(valid_password("ASDF12@23")))

"""NAME SEJAL SINGH
ROLL NO. 2018413"""