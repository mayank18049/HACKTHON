#Midterm lab Exam Set 2-2018
#Name: SAJAG PRAKASH
#Roll Number:2018089
#Section:A
#Group:1
#Date: 23 sept 2018




def end_begin_other(s1,s2):
	s1=s1.lower()                  #converting to lower case
	s2=s2.lower()
	l1=len(s1)                     #finding length 
	l2=len(s2)
	if((s2==s1[-l2:] and s2==s1[:l2])or(s1==s2[-l1:] and s1==s2[:l1])): #checking if present at end and beginning
		return True
	else:
		return False

#end_begin_other("ABCHiabc","abc")
#end_begin_other("Abc","AbbCHiabc")
#end_begin_other("abc","aBCabXabc")
#end_begin_other("Abc","aCCabXabc")


def valid_password(s3):
	a=0              #counter for capital var
	n=0              #counter for number
	c=0              #counter for special charecter
	if(len(s3)>=8):
		for i in range(len(s3)):
			if('A'<=s3[i]<='Z'):
				a=a+1
			elif(s3[i].isdigit()):
				n=n+1
			elif(s3[i]=='_'or s3[i]=='@'or s3[i]=='$'):
				c=c+1
		if(a>=1 and n>=1 and c>=1):            # checking instances of capital letter,digit,special char
			return True	
		else:
			 return False
	else:
	    return False		
    
#valid_password("aacc1@SD")
#valid_password("ASDF12@123")
#valid_password("A@bcd12")
#valid_password("abcd111_")


#_----------------------print_output------------------
print("Function1 returns "+ str(end_begin_other("abc","aBCabXabc")))
print("Function2 returns "+ str(valid_password("ASDF12@123")))
