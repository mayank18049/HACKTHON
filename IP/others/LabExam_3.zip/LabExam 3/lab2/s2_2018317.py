#Midterm Lab Exam Set 2 -2018
#Name: Sonali SInghal
#Roll Number: 2018317
#Section: B
#Group: 6
#Date: 23.09.2018
def end_begin_other(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	n1=len(s1)
	n2=len(s2)
	if n1>n2:
		flag1=s1.find(s2,len(s1)-len(s2))
		flag2=s1.find(s2)
	elif n2>n1:
		flag1=s2.find(s1,len(s2)-len(s1))
		flag2=s2.find(s1)
	if flag1!=-1 and flag2==0:
		return True
	return False

def valid_password(s3):
	flag1=False
	flag2=False
	flag3=False
	for i in range(len(s3)):
		if 65<=ord(s3[i])<=90:
			flag1=True
		if 48<=ord(s3[i])<=57:
			flag2=True
		if s3[i]=='_' or s3[i]=='@' or s3[i]=='$':
			flag3=True
	if len(s3)>=8 and flag1 and flag2 and flag3:
		return True
	return False

print("Function1 returns "+ str(end_begin_other("abc","aBCabXabc")))
print("Function2 returns "+ str(valid_password("ASDF12@23")))