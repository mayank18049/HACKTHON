#Name - Saugat Garwa
#RollNumber - 2018263
#Section - B
#Group - 8
#Date - 23/09/1028


def end_begin_other(s1,s2) :

	c = s1.lower()
	d = s2.lower()
	p = len(c)
	q = len(d)
	if (p>q) and (c[:q] == d) :
		#print("True")		
		return True 
	elif (p<q) and (d[:p] == c) :
		#print("True")		
		return True
	else :
		#print("False")
		return False
#end_begin_other("ABCoboidsoci","abc")
#end_begin_other("Abc","ABCconoAN")
#end_begin_other("abc","aBcsocib")
#end_begin_other("abc", "aCCjvokDp")

def valid_password(s3) :
	l = len(s3)
	leng =0
	cap = 0
	spe = 0
	dig = 0
	if l < 8 :
		print("False")
		return False
	elif l >= 8 :
		for i in s3 :
			if i.isupper() :
				cap = 1
				continue
			if i.isdigit() :
				dig = 1
				continue
			if (i == '@') or (i == '_') or (i == '$') :
				spe = 1
				continue
			if (leng == 0) and ((cap == 1) or (cap > 1)) and ((spe == 1) or (spe >1)) and ((dig ==1)or (dig > 0 )) :
				print("True")				
				return True
			else : 
				print("False")
				return False
#valid_password("ADCBJ_736sa")


























	
