#Midterm Lab Exam Set 2 - 2018
#Name : Shaunak Pal
#Roll Number : 2018098
#Sectoion : A
#Group : 2
#Date : 23/09/2018


def end_begin_other(s1,s2):
	if (len(s1)>len(s2)):
		s1, s2 = s2, s1

	s1=s1.lower()
	s2=s2.lower()
	
	if(s1 == s2[-len(s1) :] == s2[:len(s1)]):
		return True

	else:
		return False



def valid_password(s3):
	
	charset = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
	numset = ['0','1','2','3','4','5','6','7','8','9']
	specialset = ['_','@','$']

	flag = True


	if (len(s3) < 8):
		return False

	if(flag):
		for i in range(26):
			if charset[i] in s3:
				break
			if i==25 and charset[i] not in s3:
				return False

	if(flag):
		for i in range(10):
			if numset[i] in s3:
				break
			if i==9 and numset[i] not in s3:
				return False
	if(flag):
		for i in range(3):
			if specialset[i] in s3:
				break
			if i==2 and specialset[i] not in s3:
				return False

	return True

print("Function1 returns " + str(end_begin_other("abc","aBCabXabc")))
print("Function2 returns " + str(valid_password("ASDF12@23")))