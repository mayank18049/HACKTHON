#Midterm Lab Exam Set 2 - 2018
#Kartikay Sapra
#2018238
#B
#7
#2018/09/23


#function1
def end_begin_other(s1,s2):
	s1 = s1.lower()
	s2 = s2.lower()
	len1 = len(s1)
	len2 = len(s2)
	srev1 = s1[::-1]
	srev2 = s2[::-1]
	if len1 > len2:
		if s1[0:len2]==s2 and srev1[0:len2]==srev2:
			return True
		else:
			return False
	elif len2 > len1:
		if s2[0:len1]==s1 and srev2[0:len1]==srev1:
			return True
		else:
			return False

						

#function2
def valid_password(s3):
	
	ualpha = 'ABCDEFGHIJKLMNOPQRSTUVWX'
	num  = '0123456789'
	special = '_@$'
	
	ucount = 0
	numcount = 0
	specialcount = 0
	if len(s3)>=8:
		for i in s3:

			if i in ualpha:
				ucount += 1
			if i in num:
				numcount+=1
			if i in special:
				specialcount +=1
			
		if ucount==0 or numcount==0 or specialcount==0:
			return False
		else:
			return True
	else:
		return False		 							

#output
print('Function1 returns '+str(end_begin_other('abc','aBCabXabc')))
print('Function2 returns '+ str(valid_password('ASDF12@23')))		