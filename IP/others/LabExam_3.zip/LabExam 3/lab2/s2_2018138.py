#Midterm Lab Exam set 2 - 2018	
#Name : Debraj ghosh 
#Roll  no. : 2018138
#section : A
# group : 2
# Date : 23-09-18
#fuction 1
def end_begin_other(s1,s2):
	s1=str(s1)
	s2=str(s2)

	l1= len(s1)
	l2= len(s2)
	if l1>l2:
		var = s2.lower()
		b = s1.lower()
		if b[:l2] == var and b[-l2:]== var :

			return True 
		else:
			return False
	else:
		var = s1.lower()
		b = s2.lower()
		if b[:l1]==var and b[-l1:] == var :

			return True 
		else:
			return False








# #function2 
def valid_password(s3):
	s3 = str(s3)
	b = len(s3)
	c = False
	a = False 
	d = False	
	for m in s3 :
		if m in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ':
			c = True
			
		elif m == '_' or m == '@':
			a= True
			
		elif m in '012345689':
			d = True
			
		
	if b >= 8 :
		z = True
	else :
		z = False

	if c and a and d and z:

		return True 
	else :
		return False
 

		
