#Midterm Lab Exam Set 2 - 2018
#Name:Mohammad Basil Asad
#Roll No.: 2018397
#Section:B
#Group:6
#Date:23/09/2018



def end_begin_other(s1,s2):
	s1=s1.upper()
	s2=s2.upper()
	

	if len(s1)<len(s2):
		if (s1==s2[0:len(s1)]) and (s1==s2[len(s2)-len(s1):]):
			
			return True
		else:
			
			return False
	else:
		if s2==s1[0:len(s2)] and s2==s1[len(s1)-len(s2):]:
			
			return True

		else:
			
			return False

def valid_password(s3):
	k=2	
	if len(s3)>=8:
		for i in range(0,len(s3)):
			if 'Z'>=s3[i]>='A':
				for i in range(0,len(s3)):
					if '9'>=s3[i]>='0':
						if ('_' in s3) or ('@' in s3) or ('$' in s3):
							
							
							k='1'

			
	if k=='1':
		return(True)
	else:
		return False
	
print("Function1 returns "+ str(end_begin_other("abc","aBCabXabC")))
print("Function2 returns "+ str(valid_password('a_bCdB$1G')))

