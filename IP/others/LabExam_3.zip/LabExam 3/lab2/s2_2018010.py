#mid term lab exam
#akash malik
#20182010
#Group 2
#Sec A
def end_begin_other(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	if(len(s1)>len(s2)):
		if(s1[0:len(s2)]==s2 and s1[-(len(s2)):]==s2):
			return(True)
		else:
			return(False)
	else:
		if(s2[0:len(s1)]==s1 and s2[-(len(s1)):]==s1):
			return(True)
		else:
			return(False)

def valid_password(s3):
	if(len(s3)<8):
		return False
	i=0	
	while i<len(s3):
		if(s3[i].isdigit()==True and s3[i].ischar()==True  and (s3[i]=='@' or s3[i]=='_' or s3[i]=='$')):
			return True
print("function1 is " + str(end_begin_other('abc', 'aBCabXabc')))
print('function2 returns' + str(valid_password("ASDF12@23")))

		
			

