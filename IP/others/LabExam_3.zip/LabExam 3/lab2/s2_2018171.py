#Midterm Lab Exam Set 2- 2018
#Name: Prashansa Tanwar
#Roll Number: 2018171	
#Section: A
#Group: 3
#Date: 23/09/2018
#function1
def end_begin_another(s1,s2):
	a=s1.upper
	b=s2.upper
	x=s1.rfind(s2)
	y=s2.rfind(s1)
	if s1[0]==s2[0] and s1==s2[y:] or s2==s1[x:]:
		return True
	else:
		return False 




#function2
def valid_password(s3):
	a1=s3.find('_')
	a2=s3.find('@')
	a3=s3.find('$')
	
	b=s3.find('0')
	c=s3.find('1')
	d=s3.find('2')
	e=s3.find('3')
	f=s3.find('4')
	g=s3.find('5')
	h=s3.find('6')
	i=s3.find('7')
	j=s3.find('8')
	k=s3.find('9')

	
	if len(s3)>=8 and a1!=-1 and a2!=-1 and a3!=-1 and b!=-1 and c!=-1 and d!=-1 and e!=-1 and f!=-1 and g!=-1 and h!=-1 and i!=-1 and j!=-1 and k!=-1 :
		return True
	else:
		return False

#print output
print("function1 returns " + str(end_begin_another("abc", "aBCabXabc")))
print("function2 returns " + str(valid_password("ASDF12@23")))
