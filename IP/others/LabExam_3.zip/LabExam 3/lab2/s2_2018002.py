# Midterm Lab Exam Set 2 - 2018	
# NAME : ABHINAV SHARMA
# ROLL NO. 2018002
# SECTION A
# GROUP 2
# DATE: 23/09/2018

#FUNCTION 1

def end_begin_other(s1,s2):
	x = len(s1)
	y = len(s2)
	if x>y:
		a = s1[x-y:].lower()
		b = s1[0:y].lower()
		s2l = s2l.lower()
		if a==s2l and b==s2l:
			return True
		else:
			return False

	else:
		a = s2[y-x:].lower()
		b = s2[0:x].lower()
		s1l = s1l.lower()
		if a==s1l and b==s1l:
			return True
		else:
			return False

#FUNCTION 2
def valid_password(s3):
	y = len (s3)
	if y>=8:
		t = ''
		count=0
		for t in s3:
			if t.isalpha==True:
                                count = count + 1
                                if count>0:
                                        if s3.islower()==True:
                                                return False
                                        else:
                                                a = ''
                                        count2 = 0
                                        for a in s3:
                                                if a.isdigit==True:
                                                        count2 = count2 +1
                                                        if count2>0:
                                                                if ('_' in s3) or ('@' in s3) or ('$' in s3):
                                                                        return True
                                                                 else:
                                                        return False



#PRINT OUTPUT
print("Function1 returns " + str(end_begin_other("abc,aBCabXabc")))
print("Function2 returns " + str(valid_password("ASDF12@3")))

