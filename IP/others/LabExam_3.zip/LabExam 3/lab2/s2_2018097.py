#Midterm Lab Exam Set 2 - 2018
#Name: 			SHASHWAT AGGARWAL
#Roll Number: 	2018097
#Section:		A
#Group:			1
#Date:			23 September 2018



#fucntion1
def end_begin_other(s1,s2):
	if len(s1)>len(s2):
		x=s2.lower()
		y=s1.lower()
	else:
		x=s1.lower()
		y=s2.lower()

	if x==y[:len(x)] and x==y[-len(x):]:
		return True
	else:
		return False

#function2
def valid_password(s3):
	length=len(s3)
	upper=0
	character=0
	digit=0

	for i in range (length):
		if s3[i].isupper():
			upper=1
		if s3[i]=="_" or s3[i]=="@" or s3[i]=="$":
			character=1
		if s3[i].isdigit():
			digit=1

	if length>=8 and upper>0 and character>0 and digit>0:
		return True
	else:
		return False


#print output
print("Function1 returns " + str(end_begin_other("abc","aBCabXabc")))
print("Function2 returns " + str(valid_password("ASDF12@23"))) 