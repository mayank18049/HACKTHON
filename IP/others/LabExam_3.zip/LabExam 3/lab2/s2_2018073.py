#Midterm Lab Exam Set 2
#Name - Prince Yadav
#Roll no. - 2018073
#Section - A
#Group - 1
#Date - 23:09:2018

#function 1
def end_begin_other(s1,s2):
	l1=len(s1)
	l2=len(s2)
	c1=0
	if l1>l2:
		for i in range(l2):
			if (s1[l1-l2-i]==s2[i].lower() or s1[l1-l2-i]==s2[i].upper()):
				c1+=1
			elif (s1[i]==s2[i].lower() or s1[i]==s2[i].upper()) :
				c1+=1
			else:
				c1=c1
		if c1==l2:
			return True
		else :
			return False
	elif l2==l1:
		if s1==s2:
			return True
		else:
			return False
	else :
		for i in range(l1):
			if(s2[l2-l1-i]==s1[i].lower() or s2[l2-l1-i]==s1[i].upper()):
				c1+=1
			elif (s2[i]==s1[i].lower() or s2[i]==s1[i].upper()) :
				c1+=1
			else:
				c1=c1
		if c1==l1:
			return True
		else :
			return False

#function2 
def valid_password(s3):
	l1=len(s3)
	cnt=0
	cnt1=0
	cnt2=0
	if l1>7:
		c1=True
	for i in s3 :
		if s3[i]>='A'and s3[i]<='Z':
			cnt+=1
	if cnt>0:
		c2=True
	for i in s3 :
		if s3[i]>='0'and s3[i]<='9':
			cnt1+=1
	if cnt1>0:
		c3=True
	for i in s3 :
		if s3[i]==' 'or s3[i]=='@'or s3[i]=='$' :
			cnt2+=1
	if cnt2>0:
		c3=True
if __name__ == '__main__':
	s1=input('entr  string1')
	s2=input('entr  string2')
	s3=input('entr  string3')
	x=end_begin_other(s1,s2)
	y=valid_password(s3)
	print('Function1 returns'+ str(x))
	print('Function2 returns'+ str(y))




