#Done by Shriya Srinivasan
#Rollno: 2018193
#Group: 01
#Section: A


#function1
def end_begin_other(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	if len(s1)>len(s2):
		pos1=s1.find(s2)#Looks for s2 at the beginning of s1
		if pos1==0:
			pos2=s1.rfind(s2)#Looks for s2 at the end of s1
			if pos2==len(s1)-len(s2):
				return True	
			else:
				return False
		else:
			return False
	else:
		pos1=s2.find(s1)#Looks for s1 at the beginning of s2
		if pos1==0:
			pos2=s2.rfind(s1)#Looks for s1 at the end of s2
			if pos2==len(s2)-len(s1):
				return True	
			else:
				return False
		else:
			return False
	
				
	



#function2
def valid_password(s3):
	countcap=0
	countdigit=0
	countsp=0
	if len(s3)>=8:
		for letter in s3:
			if ord(letter)>=65 and ord(letter)<=90:
				countcap+=1
			if ord(letter)>=45 and ord(letter)<=57:
				countdigit+=1
			if letter=="_" or letter=="@" or letter=="$":
				countsp+=1
		if countcap>=1 and countdigit>=1 and countsp>=1:
			return True
		else:
			return False
	else:
		return False


#print output
print ("Function1 returns " + str(end_begin_other("abc","aBCabXabc")))
print ("Function2 returns " + str(valid_password("ASDF12@23")))
