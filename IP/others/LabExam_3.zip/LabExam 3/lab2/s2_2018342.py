#Mohammad Sajeel Khan
#2018342
#B7

def end_begin_other(s1,s2):
	x1 = s1.lower()
	x2 = s2.lower()
	n = len(x1)
	m = len(x2)
	if x2[0:n] == x1 and x2[m-n:] == x1:
		return(True)
	elif x1[0:m] == x2 and x1[n-m:] == x2:
		return(True)
	else:
		return(False)

def valid_password(s3):
	p = len(s3)
	if p>=8:
		for i in range(0,p):
			if (s3[i]=='_' or s3[i]=='@' or s3[i]=='$') and (s3[i]=='0' or s3[i]=='1' or s3[i]=='2' or s3[i]=='3' or s3[i]=='4' or s3[i]=='5' or s3[i]=='6' or s3[i]=='7' or s3[i]=='8' or s3[i]=='9'):
				return(True)
			else:
				return(False)
	else:
		return(False)




print("Function1 returns" + str(end_begin_other("abc","aBCabXabc")))
print("Function2 returns" + str(valid_password("ASDF12@23")))