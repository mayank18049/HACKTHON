#Midterm Lab Exam set 2 - 2018
Name: SHUBHAM MANJHI
Roll Number: 2018194
Section : A
Group : 2
Date : 23/9/2018


#Function1


def end_begin_other(s1,s2):
if s1 = s2.isupper()
   s1 = s2.islower()
   s2 = s1.isupper()
   s2 = s1.islower
if s1 == s2[0:2]:
   return True
elif:
   s1 == s[-3:]
   return True
elif:
   s2 == s1[0:2]
   return True
elif:
   s2 == s1[-3:]
   return True
else:
return False














#Function2

def valid_pasward(s3):
 if len(s3) >= 8:
   (any(c.isupper()   for c in s3)) or (any(c.isdigit()   for c in s3)) or (any(c.isdigit()   for c in s3)) or  (("@" in s) or ("_" in s) or ("$" in s))
     return True
 else:
     return False









# print output
print("Function1 returns " + str(end_begin_other("abc,aBCabXabc")))
print("Function2 returns " + str(valid_pasward("ASDF12@23")))














#print Output

