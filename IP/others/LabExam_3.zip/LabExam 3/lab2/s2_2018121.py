#Mdterm Lab Exam Set2- 2018
#Name:Yashdeep Prasad
#Roll no:2018121
#Section:A
#Grp:1
#Date:23:09:2018


def end_begin_other(s1,s2):
    L1=len(s1)
    L2=len(s2)
    s2=s2.upper()
    s1=s1.upper()
    if L1>L2:
        (s2==s1[:L2-1] or s2==s1[L1-L2-1:])
        return True

    elif L2>L1:
        (s1==s2[:L1-1] or s1==s2[L2-L1-1:])
        return True

    else:
        return False
            
print('Function1 returns' + str(end_begin_other('abc','aBCabXabc')))   

def valid_password(s3):
            if len(s3)>=8:
                a1=s3.count('-') or a3=s3.count('$') or a2=s3.count('@')
                a>=1 or a2>=1 or a3>=1
                for i in range(1,len(s3)+1):
                    count1=s.find(0-9)
                count1>=1
            return True
        
            else:
                return False
print('Function2 returns' + str(valid_password('ASDF12@23')))

                
                
                
                
                
                
    
        
