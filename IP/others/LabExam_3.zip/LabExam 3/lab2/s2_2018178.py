#Midterm Lab Exam Set 2 - 2018
#Rahul Singh
#2018178
#section A
#group 2
#23-09-2018
def end_begin_other(first_string,second_string):
	a= len(first_string)
	b= len(second_string)
	if a >= b:#checks which string is bigger and makes a the larger string and b the smaller string
		a = first_string
		b = second_string
	else:
		a=second_string
		b=first_string
	a= a.lower()
	b= b.lower()
	index1 = a.find(b)
	index2 = a.rfind(b)
	if index1==0 and index2==len(a)-len(b):
		return True
	else:
		return False
	
def valid_password(third_string):
	j='ABCDEFGHIJKLMNOPQRSTUVWXYZ'
	k='_@$'
	l = '0123456789'
	d=(len(third_string)>=8)
	for i in third_string:
		a=(i in j)
		if a==True:
			a=1
			break
	for i in third_string:
		b= i in k
		if b==True:
			b=1
			break
	for i in third_string:
		c= i in l
		if c==True:
			c=1
			break
	if  d==True and a==1 and b==1 and c==1 :
		return True
	else:
		return False
print("Function1 returns "+str(end_begin_other("abc","aBCabXabc")))
print("Function2 returns "+str(valid_password("ASDF12@23")))
