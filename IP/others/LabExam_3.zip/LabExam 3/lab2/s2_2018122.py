# midterm lab exam set 2- 2018
# Name : Abhishek Kumar
# roll no : 2018122
# section : A
# Group : 2
# Date : 23/09/2018



# function1
def end_begin_other(s1,s2):
s1 = input()
s2 = input()
 a = len(x)
 b = len(y)
for i in range(len(s1)-1)
if (s1[0:b-1] and s[a-1:b] == 0)
  
  print true
else 
print false






# function2
def valid_password(s3):
	x = input("enter the password:")
	for i in range(len(x)-1)
if ((x.len()>=8) and (x.isupper() == 1) and (x.isdigit() == 1) and (x.punc(x) == 1))

print true
else 
print false

#print output
print("function1 returns" + str(end_begin_other("abc,aBCabXabc")))
print("function2 returns" + str(valid_password("ASDF12@23")))
