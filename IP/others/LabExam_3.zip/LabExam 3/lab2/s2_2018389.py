# Midterm Lab Exam Set 2 - 2018
# Name: DEEPI GARG
# Roll Number: 2018389
# Section: B
# Group: 6
# Date: 23-09-2018

#function1
def end_begin_other(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	if len(s1)<len(s2):
		lsmall=len(s1)
		lbig=len(s2)
		if s2[0:lsmall]==s1 and s2[(lbig-lsmall):]==s1:
			return True
		else:
			return False
	else:
		lsmall=len(s2)
		lbig=len(s1)
		if s1[0:lsmall]==s2 and s1[lbig-lsmall:]==s2:
			return True
		else:
			return False

#function2
def valid_password(s3):
	if len(s3)<8:
		return False
	else:
		al=1
		up=0
		dig=0
		sp=0
		for i in s3:
			if i>='a' and i<='z':
				al=1
			if i>='0' and i<='9':
				dig=1
			if i>='A' and i<='Z':
				up=1
			if i=='_' or i=='@' or i=='$':
				sp=1
		if al==1 and up==1 and dig==1 and sp==1:
			return True
		else:
			return False

#print output
print("Function1 returns " + str(end_begin_other("abc","aBCabXabc")))
print("Function2 returns " + str(valid_password("ASDF12@23")))

