#Midterm Lab Exam Set 2- 2018
#Name: Pranay Jain
#Roll Number: 2018358
#Section: B
#Group: 7
#Date: 23/09/2018
#You need to implement both the functions given in this module.
#function1
from string import *
def end_begin_other(s1,s2):
	l1=len(s1)
	l2=len(s2)
	s1=s1.lower()
	s2=s2.lower()
	if l1<l2:
		if s1==s2[0:l1] and s1==s2[-l1:l2]:
			return True
	elif l2<l1:
		if s2==s1[0:l2] and s2==s1[-l2:l1]:
			return True
	else:
		return False

#function2
def valid_password(s3):
	l=len(s3)
	for x in s3:
		if x.isupper:
			b=True
		else:
			b=False
		if x.find('_')>=0 or x.find('@')>=0 or x.find('$')>=0:
			c=True
		else:
			c=False
		if x.isdigit:
			d=True
		else:
			d=False
	if l>=8 and b and c and d:
		return True
	else:
		return False

#print output
print("Function1 returns "+str(end_begin_other(s1,s2)))
print("Function2 returns "+str(valid_password(s3)))
