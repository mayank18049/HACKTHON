#Midterm Lab Exam Set 2 - 2018
#Name : Nishant Grover
#Roll Number : 2018399
#Section : B
#Group : 8
#Date : 23 September 2018

#function1
def end_begin_other(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	if(((s1[-len(s2):]==s2) or (s2[-len(s1):]==s1)) and ((s1[:len(s2)]==s2) or (s2[:len(s1)]==s1))):
		return True
	else :
		return False
#function2
def valid_password(s3):
	if(len(s3)>=8):
		countupper=0
		countnum=0
		countspecial=0
		for i in s3:
			if(i.isupper()):
				countupper+=1
			elif(i.isdigit()):
				countnum+=1
			elif(i=='_' or i=='@' or i=='$'):
				countspecial+=1
		if(countupper>=1 and countnum>=1 and countspecial>=1):
			return True
		else:
			return False
	else:
		return False
#print output
print("Function1 returns " + str(end_begin_other("abc","aBCabXabc")))
print("Function2 returns " + str(valid_password("ASDF12@23")))