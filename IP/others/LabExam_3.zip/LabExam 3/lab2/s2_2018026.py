"""
Name: Atishay Jain
Section: A
Roll number: 2018026
Group: 2

Func1 checks if string is present in start and end of another
func2 checks if the password is valid according to a given criteria

"""
def end_begin_other(s1,s2):
	if len(s1)>len(s2):
		a=s1
		s1=s2
		s2=a
	s2=s2.lower()
	s1=s1.lower()
	if s1==s2[:len(s1)] and s1==s2[-(len(s1)):]:
		return True
	else:
		return False

#print(end_begin_other("hi","HIyhi"))
#print(end_begin_other("hidfnwHe","HE"))
#print(end_begin_other("hi","HIyh"))
#print(end_begin_other("hdfnwHe","HE"))

def valid_password(s3):
	f=0
	if len(s3)>7:
		f=1
	t=0
	g=0	
	h=0
	k=1
	for i in s3:
		if not((ord(i)>=97 and ord(i)<=122) or (i=='_' or i=='@' or i=='$') or (ord(i)>47 and ord(i)<58) or (ord(i)>=65 and ord(i)<=90)):
			k=0 #I have assmued that the alphabet between [a-z] means that no extra characters can be used
		if ord(i)>=65 and ord(i)<=90:
			t=1
		if i=='_' or i=='@' or i=='$':
			g=1
		if ord(i)>47 and ord(i)<58:
			h=1
	if f==1 and t==1 and g==1 and h==1 and k==1:
		return True
	else:
		return False

#print(valid_password("Hello"))
#print(valid_password("aaac1@SD"))
#print(valid_password("#aaac1@SD"))
#print(valid_password("aaaa123@fe"))
#print(valid_password("Hellooo@"))
#print(valid_password("Yayay12345"))

if __name__=="__main__":
	print("Function1 returns " + str(end_begin_other("abc","aBCabXabc")))
	print("Function2 returns " + str(valid_password("ASDF12@23")))
