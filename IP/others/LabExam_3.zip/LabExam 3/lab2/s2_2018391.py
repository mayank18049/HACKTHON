#midterm Lab Exam Set-2 2018
#Name : Hardik Saini
#Roll Number: 2018391
#Section : B
#Group : 8
#Date : 23/09/2018
#function1
def end_begin_other(s1,s2):
	s1 = s1.lower()
	s2 = s2.lower()
	x = len(s1)
	y = len(s2)
	#print(s1,s2,x,y)
	if (s2[-x:] == s1) and (s2[0:x] == s1):
		return True
	elif (s1[-y:]==s2) and (s1[0:y] == s2):
		return True
	else:
		return False

def valid_password(s3):
	x1 = len(s3)
	al = 0
	AL = 0
	dg = 0
	sp = 0
	for i in (s3):
		if (i>="A") and (i<="Z"):
			AL = AL+1
		elif (i>="0") and (i<="9"):
			dg = dg+1
		elif (i =="@" or i=="_" or i =="$"):
			sp = sp+1
	if (x1>=8 and AL>0 and dg>0 and sp>0):
		return True
	else:
		return False

print("Function1 returns "+ str(end_begin_other("abc","abCabXabc")))
print("Function2 returns " + (str(valid_password("aaac1@SD"))))