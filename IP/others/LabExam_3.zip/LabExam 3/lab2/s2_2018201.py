def end_begin_other(s1,s2):
    t1=""
    t2=""
    
    for c in s1:
        if c.isalpha():
            c=c.lower()
            t1=t1+c
        else:
            t1=t1+c
    for c in s2:
        if c.isalpha():
            c=c.lower()
            t2=t2+c
        else:
            t2=t2+c
    q1=len(s1)
    q2=len(s2)
    if q1-q2>=0:
        if (t2==t1[q1-q2:] and t2==t1[:q2]):
            
            return (True)
        else:
            return (False)
    elif q2-q1>=0:
        if (t1==t2[q2-q1:] and t1==t2[:q1]):
            
            return (True)
        else:
            return(False)
    
    
        



def valid_password(s3):
    q=len(s3)
    digitcount=0
    splcharcount=0
    upperlettercount=0
    if q >=8:
        for c in s3:
            if c.isdigit():
                digitcount+=1
            if (c=='_' or c=='@' or c== '$'):
                splcharcount+=1
            if c.isupper():
                upperlettercount+=1
        if upperlettercount>=1 and splcharcount>=1 and digitcount>=1:
            return (True)
        else:
            return (False)
    else:
        return (False)

                
print("Function1 returns "+str(end_begin_other("abc","aBCabXabc")))
print("Function2 returns "+str(valid_password("ASDF12@23")))
