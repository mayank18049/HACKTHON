#Midterm Lab Exam Set 2 - 2018
#Sarthak Negi
#2017097
#A1
#23/09/2018






#function1
def end_begin_other(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	len1=len(s1)
	len2=len(s2)
	if(len1>=len2):
		if(s1[:len2]==s2 and s1[len1-len2:]==s2):
			return True
		else:
			return False
	else:
		if(s2[:len1]==s1 and s2[len2-len1:]==s1):
			return True
		else:
			return False







#function2
def valid_password(s3):
	count1=0
	count2=0
	count3=0
	cond1=len(s3)>=8
	for i in s3:
		if(65<ord(i)<90):
			count1+=1
		if (48<ord(i)<57):
			count2+=1
		if (i=="_"or i=="@" or i=="$"):
			count3+=1
	cond2=count1>=1
	cond3=count2>=1
	cond4=count3>=1
	if (cond1 and cond2 and cond3 and cond4):
		return True
	else:
		return False









#print output
print("Function1 returns " + str(end_begin_other("abc","aBCabXabc")))
print("Function2 returns " + str(valid_password("ASDF12@23")))