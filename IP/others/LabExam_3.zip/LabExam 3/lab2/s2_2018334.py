def end_begin_other(s1, s2):
	lent_s1 = len(s1)
	lent_s2 = len(s2)
	ad = s1.upper()
	af = s2.upper()
	if lent_s1 > lent_s2:
		first = ad[:3]
		last = ad[lent_s1-3:lent_s1+1]
		if first == last == af:
			return True
		else:
			return False
	elif lent_s2 > lent_s1:
		first1 = af[:3]
		last1 = af[lent_s2-3:lent_s2+1]
		if first1 == last1 == ad:
			return True
		else:
			return False




def valid_password(s3):
	pass_len = len(s3)
	char1 = s3.find('@')
	char2 = s3.find('_')
	char3 = s3.find('$')
	dig0 = s3.find('0')
	dig1 = s3.find('1')
	dig2 = s3.find('2')
	dig3 = s3.find('3')
	dig4 = s3.find('4')
	dig5 = s3.find('5')
	dig6 = s3.find('6')
	dig7 = s3.find('7')
	dig8 = s3.find('8')
	dig9 = s3.find('9')
	aa = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
	for x in aa:
		if aa.find(x) == True:
			if pass_len>=8 and (char3==True or char2==True or char1==True) and (dig0==True or dig1==True or dig2==True or dig3==True or dig4==True or dig5==True or dig6==True or dig7==True or dig8==True or dig9==True):
				return True
			else:
				return False
		else:
			return False			



