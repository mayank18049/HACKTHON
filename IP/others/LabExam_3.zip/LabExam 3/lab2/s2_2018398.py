# Midterm Lab Exam Set 2 - 2018
# Name: Mrinal
# Roll Number: 2018398
# Section: B
# Group: 7
# Date: 23/09/2018

#function1
def end_begin_other(s1,s2):
	str1=s1.lower()
	str2=s2.lower()
	m=len(str1)
	n=len(str2)
	if m>n:
		begin=str1[:n]
		end=str1[-n:]
		if(begin==str2) and (end==str2):
			return True
		else:
			return False
	elif n>m:
		begin=str2[:m]
		end=str2[-m:]
		if(begin==str1) and (end==str1):
			return True
		else:
			return False
	else:
		return True #length of both strings same case

#function2
def valid_password(s3):
    n=len(s3)
    upperalpha='ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    digit='0123456789'
    check1=0;check2=0;check3=0;check4=0;check5=0
    if(n>=8):
        for j in upperalpha:
            if s3.find(j)>=0:
                check2=1
        for k in digit:
            if s3.find(k)>=0:
                check3=1
        if(s3.find('_')>=0) or (s3.find('@')>=0) or (s3.find('$')>=0):
            check4=1
        if(check2==check3==check4==1):
            return True
    return False                               
            
if __name__=="__main__":
    print("Function1 returns " + str(end_begin_other("abc","aBCabXabc")))
    print("Function2 returns " + str(valid_password("ASDF12@23")))

    
