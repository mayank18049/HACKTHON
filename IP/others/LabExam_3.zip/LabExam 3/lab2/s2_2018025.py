
# midterm lab exam set2-2018
# name:asmit kumar singh
# roll no.-2018025
# section:A
# group:1
# date:23/9/2018

#FUNCTION1
def end_begin_other(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	t=s1[-1:0:-1]
	d=s2[-1:0:-1]
	if (s1.find(s2)==0 and t.find(d)==0) or  (s2.find(s1)==0 and d.find(t)==0) :
		return True
		
	else:
		return False
#FUNCTION2
def valid_password(s3):
	f=0
	if len(s3)<8:
		f=1

	t=0
	for i in s3:
		if i.isupper():
			t=1
	if t==0:
		f=1

	t=0
	for i in s3:
		if i.isdigit():
			t=1
	if t==0:
		f=1

	t=0
	for i in s3:
		if i=='_' or i=='@' or i=='$':
			t=1

	if t==0:
		f=1
		
	if f==0:
		return True
	else:
		return False
	#PRINT OUTPUT
print("Function1 returns" + str(end_begin_other('abc','aBCabXabc')))

print("Function2 returns" + str(valid_password('ASDF12@23')))
