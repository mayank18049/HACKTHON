#midterm Lab Exam Set 2 - 2018
#Name: Osheen Sachdev
#Roll Number:: 2018059
#Section: A
#Group: 3
#Date: 23/09/18
#You need to implement both the functions given in this module

#Function 1

def end_begin_other(s1,s2):
	if len(s1)>len(s2):
		x=s1.lower()
		y=s2.lower()
	else:
		x=s2.lower()
		y=s1.lower()
	if x[:len(y)]==y and x[len(x)-len(y):]==y:
		return True
	else:
		return False

#Function 2:

def valid_password(s3):
	x1= len(s3)>7
	x2= not(s3.lower()==s3)
	x3= False
	for i in s3:
		if i.isdigit():
			x3=True
			break
	x4= False
	for i in s3:
		if i== '$' or i== '_' or i=='@':
			x4=True
			break
	return (x1 and x2 and x3 and x4)

#Print Output:
print('Function 1 returns',end_begin_other('abc','aBCabXabc'))
print('Function 2 returns',valid_password('ASDF12@23'))
