"""returns True if either othe string appear at the very end or very begining of other string"""
#name gauri shankar
def end_begin_other(s1,s2):
    s1=s1.lower() #convert both into lower case for comparison
    s2=s2.lower()
    x=len(s1)
    y=len(s2)
    if y>x:
       
             if s2[0:x]==s1 or s2[y-x:]==s1
                 return True
             else:
                 return False
    elif x>y:
        
             if s1[0:y]==s2 or s1[x-y:]==s2:
                 return True
             else:
                 return False
    else:
             if s1==s2:
                 return True
             else:
                 return False


def valid_password(s3):
     y=len(s3)
     a=0
     b=0
     c=0
     for i in range(y):
         if s3[i].isdigit()==True:
               a=a+1
         if s3[i]=="_" or s3[i]=="@" or s3[i]=="$":
               b=b+1
         if s3[i].isupper()==True:
               c=c+1
     if y>=8 and a>=1 and b>=1 and c>=1:
               return True
     else:
               return False


