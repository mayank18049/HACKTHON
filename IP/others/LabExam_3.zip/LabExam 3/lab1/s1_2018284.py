# Midterm Lab Exam set 1 - 2018
# Name - Harman
# Roll Number - 2018284
# Section - B
# Group - 5
# Date - 23 sept 2018



# Function1

def end_other(s1,s2):






	a=s1.find("abc")
	len1=len(s1)
	b=s2.find("abc")
	len2=len(s2)
	
	if a>=0 and b>=0:


		if s1[a:len1]=="abc":
			s11=s1[a:a+3]




	
		if s2[b:len2]=="abc":
			s22=s2[b:b+3]


	
	

			if s11==s2[b:b+3] or s22==s1[a:a+3]:
				return True
				

		
	else:
		return False
		


end_other("abc","abXabc")
	


# http://192.168.1.89


def count_code(s3):



	count=0

	a=s3.find("s4")
	if a<0:
		for x in "abcdefghijklmnopqrstuvwxyz":
			
			s4="co"+x+"e"
			a=s3.find("s4")
			

	
		

	
	if a>=0:
		count=count+1
		s3=s3[a+4:]
		for a in s3:
			s3=s3.find("code")
			a=a+4
			return count	

	else:
	
		return 0

		


		



print ("Output1 is " + str(end_other("Hiabc","abc")))	
print ("Output2 is " + str(count_code("cozexxcope")))





			






