#Midterm Lab Exam Set 1 - 2018
#Name: Gaurav Meena
#Roll Number: 2018233
#Section: B
#Group: 2
#Date: 23-09-2018


from string import ascii_lowercase

def reverseString(string):
	length = len(string)
	a = ''
	for i in range(length-1, -1, -1):
		a += string[i]
	return a



def end_other(s1, s2):
	length_s1 = len(s1)
	length_s2 = len(s2)

	if length_s2 > length_s1:
		b = reverseString(s2)
		c = reverseString(s1)
		for i in range(length_s1):
			if (c[i] == b[i]) or (c[i].lower() == b[i]) or (c[i] == b[i].lower()):
				continue
			else:
				return False
		return True
		
	elif length_s1 > length_s2:
		b = reverseString(s1)
		c = reverseString(s2)
		for i in range(length_s2):
			if (c[i] == b[i]) or (c[i].lower() == b[i]) or (c[i] == b[i].lower()):
				continue
			else:
				return False
		return True

	else:
		b = reverseString(s1)
		c = reverseString(s2)
		for i in range(length_s2):
			if (c[i] == b[i]) or (c[i].lower() == b[i]) or (c[i] == b[i].lower()):
				continue
			else:
				return False
		return True


def count_code(s3):
	count = 0
	d = -1

	while True:
		d = s3.find("co", d+1)
		
		if d == -1:
			break

		elif s3[d + 3] == 'e':
			if s3[d + 2] in ascii_lowercase:
				count += 1

	return count

print("Output1 is " + str(end_other("ABckigjabc", "abc")))
print("Output2 is " + str(count_code("cozejfhfuhwuffcope")))
