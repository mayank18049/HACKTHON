# Midterm Lab Exam Set 1 - 2018
# Name : Bhavam Hans
# Roll Number : 2018228
# Section : B
# Group : 5
# Date : 23/09/18
# function1
def end_other(s1,s2):
	n=0
	n=0
l1=len(s1)
l2=len(s2)
if (l1<l2):
	l=l1
else:
	l=l2
m=l-1
i=m
while (i>=0):
	k1=ord(s1[i])
	k2=ord(s2[i])
	if (k1==k2):
		n+=1
	elif (k1+32==k2):
		n+=1
	elif (k1-32==k2):
		n+=1
	i-=1
if (n==1):
	return(True)
else :
	return(False)

# function2
def count_code(s3):
	l=len(s3)
	i=l-1
	n=0
	while(i>=0):
		if(s3[i]=='e' and s3[i-2]=='o' and s3[1-3]=='c'):
			n+=1
		i-=1
	return(n)

#print output
print("output1 is " + str(end_other(Hiabc","abc")))
print("output2 is " + str(count_code("cozexxcope")))
