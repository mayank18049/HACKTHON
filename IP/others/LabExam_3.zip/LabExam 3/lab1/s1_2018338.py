# Midterm Lab Exam Set 1 - 2018
# Name: Jatin Kumar Jadoun
# Roll Number : 2018338
# Section : B
# Group : 3
# Date : 23.09.18
#function1
def end_other(string1,string2):
	length1 = len(string1)
	length2 = len(string2)
	check = True
	if(length1>length2):
		diff = length1-length2
		var = 0
		string1 = string1.upper()
		string2 = string2.upper()
		while(diff<length1):
			if(string1[diff]==string2[var]):
				check = True
				diff = diff+1
				var = var+1
			else:
			check = False
			diff = length1
	elif(length1<=length2):
		diff = length2-length1
		var = 0
		string1 = string1.upper()
		string2 = string2.upper()
		while(diff<length2):
			if(string2[diff]==string2[var]):
				check = True
				diff = diff+1
				var = var+1
		else:
				check = False
				diff = length2
return check
#function2
def count_code(string3):
	find = 0
	count = 0
	check = True
	length3 = len(string3)
	while(search<length3):
		find = string3.index['co',find]
		if(string3[find+3]=='e'):
			check = True
			count = count+1
			find = find+1
		else:
			check = False
return count
#print output
print("Output1 is "+ str(end_other(string1,string2)))
print("Output2 is "+ str(count_code(string3)))
				
				
	
	

				
			
				
	
