#Name: Abhishek Pratap Singh
#Roll No: 2018211
#Section: B
#Group: 4
#Date: 23/09/2018

#192.168.1.89


#function 1

def end_other(s1,s2):	
	a=s1.lower()
	b=s2.lower()
	if a.endswith(b) or b.endswith(a):
		#print ("True")
		return True		
	else:

		#print ("False")
		return False
#end_other(s1,s2)	



def count_code(s3):
	sum=0
	for i in range(len(s3)):
		if s3[i:i+2] =="co" and s3[i+3:i+4] =="e":
			sum=sum+1
	#print(sum)		
	return sum		
#count_code(s3)			
