#Midterm Lab Exam Set 1-2018
#Name:LOVNEESH
#Roll Number:2018395
#Section:B
#Group-4
#date-23-09-2018
#You need to implement both the functions given in this module.
#function1
import string
def end_other(s1,s2):
	x=s1.islower()
	y=s2.islower()
	a=len(s1)
	b=len(s2)
	if a>b:
		if (x[a-b:]==y):
			return True
		else :
			return False
	elif b>a:
		if (y[b-a:]==x):
			return True
		else :
			return False
	else:
		return True		

def count_code(s3):
	a=s3.islower()
	b=a.count('co'+''+'e')
	return b
print ("Output1 is "+str(end_other("Hiabc","abc")))
print ("Output2 is "+str(count_code("cozexxcope")))	



