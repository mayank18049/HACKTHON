#Midterm Lab Exam Set 1 - 2018
#Name - Samarth Chauhan
#Roll Number - 2018410
#Group - 3
#Section - B
#Lab Number - 320
#Date - 23/09/2018


#function1
def end_other(s1,s2):
	len1=len(s1)
	
	len2=len(s2)
	
	if(len1>=len2):
		if s1[len1-3:len1].lower()==s2.lower():
			return True
		else:
			return False

	else:
		if s2[len2-3:len2].lower()==s1.lower():
			return True
		else:
			return False












#function2
def count_code(s3):
	
	index=-1
	count=0

	for x in s3:

		index=index+1

		if x=='c':
			if (s3[index+1]=="o")and(s3[index+3]=="e"):
				count=count+1
				
			
	return count


