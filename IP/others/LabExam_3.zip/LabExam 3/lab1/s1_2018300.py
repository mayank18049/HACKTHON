#MIDTERM LAB EXAM SET-1 - 2018
#NAME:PRAKHAR GUPTA
#ROLL NUMBER: 2018300
#SECTION:B
#GROUP:5
#DATE:23/9/18
#function1
def end_other(s1,s2):
	s1=s1.lower()              
	s2=s2.lower()
	n1=len(s1)                 #to find length of the string
	n2=len(s2)
	if n2>n1:                  
		if s1==s2[n2-n1:]:     #checking if s1 is at the very end of s2
			return True
		else:
			return False
	elif n1>n2:
		if s2==s1[n1-n2:]:     #checking if s2 is at the very end of s1
			return True	
		else:
			return False
	else:
		if s1==s2:           #cheking if both the strings are equal
			return True
		else:
			return False
#function2
def count_code(s3):
	q='abcdefghijklmnopqrstuvwxyz'
	k=0                       

	for i in q:
		s='co'+i+'e'
		c=s3.count(s)
		k+=c
	return k
#print output
print ('Output1 is'+str(end_other('Hiabc','abc')))
print ('Output2 is'+str(count_code('cozexxcope')))

