#midterm lab exam set 1-2018
#NAME:SHAILESH
#ROLLNO.:2018264
#SECTION:B
#GROUPNO.:1
#date:23-09-2018
 




def end_other(s1,s2):
	if (len(s1)>len(s2)):
		x=(s2.lower())
		y=(s1[-len(s2):].lower())
		if x==y :
			return True
		else:
			return False
	else:
		x=(s1.lower())
		y=(s2[-len(s1):].lower())
		if x==y :
			return True
		else:
			return False


print(end_other('Asme', 'QWasde'))









def count_code(s3):
	q=0
	p=0
	if("co" in s3):
		n=s3.count('co')
		p=s3.index('co',)
		if(s3[p+int(3)]=='e'):
			q=s3.count('co'+s3[p+int(2)]+'e')
		return q
print(count_code('codedfsdfcoecode'))



