#Name : Om Khandade
#Roll No. : 2018289
#Section : B
#Group : 2

def end_other(s1,s2) :
	a=len(s1)
	b=len(s2)
	if s1[-b:].title()==s2.title() or s2[-a:].title()==s1.title():
		return True
	else:
		return False

def count_code(s3) :
	count=0
	a=0
	for x in range (0,len(s3)):
		if s3[a:a+2]=="co" and s3[a+3]=="e":
			count =count+1
		a=a+1
	return count

print("output1 is " + str(end_other("hiAbc","jsnkjnshiABc")))
print("output2 is " + str(count_code("cozexxcodexxco2e")))