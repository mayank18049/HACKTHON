#Midterm Lab Exam Set 1 - 2018
#Name: Sai Pranav Varada Raghunath
#Roll Number: 2018418
#Section: B,Group: 3
#Date: 23-9-18
from string import *
def end_other(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	if (s1.endswith(s2)==True) or (s2.endswith(s1)==True):
		print("Output1 is True")
	else:
		print("Output1 is False")
def count_code(s3):
	m=0
	while c in range(65,123):
		x=chr(c)
		y='co'+x+'e'
		n=s3.count(y)
		m=n+m
	print("Output2 is"+m)
