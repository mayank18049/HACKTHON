# Name - Mohit Kumar
# Section - B
# Group - 1
# Roll No. - 2018344
# Date : 23.09.2018
# function1
# We need to implement both the functions given in this module.

# function1

def end_other(s1 , s2) :
	
	if :
	 x == input(end_other(s1 , s2))
	 x = output1
	 s1 = true
	 s2 = false

	elif :
		s1 = end_other("Hiabc")
		print(s1)

	elif :
		s1 = end_other("abc")
		print(s1)

	elif :
		s1 = end_other("Abc")
		print(s1)

	elif :
		s1 = end_other("HiaBc")
		print(s1)

	elif :
		s1 = end_other("abXabc")
		print(s1)
	
	else :
		s2 = end_other("defx")
		print(s2)
	
	return output1 

# function2

def count_code(s3) :
	
	if x == input(count_code(s3))
	   x = output2 
	   x1 = str"0"
	   x2 = str"1"
	   x3 = str"2"

	elif :
		s3 = count_code("aaacodebbb")
		print(x2)

	elif :
		s3 = count_code("cpdexxcode")
		print(x2)
	elif : 
		s3 = count_code("cozexxcope")
		print(x3)
	else :
		s3 = count_code("aabbccc")
		print(x1)

	return output2		

	"""

#print output
print("output1 is" + str(end_other("Hiabc","abc")))
print("output2 is" + str(count_code("cozexxcope")))