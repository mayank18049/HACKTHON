# Name : Shaney waris
# Roll Number : 2018308
# Section : B
# Group : 5
# Date : 23/09/2018

def end_other(s1,s2) :
	if s1.find(s2)==True :
		return(bool(1))
	elif s2.find(s1)==True :
		return(bool(1))
	else : 
		return(bool(0)) 

def count_code(s3) :
count=0
c=len(s3)
for i range (1,c+1,1) :
	if s3.find("co"+chr(97)<s3[i]<chr(122)+"e") :
		count=count+1
print(count)


print("Output is " + str(end_other("Hiabc","abc")))
print("Output is " + str(count_code("cozexxcope")))
