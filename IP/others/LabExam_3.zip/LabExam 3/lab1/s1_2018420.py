#Midterm Lab Exam Set 1 - 2018
#Vishesh Agrawal
#2018420
#B-5
#23rd September 2018
def end_other(s1,s2):
	l1=len(s1)
	l2=len(s2)
	if l1>l2:
		s2=s2.lower()
		a=s1[l1-l2:l1]
		a=a.lower()
		if a==s2:
			return True
		else:
			return False
	if l2>l1:
		s1=s1.lower()
		a=s2[l2-l1:l2]
		a=a.lower()
		if a==s1:
			return True
		else:
			return False

def count_code(s3):
	s=s3
	count=0
	l=len(s)
	for i in range(0,l):
		if s[i:i+2]=="co" and s[i+3]=="e" and 97<=ord(s[i+2])<=123:
			count=count+1	
		else:
			count=count
	return count
			
#print output
print("Output1 is " + str(end_other("Abc","HIaBc")))
print("Output2 is " + str(count_code("aabbccd")))
	
