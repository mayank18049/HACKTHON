#Midterm Exam Set 1- 2018
#Name: Utsav Singla
#Roll Number: 2018321
#Section: 2
#Group: B
#Date: 23/09/2018

def end_other(s1,s2):
	'''Lower case both strings s1,s2'''
	LowerS1= s1.lower()
	LowerS2= s2.lower()
	'''checks if string ends with the other one'''
	if LowerS1.endswith(s2):
		return True
	elif LowerS2.endswith(s1):
		return True
	else:
		return False

def count_code(s3):
	LowerS3 = s3.lower()
	count = 0
	countC = LowerS3.count('c')
	
	for r in range(countC):
		indexC= LowerS3.index('c')
		if LowerS3[indexC+1]=='o' and LowerS3[indexC+3]=='e':
			count+=1
			LowerS3 = LowerS3[indexC+1:len(s3)]
			
		else:
			LowerS3 = LowerS3[indexC+1:len(s3)]
	return count


print("output1 is " + str(end_other("Hiabc","abc")))
print("output5 is "+ str(count_code("cozexxcope")))
