#MidtermLab Exam Set 1 - 2018
#Name: Swastik Jain
#Roll Number:2018269
#section:B
#group:6
#Date:23/09/2018
#function1
def end_other(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	if s1 in s2:
		b=s2.index(s1)
		if s1==s2[b:]:
			return("True")
	elif s2 in s1:
		c=s1.index(s2)
		if s2==s1[c:]:
			return("True")
	else:
		return("False")
	return("False")
#function2
def count_code(s3):
	c="abcdefghijklmnopqrstuvwxyz"
	q=0
	for i in c:
		y=("co"+i+"e")
		q=q+s3.count(y)
	return(q)
print("Output1 is " + str(end_other("Hiabc","abc")))
print("Output2 is " + str(count_code("cozexxcope")))