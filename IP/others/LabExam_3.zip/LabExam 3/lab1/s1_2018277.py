#Midterm Lab Exam Set 1-2018
#Name: Aneesha Lakra
#Roll Number: 2018277
#Section: B
#Group: 6
#Date: 23/9/18
import string
#function 1
def end_other(s1,s2):
    n=len(s1)
    x=s1[(n-3):n]
    m=string.tolower(x)
    n=string.tolower(s2)
    for c in range(m):
        if (m[c]==n[c]):
            return (True)
        else:
            return (False)


#function 2
def count_code(s3):
    a=0
    index=s3.find('c')
    while n<(len(s3)):
        if (index!=-1):
            if((s3[index+1]=='o') and (s3[index+3]=='e')):
                a=a+1
                n=s3.find(index,'c')
                index=n 
            else:
                return (0)
        else:
            return (0)              



print ("Output1 is " + str(end_other("Hiabc","abc")))
print ("Output2 is " + str(count_code("cozexxcope")))

