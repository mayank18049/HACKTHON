def end_other(s1,s2):
	s1 = input("entre a string")
	s2 = input("entre 2nd string")
	if s1 = s1[:s2+1] or s2 = s2[:s1+1]:
		return True
	else:
		return False

def count_code(s3):
	s3 = input("entre any string")
	x = s3.find("code")
	return x
