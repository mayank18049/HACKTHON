#Midterm Lab Exam set 1 - 2018
#Jaspreet Saka 
#2018237
#23 August 2018
#group : 6
#section : B

def end_other(s1,s2) :
	x=s1.lower()
	y=s2.lower()
	n=len(s2)
	m=len(s1)
	if x[m-n:]==y :
		return True
	else :
		return False 

def count_code(s3):


	s=str(s3)
	x=s.lower()
	y=x.count("co")


	return y


print("Output1 is " + str(end_other("hiabc","abc")))

print("Output2 is " + str(count_code("cozexxcope")))







































































































