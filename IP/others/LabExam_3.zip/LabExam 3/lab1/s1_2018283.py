# Midterm Lab Exam Set 1 - 2018
# Name: Gagan Malik
# Roll Number: 2018283
# Section: B
# Group: 4
# Date: 23-09-2018

def end_other(s1,s2):
	s1 = str(s1)
	s2 = str(s2)
	x = s1.lower()
	y = s2.lower()
	if x.endswith(y) == True:
		return(True)
	elif x.endswith(y) == True:
		return(True)
	else:
		return(False)

print("Output1 is " + str(end_other('Hiabc','abc')))

def count_code(s3):
	s3 = str(s3)
	if s3.find("co") != -1:
		x = s3.find("co")
		if s3[x + 3] == "e":
			r = s3.count("co")
			return(r)
		else:
			return(0)
	else:
		return(0)

print("Output2 is " + str(count_code("cozexxcope")))

