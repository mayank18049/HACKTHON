# Midterm Lab Exam Set 1 - 2018
# Name - Prutyay Gautam
# Roll Number - 2018403
# Section - B
# Group - 4
# Date - 23/09/18

#Function1
def end_other(s1,s2) :
	s1 = s1.lower()
	s2 = s2.lower()
	n1 = len(s1)
	n2 = len(s2)
	if(n1>n2):
		a = s1.find(s2)
		if(a == (n1-n2)):
			print("Output1 is True")
		else:
			print("Output1 is False")
	else:
		a = s2.find(s1)
		if(a == (n2-n1)):
			print("Output1 is True")
		else:
			print("Output1 is False")


#Function2
def count_code(s3):
	a = "abcdefghiklmnopqrstuvwxyz"
	q = 0
	for i in a:
		f = "co" + i + "e"
		q = q + s3.count(f)
	print("Output2 is " + str(q))

	
	

