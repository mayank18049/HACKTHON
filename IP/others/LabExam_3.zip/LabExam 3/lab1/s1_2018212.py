#Midterm Lab Exam Set 1 - 2018
#NAME:ABHISHEK RAJ
#ROLL NO:2018212
#SECTION:B
#GROUP:5
#DATE:23/09/2018

#function1

def end_other(s1,s2):
    s1=s1.lower()
    s2=s2.lower()
    p=len(s1)
    s=len(s2)
    if p>s:
       if s1[p-s:]==s2:
          return True
       else:
          return False
    elif s>p:
         if s2[s-p:]==s1:
            return True
         else:
            return False
    elif s==p:
         if s1==s2:
            return True
         else:
            return False


#function2
def count_code(s3):
     count=0
     for i in range(len(s3)):
         if s3[i]=="c" and s3[i+1]=="o" and s3[i+3]=="e":
                count=count+1
     return count
         
print("Output1 is "+str(end_other("Hiabc","abc")))
print("Output2 is "+str(count_code("cozexxcope")))

