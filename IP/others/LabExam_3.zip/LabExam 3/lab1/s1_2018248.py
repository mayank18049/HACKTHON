#Midterm Lab Exam Set 1 - 2018
#Nikhil Krishnan
#2018248
#Section B
#Group 1
#23/09/18


def end_other(s1, s2):
	s1 = str(s1)
	s2 = str(s2)
	s1 = s1.lower()
	s2 = s2.lower()
	len1 = len(s1)
	len2 = len(s2)
	if len1 > len2 :
		if s1[-(int(len2)):] == s2 :
			return True
		else :
			return False	
	elif len2 > len1 :
		if s2[-(int(len1)):] == s1 :
			return True
		else :
			return False
	else:
		if s1 == s2:
			return True
		else:
			return False


#print Output
print ("Output1 is" + str(end_other("Hiabc","abc")))



def count_code(s3):
	length = len(str(s3))	
	s3 = str(s3)
	#n is the number of times "co e" occurs
	n = 0
	#a is the index of "co"
	a = s3.index("co")
	if a < 0 :
		return 0
	else:
		for i in range(0,length-2):
			if s3[a+3] == "e" :
				n = n+1
			return n

#print output
print ("Output2 is"+str(count_code("cozexxcope")))
			

















		 
