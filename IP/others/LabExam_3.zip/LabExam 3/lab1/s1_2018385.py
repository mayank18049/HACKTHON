def end_other(s1,s2):
	l1=len(s1)
	l2=len(s2)
	s1=s1.lower()
	s2=s2.lower()
	if(s1[l1-l2:]==s2)or(s2[l2-l1:]==s1):
		return True
	else:
		return False

def count_code(s3):
	l3=len(s3)
	count=0
	letters='abcefghijklmnopqrstuvwxyz1234567890'
	for i in letters:

		s="co"+i+"e"
		if s3.find(s)!=-1:
			count=count+1
		return count
	
	


