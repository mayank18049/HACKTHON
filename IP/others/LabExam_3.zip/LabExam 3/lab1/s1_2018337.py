# midterm lab exam set 1 - 2018
#name - Himanshu Garg
#roll no. - 2018337
#sec - B
#grp - 2


#function 1
def end_other(s1,s2):
	s1 = s1.lower()
	s2 = s2.lower()
	lens1 = len(s1)
	lens2 = len(s2)

	if s2[-1::-1]==s1[-1:(-1*lens2)-1:-1]:
		return True
	elif s1[-1::-1]==s2[-1:(-1*lens1)-1:-1]:
		return True
	else:
		return False


#function 2
def count_code(s3):
	lens3=len(s3)
	count = 0
	for i in range(lens3-3):
		if s3[i:i+2]+s3[i+3]=='coe':
			count=count+1
	return count


'''
s1 = str(input('enter s1 : '))
s2 = str(input("enter s2 : "))
ans1 = end_other(s1,s2)
print("ans of end_other is : %s" %ans1)
s3 = str(input("enter s3 : "))
ans2 = count_code(s3)
print("ans of count_code is : %s" %ans2)


'''