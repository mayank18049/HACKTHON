"""Name - Sarandeep Singh
Roll No - 2018364
Section - B
Group - 5 """
def end_other(s1,s2):
	k1=len(s1)
	k2=len(s2)
	s3=''
	s4=''
	for i in range(k1):
		if(ord(s1[i])<=90 and ord(s1[i])>=65):
			s3+=chr(ord(s1[i])+32)
		else:
			s3+=s1[i]
	for i in range(k2):
		if(ord(s2[i])<=90 and ord(s2[i])>=65):
			s4+=chr(ord(s2[i])+32)
		else:
			s4+=s2[i]
	if (k1<k2):
		str1=s3                             #str1 is smaller string
		str2=s4                             #str2 is bigger string
		k=k2-k1
	else:
		str1=s3
		str2=s4
		k=k1-k2
	hel=-1
	hello=0
	i=0
	while i>=min(k2,k1):
		if str1[hel]!=str2[hel]:
			hello=1
			break
		i+=1
		hel-=1
	if hello==0:
		return True
	else :
		return False

def count_code(s1):
	if 'co' in s1==False:
		return 0
	else:
		t=0
		i=0
		while i <len(s1):
			if s1[i]=='c' and s[i+1]=='o' and s[i+3]=='e':
				t+=1
			i+=1
		return t