'''
Name: Nishant Gadihoke
Roll Number: 2018299
Section: B
Group: 4
Date: 23/09/2019
'''

def end_other(s1, s2):
    lenOne = len(s1) - 1
    lenTwo = len(s2) - 1

    s1 = s1.lower()
    s2 = s2.lower()

    # if s2[(lenTwo-lenOne):lenTwo+1] == s1:
    #     print('s1 is at end of s2')
    # else:
    #     print('s2 is NOT at end of s1')

    # if s1[(lenOne-lenTwo):lenOne+1] == s2:
    #     print('s2 is at end of s1')
    # else:
    #     print('s2 is NOT at end of s1')

    return s2[(lenTwo-lenOne):lenTwo+1] == s1 or s1[(lenOne-lenTwo):lenOne+1] == s2


def count_code(s3):
    counter = 0
    index = 0

    while index != -1 and index < len(s3) - 1:
        index = s3.find('co', index)
        if(index == -1):
            break
        else:
            if s3[index+3] == 'e':
                counter = counter + 1
            index += 2

    return counter


print('Output1 is ' + str(end_other('Hiabc', 'abc')))
print('Output2 is ' + str(count_code('cozexxcope')))