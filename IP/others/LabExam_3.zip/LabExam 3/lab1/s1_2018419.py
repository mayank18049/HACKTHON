#Midterm lab Exam Set 1-2018
#Name: Vikas Mahto
#Roll Number:2018419
#section: B
#Group:4
#Date: 23/09/2018
#function1
def end_other(s1,s2):
	m=s1.lower()
	n=s2.lower()
	x=len(m)
	y=len(n)
	if (m[x:x-y]==n[y:x-y] or m[y:y-x]==n[x:x-y]):
		return True
	else :
	    return False
	    print(x)
	    print(y)
	    print(m)
	    print(n)
#function2
def count_code(s3):
	w=s3.islower()
	z= w.count("code")
	return z  
	v=w.count("co"+ +"e")
#print output
print("output1 is "+str(end_other("Hiabc","abc")))
print("output2 is "+ str(count_code("codexxcode")))