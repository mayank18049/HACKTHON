#Midterm Lab Exam Set - 2018
#Name: Aditya Sharma
#Roll Number: 2018274
#Section: B
#Group: 3
#Date: 23-09-2018
#You need to implement both the  functions given in this module.
#function1
def end_other(s1,s2):
	s1 = s1.lower()
	s2 = s2.lower()
	len_s1=len(s1)
	len_s2=len(s2)
	if len_s1>len_s2:
		if s1.rfind(s2)!=-1 and s1.rfind(s2)+len_s2==len_s1:
			return True
		else:
			return False
	elif len_s2>len_s1:
		if s2.find(s1)!=-1 and s2.rfind(s1)+len_s1==len_s2:
			return True
		else:
			return False
	elif len_s2==len_s1:
		if s1 == s2:
			return True
		else:
			return False
 		 		
#function 2
def count_code(s3):
	n=0
	q=1
	flag = 0
	find = 'co'
	len_s3 = len(s3)
	while n <= len_s3-1:
		if q!=n:
			q = n
			a_index = s3.find(find,n)
			if a_index != -1 and a_index+3<=len_s3-1:
				if s3[a_index+3]=='e':
					flag += 1
					n = a_index+3
			else:
				n = a_index
		else:
			break
	return flag
#print Output
print("Output1 is "+ str(end_other("hiabc","hiabc")))
print("Output2 is "+ str(count_code("aaaCodebbb")))