
def end_other(s1,s2):
	s1=s1.islower()
	s2=s2.islower()
	x1=len(s1)
	x2=len(s2)
	if(x1>x2):
		for k in range(0,x2,-1):
			if(s1[k]==s2[k]):
				k=k+1
			else:
				return False
		return True
	
	else:
		for k in range(0,x1,-1):
			if(s1[k]==s2[k]):
				k=k+1
			else:
				return False
		return True

	
	
def count_code(s3):
	x=len(s3)
	s=s3.count('c')
	y=s3.count('o')
	z=s3.count('e')
	if(s==y and y==z and z==s):
		return s
	
	
	
		
		