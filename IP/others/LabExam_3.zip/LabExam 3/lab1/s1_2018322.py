# Midterm Lab Exam Set 1 - 2018
# Name: Vasu Goel
# Roll Number: 2018322
# Section: B
# Group: 3
# Date: 23/09/2018

#function1
def end_other(s1, s2):
	x = s2
	y = s1
	if (len(s1) > len(s2)):
		x = s1
		y = s2
	if (x[len(x) - len(y):].lower() == y.lower()):
		return True
	else:
		return False

#function2
def count_code(s3):
	flag = True
	ind = 0
	count = 0
	while(flag):
		loc = s3.find('co', ind)
		if (loc == -1):
			flag = False
		else:
			ind = loc + 1
			if (loc + 3 < len(s3) and s3[loc+3] == 'e'):
				count += 1
	return count

#print output

# Testing Statements
#print(count_code("aaacodebbb"))
#print(count_code("cpdexxcode"))
#print(count_code("cozexxcope"))
#print(count_code("coe"))
#print(end_other("HiABC", "abc"))
#print(end_other("AbC", "HiaBc"))
#print(end_other("abc", "abXabc"))
#print(end_other("abc", "defx"))
