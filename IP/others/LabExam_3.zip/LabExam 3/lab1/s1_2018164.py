#MIDTERM LAB EXAM SET 3 -2018
#NAME: NISHANT CHAUBEY
#ROLL No.:2018164
#SECTION: A
#GROUP: 4
#DATE: 23-SEPTEMBER-2018

#function 1
def count_matchingChars(s1, s2):
	s1=s1.lower()
	s2=s2.lower()
	m = len(s1)
	n = len(s2)
	count = 0
	if (m>n):
		for x in s2:
			if (s1.find(x)!=-1):
				count+=1
				s1=s1.replace(x,'')
	elif (m<n):
		for x in s1:
			if (s2.find(x)!=-1):
				count+=1
				s2=s2.replace(x,'')
	return count

#function 2
	def valid_password(s3):
		if (len(s3)<8):
			return False
		has_alpha = False   # String has no alphabet
		has_Upper = False   # String has no Upper Case
		has_digit = False   # String has no digit
		has_char = False    # String has no Character
		has_palin = False   # String is palindrome
		for x in s3:
			if x.isalpha():
				has_alpha = True     
			elif x.isupper():
				has_Upper = True
			elif x.isdigit():
				has_digit = True
			elif (x=="_" or "@" or "$"):
				has_char = True
			elif (s3[x]!=s3[len-1-x]):
				has_palin = True
		if (has_alpha and has_Upper and has_digit and has_char and has_palin):
			return True
		else:
			return False
		



	
