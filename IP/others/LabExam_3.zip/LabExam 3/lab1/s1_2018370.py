""" Midterm Lab Exam Set 1 - 2018
Name: Vaibhav Yadav
Roll number: 2018370
Section: B
Group: 3
Date: 23 September 2018
"""
def end_other(s1,s2):
	for s1 in s2:
		return('true')
	for s2 in s1:
		return('true')	
	
		return('false')

def count_code(s3):
	n=len(s3)
	count = 0
	i = 0
	if (s3[i] == 'c' and s3[i+1] == 'o' and s3[i+3] == 'e'):
		count+=1
		i+=1
		return(count)
	else:
		return('0')

print("Output1 is " + str(end_other("Hiabc","abc")))
print("Output2 is " + str(count_code("cozexxcope")))		
		
