#Midterm Lab Exam Set1 -2018
#name: Mukul Tomar
#roll number: 2018296
#section: B
#Group: 1
#Date: 23-09-2018
#function1
def end_other(s1,s2):
	sl1=s1.lower()
	sl2=s2.lower()
	l1=len(sl1)
	l2=len(sl2)
	s=0
	if l1>l2 :
		s=sl1[l1-l2:]
		if s==sl2 :
			return True
		else :
			return False
	if l2>l1 :
		s=sl2[l2-l1:]
		if s==s1:
			return True
		else :
			return False
#function2
def count_code(s3) :
	ss3=s3.lower()
	l3=len(ss3)
	#code="c"++"de"
	n=0
	for i in range(l3):
		a=ss3.find("c")
		b=ss3.find("de")
		aa=ss3[a+1]
		if b-a==2:
			ss3.replace(aa,"o")
		l=ss3.find("code")
		if l>=0:
			n+=1
	return n
			
		

#print output
print(end_other("hiabC", "AbC"))
print(count_code("asvjadcodedhcodejkbecode123#21ecode"))


