#Midterm Lab Exam Set 1-2018
# Name : Archit Agrawal
# Roll no : 2018221
# Section: B
# Group: 6 
# Date: 23/09/2018

def end_other(s1,s2):
	s1=s1.upper()				
	s2=s2.upper()
	flag=0
	a=len(s1)
	b=len(s2)
	if(a>b) :                       #If string s1 is greater than s2 then this means s2 will be present in s1
		i=0							#Hence this code first find out which is bigger and then search the smaller string in the bigger one
		for s in s2:
			if(s!=s1[a-b+i]):
				flag=5				
			i=i+1
	else :
		i=0
		for s in s1:
			if(s!=s2[b-a+i]):
				flag=5
			i=i+1

	if ( flag==5) :
		return False
	else:
		return True			

def count_code(s3):
	count=0						#This code first find the c in the code and then compare its next and next to next caharacter
	x=0
	i=0							
	l=len(s3)
	for s in s3 :
		if(s=='c'):
			if(i<l-3):				#This line takes care that thst if c is the last character then it will throw an error while comparing other 
				if(s3[i+1]=='o' and s3[i+3]=='e'):
					count=count+1

		i=i+1
	return count		

if __name__ == '__main__':
	print("Output1 is " + str(end_other("Hiabc","abc")))
	print("Output2 is " + str(count_code("cozexxcope")))




	

	
	
					
