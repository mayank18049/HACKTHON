# Midterm Lab Exam Set 1 -2018
# Name: Aanchal Bakshi
# Roll Number: 2018377
# Section: B
# Group: 2
# Date: 22 sep 2018
# You need to implement both the functions given in this module.
# function1
def end_other(s1,s2):
	s1=input("Enter the one string")
	s1=[0,r]
	s2=input("Enter the second string")
	s2[0,k]
	if s1[:r]==s2[:k]:
   
		returns(True)
	else:

		returns(False)

