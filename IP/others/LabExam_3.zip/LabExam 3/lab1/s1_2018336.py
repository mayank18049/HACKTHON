#Midterm Lab Exam Set 1- 2018
#Name : Gursimran Kaur
#Roll Number : 2018336
#Section : B 
#Group : 1
#Date : 23/09/2018

#To check the count of code, where d can be any other letter occuring in the string to be checked.
def count_code(s3):
	s=len(s3)
	count=0
	for v in range(s):
		if (s3[v]=='c' and s3[v+1]=='o' and s3[v+3]=='e'):
			count=count+1
	return count

#To check if one string is a substring of the other string or not
def end_other(s1,s2):
	s=len(s1)
	p=len(s2)

	if (s>p):
		c=s1[s-p:]
		if (c==s2):
			return True
		else :
			return False
	elif (p>s):
		q=s2[p-s:]
		if (q==s1):
			return True
		else :
			return False

s1=input('Enter the string :')
s2=input('Enter the string you want to check for :')
print("Output1 is",end_other(s1,s2))


s3=input("Enter the string to be checked :")
print("The no of counts are :",count_code(s3))
