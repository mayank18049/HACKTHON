# Midterm Lab Exam Set 1 -
# Name: Hrithik Malhotra
# Roll number: 2018236
# Section: B
# Group: 05
# Date: 23 September 2018
def end_other(s1,s2):
	s1=s1.upper()
	s2=s2.upper()
	len1=len(s1)
	len2=len(s2)
	if len2>len1:
		s2end=s2[len2-len1:]
		if s2end==s1:
			return True
		else:
			return False
	elif len1>len2:
		s1end=s1[len1-len2:]
		if s1end==s2:
			return True
		else:
			return False
	else:
		if s1==s2:
			return True
		else:
			return False
def count_code(s3):
	code=0
	for i in range(len(s3)-3):
		if s3[i]=='c' and s3[i+1]=='o' and s3[i+3]=='e':
			code+=1
	return code
print("Output1 is " + str(end_other("Hiabc","abc")))
print("Output2 is " + str(count_code("cozexxcope")))