# Midterm Lb Exam Set 1 - 2018
#Name:Chandan Gupta
#Roll Number:2018386
#Section:B
#Group:3
#Date:23 September 



def end_other(s1,s2):
	x1=len(s1)
	x2=len(s2)
	s1=s1.islower()
	s2=s2.islower()
	if x1>x2:
		if s1.find(s2,x1-3,x1-1)>0:
			return True

		else:
			return False

	else:
		if s2.find(s1,x2-3,x2-1)>0:
			return True
		else:
			return False


	


def count_code(s3):
	count=0
	for i in range(0,len(s3)):
		i=int(i)
		if s3[i,i+2]='co'
			if s3[i+3]=='e':
				count=count+1
	return count
