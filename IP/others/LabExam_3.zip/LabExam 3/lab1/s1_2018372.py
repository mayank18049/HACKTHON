#yash kanojia
#2018372
#grp 5
#sec-b
def end_other(s1,s2):
	if s1.find(s2)!=-1:
		return True
	else:
		return False
	
	

def count_code(s3):
	count=0
	n='co'
	if x.find(n)!=-1:
		m=x.find(n)
		n=x[m+3]
		if n=='e':
			count=count+1
		return count
		
print("output1 is" + str(end_other("hiabc"'"abc")))
print("output2 is" + str(count_code("cozexxcope")))

	

