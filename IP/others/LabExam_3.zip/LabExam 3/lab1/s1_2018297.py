#MUSKAN AGGARWAL
#2018297
#SECTION B GROUP 2

def end_other(s1,s2):
	a=s1.lower()
	b=s2.lower()
	x=len(s1)
	y=len(s2)
	if((x>y) and (a[x-y:]==b)):
		return True
	else:
		if((x<y) and (b[y-x:]==a)):
			return True
		else:
			if((x==y) and (a==b)):
				return True
			else:
				return False

def count_code(s3):
	l=len(s3)
	count=0
	for i in range (0,l-1):
		if((s3[i]=="c")and(s3[i+1]=="o")and(s3[i+3]=="e")):
			count=count+1
	return count

if __name__ == '__main__':
	print("Output1 is "+str(end_other("HiaBc","abc")))
	print("Output2 is "+str(count_code("cozexxcope")))