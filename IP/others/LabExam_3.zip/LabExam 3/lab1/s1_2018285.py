#Midterm Lab Exam Set 1 - 2018
#Name: Harsh Kumar
#Roll Number: 2018285
#Section: B
#Group: 6
#Date: 23/09/18


#function1

def end_other(s1,s2):
	l1 = len(s1)
	l2 = len(s2)
	d1 = s1.lower()
	d2 = s2.lower()
	if (l1>l2):
		if (d1[(l1-l2):] == d2):
			return True
		else:
			return False
	elif (l1<l2):
		if (d2[(l2-l1):] == d1):
			return True
		else:
			return False
	elif (l1==l2):
		if (d1==d2):
			return True
		else:
			return False
	else:
		return False

#function2

def count_code(s3):
	d3 = s3
	l3 = len(s3)
	c=0
	cc=0
	for x in range(0,l3):
		d3 = d3[cc:]
		i = d3.find("co")
		if (i!=-1):
			fc = d3[i+3]
			tc = d3[i+2]
			cc = tc.isalpha()
			if (cc and fc=='e'):
				c=c+1
			cc = (i+4)
		else:
			break
	return c
 
		
print ("Output1 is " + str(end_other("Hiabc","abc")))
print ("Output2 is " + str(count_code("cozexxcope")))
