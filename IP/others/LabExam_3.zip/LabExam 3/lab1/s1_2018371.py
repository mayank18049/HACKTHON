def each_other(s1,s2) :
a = str(input("enter value of a "))
b = str(input("enter value of b "))
c = str(input("enter value of c "))

if (s1==a+c or s2==b+c) ::

else :







def count_code(s3) :
s3 = str(input("enter value of s3 "))
c = int(no. of str(code)) 
