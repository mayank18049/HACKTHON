#Midterm Lab Exam Set 1 - 2018
#Name: SANYAM AGRAWAL
#Roll No: 2018261
#Section: B
#Group: 6
#Date: 23/09/18

#function1
def end_other(s1,s2):
    if len(s1)>=len(s2):
        big=s1
        small=s2
    else:
        small=s1
        big=s2
    if big[len(big)-len(small):].upper()==small.upper():
        return True
    else:
        return False

#function2
def count_code(s3):
    if len(s3)<4:
        return 0
    else:
        flag=0;count=0
        while 1:
            flag=s3.find("co",flag)
            if flag==-1 or len(s3)<=flag+3:
                return count
            elif s3[flag+2].islower() and s3[flag+3]=="e":
                    count+=1
                    flag+=1
            else:
                flag+=1

#print output
print("Output1 is " + str(end_other("Hiabc","abc")))
print("Output2 is " + str(count_code("cozexxcope")))
