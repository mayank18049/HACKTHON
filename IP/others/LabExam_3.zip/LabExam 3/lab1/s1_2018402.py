def count_code(s3):
	s='co'	
	i=0
	j=0
	while(i < len(s3)):
		if(s3[i:i+2]==s and s3[i+3]=='e'):
			j+=1
			i+=3
		i=i+1
	return j
def end_other(s1,s2):
	i=1
	j=0
	x=len(s1)
	y=len(s2)
	main=min(x,y)
	while(i<main):
		if(s1[-i]==s2[-i].upper() or s1[-i] == s2[-i].lower()):
			j=j+1
		i=i+1
	if(j>1):
		return True
	else :
		return False
print('Output1 is '+str(end_other('Hiabc','abc')))
print('Output2 is '+str(count_code('cozexxcope')))




	
