#	midterm lab exam set 1 - 2018
# Name: Anuj
# Roll Number: 2018220
# Section: B
# Group: 5
# Date: 23 Sep 2018
import string
def end_other(s1,s2):
	s1_size= len(s1)
	s2_size= len(s2)
	if s1_size>= s2_size:
		small= s2
		large= s1
	else:
		small= s1
		large= s2
	small = small.upper()
	large = large.upper()
	if (small[::-1]==large[s1_size::-1]):
		return(True)
	else:
		return(False)


def count_code(s3):
	start= 0
	n= len(s3)
	count= 0
	while(start<n):
		f1=s3.find('co',start,n)
		if f1== -1:
			return(0)
			
		else:
			if s3[f1+3] == 'e':
				count= count +1
				
			else:
				return(count)
				

			if count!= 0:
				return(count)
		start= start+3
			
print(str(count_code('copexxcoze')))




