#Midterm Lab Exam Set 1 - 2018
#Name:Aditya Singh	
# Roll Number:2018378
# Section:B
# Group:3
# Date:23 September 2018


#function1

def end_other(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	m=len(s1)
	n=len(s2)
	if m>n:
		x=s1.find(s2)
		if x==m-n:
			return  True
		else:
			return False
	else:
		x=s2.find(s1)
		if x==n-m:
			return True
		else:
			return False

#function2

def count_code(s3):
	p='abcdefghijklmnopqrstuvwxyz'
	d=0
	for i in p:
		x=s3.count('co'+i+'e')
		d=d+x
	return d


#print("Output1 is" + str(end_other("Hiabc","abc")))
#Output1 is True
#print("Output2 is" + str (count_code("cozexxcope")))
#Output2 is 2
