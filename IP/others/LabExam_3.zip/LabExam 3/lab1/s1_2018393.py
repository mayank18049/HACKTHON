#Midterm lab exam set 1 - 2018
#Name:Juhi Pandey
#Roll No:2018393
#Section:B
#Group:2


#function1
def end_other(s1,s2):
	flag=False
	count=0
	l1=len(s1)
	l1=int(l1)
	l2=len(s2)
	l2=int(l2)

	if (l2<l1):
		for i in range (1,l2):
			if(s1[-i]==s2[-i]):
				count+=1
		if (count==l2):
			flag=True


	else:
		for i in range (1,l1):
			if(s1[-i]==s2[-i]):
				count+=1
		if (count==l1):
			flag=True

	return flag

#function2
def count_code(s3):
	a=True
	x=int('0')
	count=0
	while(a==True):
		x=s3.find('c',x)
		x=int(x)
		if(x==-1):
			a=False
		else:
			if(s3[x+1]=='o' and s3[x+3]=='e'):
				count=count+1
	return count

#print output
print('Output1 is'+ str(end_other("Hiabc","abc")))
print('Output2 is'+ str(count_code("cozexxcope")))
