def end_other(s1,s2):
	l1=len(s1)
	l2=len(s2)
	s1=s1.lower()
	s2=s2.lower()
	if l1>l2:
		if s1[l1-l2:]==s2:
			return True
		else:
			return False
	elif l1<l2:
		if s2[l2-l1:]==s1:
			return True
		else:
			return False
	else:
		if s1==s2:
			return True
		else:
			return False




def count_code(s3):
	
	b=0
	for a in range(len(s3)-2):

		if s3[a]=='c' and s3[a+1]=='o' and s3[a+3]=='e':
			b+=1
	
	return b
