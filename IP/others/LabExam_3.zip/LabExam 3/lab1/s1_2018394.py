#KARAN CHAWLA
#2018394
#SECTION-B
#GROUP-3



def end_other(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	m=len(s1)
	n=len(s2)
	if m>n:
		if s2==s1[-n:]:
			return True
		else:
			return False
	elif m<n:
		if s1==s2[-m:]:
			return True
		else:
			return False
	else:
		if s1==s2:
			return True
		else:
			return False

def count_code(s3):
	count=0
	x=s3.find("co")
	while x<len(s3) and x!=-1:
		if s3[x+3]=='e':
			count+=1
		else:
			count=count
		x=s3.find("co",x+3)
	return count

