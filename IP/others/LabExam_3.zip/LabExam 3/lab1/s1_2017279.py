#angad yadav
#2017279
#b4



#def count_code(s3):
s=input(str("Enter the string: "))
#l=s.len()
#i=0
#for i in range(0,l):
	count=0
	if(s[i]=='c' and s[i+1]=='o' and s[i+3]=='e'):
		count=count+1
		i=i+1
			
		#return count
			
	print(count)


#print("Output2 is" + str(count_code("cozexxcope")))

def end_other(s1,s2):
s1=input("Enter the string: ")
s2=input("Enter the strin: ")
l1=s1.len()
l2=s2.len()
if(l1>l2)
for i

