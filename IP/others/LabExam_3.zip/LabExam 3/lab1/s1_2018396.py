# name : manav kumar jaiswal 
# roll no : 2018396
# section :b
# group :5

def end_other(s1,s2) :
	a = len(s1)
	b = len(s2)
	if a >= b :
		c = b
		p = s1[::-1]
		d = p[:c]
		e = d[::-1]
		if e.lower() == s2.lower() :
			return ('true')
		else :
			return ('false')
	else :
		c = a
		p = s2[::-1]
		d = p[:c]
		e = d[::-1]
		if e.lower() == s1.lower() :
			return ('true')
		else :
			return ('false')


def count_code(s3) :
	while True :
		a = s3.find("co")
		b = s3[a:].find('e')
		if b == 1 :
	 		i+=1
	 		s3 = s3[a:]
	 		return(i)
	 	else:
	 		return (i)
	 		break	
print("output is " + str(end_other("Hiabc","abc"))
print("output is" + str(count_code("cozexxcope")))	

