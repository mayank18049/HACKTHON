'''IP LAB EXAM 
   NAME    : RACHIT BHAYANA
   ROLL NO :2018301
   SECTION :B
   GROUP   :6
   BRANCH  :CSD
   '''

def end_other(s1,s2):
	S1=s1.lower()
	S2=s2.lower()
	l1=len(S1)
	l2=len(S2)
	if S1[l1-l2:]==S2:
		return True
	else:
		return False	



def count_code(s3):
	count=0
	l=len(s3)

	for c in range(l):
		if s3[c]=='c':
			if s3[c:c+2]=='co':
				if s3[c+2].isalpha():
					if s3[c+3]=='e':
						count+=1	
	return count

