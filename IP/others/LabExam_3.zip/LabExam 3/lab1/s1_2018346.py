#midterm lab exam set 1-2018
#name=mukesh yadav
#secton=b
#group=3
#date=23/09/2018
#function 1
def end_other(s1,s2):
    m=len(s1)
    n=len(s2)
    k=s1.upper()
    l=s2.upper()
    if k[(m-n):m]==l or l[n-m:n]==k:
        return True
    else:
        return False
def count_code(s3):
    a=s.index('co')
    d=s.count('co'+s[a+2]+'e')
    return d
#PRINT OUTPUT
print("output1 is" + str(end_other(s1,s2)))
print("output2 is" + str(count_code(s3)))
        
    
