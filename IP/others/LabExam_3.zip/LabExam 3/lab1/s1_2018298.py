##Nikhil Yadav
##rollno-2018298



def end_other(s1,s2):
	m=s1.upper()
	n=s2.upper()
	r=(m.find(n))
	
	s=(n.find(m))
	if (s1[r:]==s2) or (s2[s:]==s1) :
		return True
	else 
		return False














def count_code(s3):
	
	
		
	result=0
	s1=s3.count('code')
	number=0
	while n[i]
	if(c!=0):
		m=s3.find('co')
			if(s3[m+2]!='d' and s3[m+3]=='e')
				number=number+1
				n=s3[m+4:]
				l=n.find('co')
					if(n[l+2]!=d and n[l+3]=='e')
					number=number+1
	result=s1+number 
	if(result==0)
		return 0
	else return result