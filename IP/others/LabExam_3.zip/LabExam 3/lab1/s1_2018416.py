# Midterm Lab Exam Set 1 - 2018
# Name: Sidhant
# Roll Number: 2018416
# Section: B
# Group: 1
# Date: 23/09/2018
# You need to implement both the functions given in this module.
#function1

def end_other(s1,s2)

s1=Hiabc
s2=abc

s1=input ('Hiabc')
s2=input ('abc')

if: ("s1","s2")
   print: 'True'
else:
     print 'False'




#function2

def count_code(s3):

s3= code

n1=a find('coae')
n2=b find('cobe')


"""""

count=0









#print output

print("Output1 is " + str(end_other("Hiabc","abc")))
print("Output2 is " + str(count_code("cozexxcope")))


"True"
"2.0"
