def end_other(s1,s2):
x=int(input("enter a string")
    if(s1=="x"+"abc"or"abc",s2=="abc" or s2=="x"+"abc"):
     return true
    elif(s1=="abc" and  s2=="abc"+"x"):
     return false
    else(s1=="abc"and s2=="x"):
     return false



def count_code(s3):
x=int(input(

















print("output is " + str(end_other("Hiabc","abc")))
print("output is " + str(count_code("cozexxcope")))
 
     
  
   


   
    
     
    
