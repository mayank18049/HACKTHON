#Midterm lab exam set1 -2018
#name: advika singh
#ROLL NO. 2018275
#SECTION-b
#GROUP-4
#DATE-21/09/2018
def end_other(s1,s2):
	
	x=s1.lower()
	
	y=s2.lower()
	
	ans=0
	if len(x)>len(y):
		ans=x.find(y)
	if len(y)>len(x):
		ans=y.find(x)

	if ans!=0:
		return True
	else:
		return False

	


def count_code(s3):
	
	y=len(s3)
	w=s3.find('c')
	
	count=0

	for w in range (0,y):
		if s3[w]=='c':
			if s3[w+1]=='o':
				
				if s3[w+3]=='e':
					count=count+1
					
				else :
					return 0
	return count		


if __name__ == '__main__':
	count_code()
	end_other()