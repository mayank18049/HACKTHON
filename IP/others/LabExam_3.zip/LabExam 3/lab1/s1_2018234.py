def end_other(s1,s2):

	l1=len(s1)
	l2=len(s2)
	if(l1>l2):
		n1=s1.lower().rfind(s2.lower())
		if(n1+l2==l1):
			return True
		else:
			return False
	else:
		n2=s2.lower().rfind(s1.lower())
		if(n2+l1==l2):
			return True
		else:
			return False


#print('Output1 is' + str(end_other('Hiabc','abc')))

def count_code(s3):
	l=len(s3)
	count=0

	n1=s3.find('co')
	if(s3[n1+3]=='e'):
		count=1	
	
	while(n1+3!=l-1):
		if(s3[n1+3]=='e'):
			n1=s3.find('co',n1+1)
			count=count+1
	return(count) 

print(count_code('rfwcozecozecoze'))


