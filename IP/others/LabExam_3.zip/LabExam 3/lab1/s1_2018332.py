#Midterm Lab Exam Set 1-2018
#Name:- Bhaskar Singh
#Roll Number:- 2018332
#Section :- B
#Group:- 05
#Date:- 23 September 2018

#function1
def end_other(s1,s2):
	a=len(s1)
	b=len(s2)
	x=0
	z=0
	while x in range(b+1):
		y=ord(s2[x])
		if 65<=y<=90:
			s2=s2.replace(s2[x],chr[y+32])

	while z in range(a+1):
		c=ord(s1[x])
		if 65<=c<=90:
			s1=s1.replace(s1[x],chr[y+32])

	if s1 in s2 or s2 in s1:
		return(bool(1))
	else:
		return(bool(0)) 



#function2
def count_code(s3):
	a=0
	count=0
	b=len(s3)
	while a<=b:
		x=s3.find("co",a)
		if x>=0:
			if s3[x+3]=="e":
				count+=1
		a=a+4
	
	return(count)

print("Output1 is " + str(end_other("Hiabc","abc")))
print("Output2 is "+ str(count_code("cozexxcope")))