#Midterm Lab Exam Set 1 - 2018
#Name: Manas
#Roll Number: 2018244
#Section: B
#Group: 5
#Date: 23-09-2018


from string import ascii_lowercase

def reverseString(string):
	length = len(string)
	revString = ''
	for i in range(length-1, -1, -1):
		revString += string[i]
	return revString



def end_other(s1, s2):
	length_s1 = len(s1)
	length_s2 = len(s2)

	if length_s2 > length_s1:
		revBigString = reverseString(s2)
		revSubString = reverseString(s1)
		for i in range(length_s1):
			if (revSubString[i] == revBigString[i]) or (revSubString[i].lower() == revBigString[i]) or (revSubString[i] == revBigString[i].lower()):
				continue
			else:
				return False
		return True
		
	elif length_s1 > length_s2:
		revBigString = reverseString(s1)
		revSubString = reverseString(s2)
		for i in range(length_s2):
			if (revSubString[i] == revBigString[i]) or (revSubString[i].lower() == revBigString[i]) or (revSubString[i] == revBigString[i].lower()):
				continue
			else:
				return False
		return True

	else:
		revBigString = reverseString(s1)
		revSubString = reverseString(s2)
		for i in range(length_s2):
			if (revSubString[i] == revBigString[i]) or (revSubString[i].lower() == revBigString[i]) or (revSubString[i] == revBigString[i].lower()):
				continue
			else:
				return False
		return True


def count_code(s3):
	count = 0
	firstIndexOfSubString = -1

	while True:
		firstIndexOfSubString = s3.find("co", firstIndexOfSubString+1)
		
		if firstIndexOfSubString == -1:
			break

		elif s3[firstIndexOfSubString + 3] == 'e':
			if s3[firstIndexOfSubString + 2] in ascii_lowercase:
				count += 1

	return count

print("Output1 is " + str(end_other("Hiabc", "abc")))
print("Output2 is " + str(count_code("cozexxcope")))