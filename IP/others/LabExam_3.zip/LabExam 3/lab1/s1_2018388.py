#Name- Deepanshu Kaushal
#Roll no.-2018388
#Section-B
#Group-05
def end_other(s1,s2):
	a=len(s1)
	l1=s1[a-1]
	b=len(s2)
	l2=s2[b-1]
	if l1==l2:
		return True
	else:
		return False
def count_code(s3):
	count=0
	a=len(s3)
	for i in range(1,a):
		f=s3.find('code',0,a)
		e=s3[f:f+4]
		if e=='code':
			count+=1
		else:
			count+=0
		print(count)
