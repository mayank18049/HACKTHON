#Aditya Rastogi
#2018273
#Grp 2, Sec. B

def end_other(s1,s2):
	n1=len(s1)
	n2=len(s2)
	s1=s1.lower()
	s2=s2.lower()
	if n1==n2:
		if s1==s2:
			return True
		else:
			return False
	elif n1>n2:
		if s2==s1[n1-n2:]:
			return True
		else:
			return False
	else:
		if s1==s2[n2-n1:]:
			return True
		else:
			return False

def count_code(s3):
	cnt=0
	n=len(s3)
	lv=0
	s1="co"
	r=s3.find(s1)
	if r==-1:
		return cnt
	else:
		for lv in range(0,n):
			pass
			lv=s3.index(s1,lv)
			if (s3[lv+3]=='e'):
				cnt=cnt+1
			else:
				cnt=cnt
		return cnt

print("Output1 is " + str(end_other("Hiabc","abc")))
print("Output2 is " + str(count_code("cozexxcope")))
