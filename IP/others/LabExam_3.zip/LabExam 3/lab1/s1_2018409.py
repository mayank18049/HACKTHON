#Midterm Lab Exam Set 1- 2018
# Name - Saad Ahmad
# Roll number- 2018409
# Section - B
# group - 2
# Date - 23/09/2018


def end_other(s1, s2):
	s2 = s2.lower()
	s1 = s1.lower()
	if s2 in s1:
		return True		
	else:
		return False
		
def count_code(s3):
	init = 0
	k1 = s3.find("c")
	if s3[k1+1] == "o" and s3[k1+3] == "e":
		init += 1
	k2 = s3.find("c", k1+1)
	if s3[k2+1] == "o" and s3[k2+3] == "e":
		init += 1	
	return init	
 
print("output1 is " + str(end_other("Hiabc", "abc")))
print("output2 is " + str(count_code("cozexxcope")))
			
