#Midterm Lab Exam Set 1- 2018
#Name:Navneet Agarwal	
#Roll Number:2018348
#Section:B
#Group:5
#Date:23/09/2018
#function1

def end_other(s1,s2):
	a=len(s1)
	b=len(s2)
	if s1.lower()==s2[b-a:b].lower():	
		return(True)
	elif s2.lower()==s1[a-b:a].lower():
		return(True)
	else:
		return(False)

def count_code(s3):
	count=0
	for i in range(len(s3)):
		if(i+3<len(s3)):	
			if(s3[i]=='c' and s3[i+1]=='o' and s3[i+3]=='e'):		
				count +=1
	return(count)
			 
#function2

#print output
print("Output1 is " + str(end_other("Hiabc","abc")))
print("Output2 is " + str(count_code("cozexxcope")))

