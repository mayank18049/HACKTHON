#Midterm Lab Exam Set 1 - 2018314
#Name       : Siddharth.V
#Rol Number : 2018314
#Section    : B
#Group      : 3
#Date       : 23/09/2018

import string

#function 1
def end_other(s1,s2):
	l1 = len(s1)
	l2 = len(s2)
	result = False
	if( string.lower( s1[l1-l2:] ) == string.lower(s2) ) :
		result = True
	elif( string.lower( s2[l2-l1:] ) == string.lower(s1) ):
		result = True
	return result
	

#funstion 2
def count_code(s3) :
	count = 0
	co_pos = s3.find('co')
	while co_pos != -1 :
		if( s3[ co_pos + 3 ] == 'e'):
			count+=1
		co_pos = s3.find('co' , co_pos+3)
	return count


#print output
print("Output1 is " + str(end_other("abc","lolXAc")))
print("Output2 is " + str(count_code("coexxcopecode")))