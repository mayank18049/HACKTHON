#Midterm Lab Exam Set 1-2018
# Name: Karishma Sinha
# Roll number: 2018339
# Section: B
# Group: 4
# Date: 23-09-2018
#function1
def end_other(s1,s2):
	import string
	#w1=lower(s1)
	#w2=lower(s2)
	w1=s1
	w2=s2

	l1=len(w1)
	l2=len(w2)
	if (w1 in w2):
		if(w2.find(w1)==l2-l1):
			return 'True'

	if (w2 in w1):
		if(w1.find(w2)==l1-l2):
			return 'True'
	else:
		return 'False'

def count_code(s3):
	
	count=0
	i=0
	for x in s3:
		
		if (s3[i]=='c'):
			if(s3[i+1]=='o' and s3[i+3]=='e'):
				count+=1


		i+=1
	return count

#print output	
print ("Output1 is"+ str(end_other("Hiabc","abc")))
print ("Output2 is"+ str(count_code("cozexxcope")))
