#Anshul Mendiratta
#2018219
#Group 4
#Sec B

#Function 1
import string
def end_other(s1, s2):
	s1 = s1.lower()
	s2 = s2.lower()
	if((s1[-len(s2):]==s2) or (s2[-len(s1):]==s1)):
		#print('True')
		return True
	else:
		#print('False')
		return False

#Function 2
def count_code(s3):
	l = []
	letters = string.ascii_letters
	for i in letters:
		reqd_word = str("co" + i + "e") 
		a = s3.count(reqd_word)
		l.append(a)
	#print(l)
	net = sum(l)
	#print(net)
	return net

#print output
print("Output1 is " + str(end_other("Hiabc", "abc")))
print("Output2 is " + str(count_code("cozexxcope")))
