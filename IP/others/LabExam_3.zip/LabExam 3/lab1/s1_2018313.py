#Midterm Lab Exam Set 1-2018
#Name: Siddharth Sadhwani
#ROll Number:2018313
#Section:B
#Group:2
#Date:23/09/2018
#Function 1
import string
def end_other(s1,s2):
	st1=s1.lower()
	st2=s2.lower()
	if st2[:]==st1[-len(st2):]:
		n=1
	elif st1[:]==st2[-len(st1):]:
		n=1
	else:
		n=0
	if n==1:
		return True
	elif n==0:
		return False
#Function 2		
def count_code(s3):	
	n=0
	st3=s3.lower()
	for i in range(len(st3)):
		if (i+3)<len(st3) and st3[i]=='c' and st3[i+1]=='o' and st3[i+3]=='e' :
			n=n+1
	if n!=0:
		return n
	else:
		return 0
#print output		
print ("output is" + str(end_other("Hiabc","abc")))	
print ("output is " + str(count_code("cozexxcope")))						


