#Midterm Lab Exam Set 1 - 2018
#Name: Shrey Kumar Singh
#Roll Number: 2018266
#Section: B
#Group: 3
#Date: 23rd Sept 2018

from string import *

def end_other(s1,s2):
	if s1[len(s1)-len(s2):].lower() == s2.lower() or s2[len(s2)-len(s1):].lower() == s1.lower():
		return True
	else:
		return False

def count_code(s3):
	count=0
	i=0
	while i<len(s3):
		if i<=len(s3)-4:
			if s3[i]=="c" and s3[i+1]=="o" and s3[i+3]=="e":
				count+=1
		i+=1
	return count

print("Output1 is " + str(end_other("Hiabc","abc")))
print("Output2 is " + str(count_code("cozexxcope")))