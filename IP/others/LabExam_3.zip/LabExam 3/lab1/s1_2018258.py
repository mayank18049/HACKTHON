# Midterm Lab Exam Set 1 - 2018
# Ritoma Sen
# 2018258
# Section B
# Group 3
# 23.09.2018

# function 1
def end_other(s1, s2):
	s1 = s1.lower()
	s2 = s2.lower()
	lens1 = len(s1)
	lens2 = len(s2)
	if lens1 > lens2:
		# checks to see whether s2 is appended to s1
		ends1 = s1[-lens2:]
		if (ends1 == s2):
			return True
		else:
			return False
	elif lens2 > lens1:
		# checks to see whether s1 is appended to s2
		ends2 = s2[-lens1:]
		if (ends2 == s1):
			return True
		else:
			return False
	else:
		# if length of both strings is same, checks to see whether both are same
		if (s1 == s2):
			return True
		else:
			return False

# function 2
def count_code(s3):
	start = 0
	count = 0
	while start <= (len(s3) - 4):
		indexC = s3.find('c', start)
		if (indexC != -1):
			if (s3[(indexC + 1)] == 'o') and (s3[(indexC + 3)] == 'e'):
				count += 1
			else:
				count += 0
			start = indexC + 4
		else:
			count += 0
			break
	return count

# print output
print("Output1 is " + str(end_other("Hiabc","abc")))
print("Output2 is " + str(count_code("cozexxcope")))