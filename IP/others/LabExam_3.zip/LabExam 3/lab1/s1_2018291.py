#Midterm Lab Exam Set 1- 2018
#Name : Kirti Gautam
#Roll Number : 2018291
#section : B
#Group : 4
#Date : 23-09-2018
def end_other(s1,s2):
	if s2 in s1 or s1 in s2:
		return True
	else:
		return False
def count_code(s3):
	s="co"
	if(s in s3):
		s3.count(s)	     
	else:
		return 0
  




	
