#NAME	-	M.ARUN KUMAR
#ROLLNO.-	2018376
#SECTION-	B
#GROUP	-	1

from str import *

#function1
def end_other(s1,s2):
   k=0
   s1=s1.lower()
   s2=s2.lower()
   l1=len(s1)
   l2=len(s2)
   if (l1>l2) :
       z=s1.find(s2)
         if z=-1:
	     return FALSE
	   else :
	     for i in range[l2] :
		      if(s1[l1-l2+i]==s2[i])
			    k=1
		      if k!=1 :
                return FALSE
	     if z=1 :
	      return TRUE
    else:
       z=s2.find(s1)
       if z=-1:
	      return FALSE
	   else :
	      for i in range[l1] :
		      if(s2[l1-l2+i]==s1[i])
			    k=1
		      if k!=1 :
                 return FALSE
	   if z=1 :
	      return TRUE

		
#function2
def count_code(s3):
	x=len(s3)
	s=s3.count('c')
	y=s3.count('o')
	z=s3.count('e')
	if (s==y and y==z and z==s)
	  return s
	
    
	
	