def end_other(s1,s2):
	s1=str(s1)
	s2=str(s2)
	s1=s1.lower()
	s2=s2.lower()
	a=int(len(s1))
	b=int(len(s2))
	if a>b:
		if s1[-b:]==s2:
			
			return True
		else:
			
			return False
	else:
		if s2[-a:]==s1:
			
			return True
		else:
			
			return False

def count_code(s3):
	s3=str(s3)
	a=len(s3)
	count=0
	a=s3.find('c')
	if s3[a+1]=='o':
		if s3[a+3]=='e':
			count=count+1
			b=s3.find('c',a+1)
			if s3[b+1]=='o':
				if s3[b+3]=='e':
					count=count+1
					c=s3.find('c',b+1)
					if s3[c+1]=='o':
						if s3[c+3]=='e':
							count=count+1
							return count
					
					
					
				
	return count



print("Output1 is " + str(end_other("Hiabc","abc")))
print("Output2 is " + str(count_code("cozexxcope")))

