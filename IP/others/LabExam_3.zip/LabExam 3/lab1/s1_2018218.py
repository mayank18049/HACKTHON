def end_other(s1,s2):
	n=str(s1)
	m=str(s2)
	if (n.find(m)==0):
		return True
	elif (m.find(n)==0):
		return True
	else:
		return False


def count_code(s3):
	k=str(s3)
	m=k.index("co")
	n=k+2
	

	j=k.count("co")
	return j









k=end_other("abc","abcd")	
print(k)


p=count_code("codecodf")
print(p)