#Name: aman kumar
#Roll no: 2018216
#section : B
#group :1
#Date : 23/09/2018

#function1
def end_other(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	n1=en(s1)
	n2=n(s2)
	if end_other(s1,s2):
		s1=s1[:]or s2=s2[0:n]
		return true
	else:
		return false

#test cases
if __ "main"__="test cases
  def test end_other(s1,s2):
	end_other("Hiabc","abc")
	end_other("Abc","HiaBc")


#function2
def count_code(s3):
	s3="enter a string"
	if count_code(s3):
		s3=d.recursion
		return 2
	elif count_code(s3):
		return 1
	else:
		return 0


#test cases
if __"main"__"test cases"
 def test count_code(s3):
	count_code("aaacodebbb")
	count code("cpdexxcope")
	
	


