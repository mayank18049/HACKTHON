# Midterm Lab Exam Set 1- 2018
#Name: Naman jain	
#Roll Number: 2018347
#Section: B
#Group: 4
#Date: 23/09/2018

def end_other(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	if (len(s1)==len(s2) and s1==s2):
		return True
	elif (len(s2)>len(s1) and s2[-len(s1):]==s1):
		return True
	elif (len(s1)>len(s2) and s1[-len(s2):]==s2):
		return True
	else:
		return False
def count_code(s3):
	c=0
	h='abcdefghijklmnopqrstuvwxyz0123456789/*-+.~!@#$%^&*()_=`[]{\}|;,<>/?'
	for k in h:
		x='co'+k+'e'
		c=c+s3.count(x)
	return c
print("Output is " + str(end_other("Hiabc","abc")))
print("Output is " + str(count_code("cozexxcope")))