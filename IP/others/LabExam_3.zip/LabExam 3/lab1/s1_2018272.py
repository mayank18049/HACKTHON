#Name = Abhishek anil
#Sec = B
#Roll No. = 2018272

#To show the equality of the last string
#Q1 :::
def end_other(s1 ,s2):
	s1 = s1.lower()
	s2 = s2.lower()
	if s1[-1:] == s2[-1:]:
		return True
	else:
		return False
print("Output1 is " + str(end_other("ASDASD", "AFSDED")))


#Q2 :::
def count_code(s3):
	s3 = s3.lower()
	if(s3[0:3] == s3[-3:-1]):
		return 1
	else:
		return 0
print("Output2 is " + str(count_code("aaasdfsadfbbbb")))