# Midterm Lab Exam Set 1 - 2018
# Name : Adwit Singh Kochar
# Roll Number : 2018276
# Section : B
# Group : 5
# Date : 23 Sep, 2018

#function1
def end_other(s1,s2):
	"""Returns True if either of the strings appear at the very end of the other string, ignoring case differences, else returns False."""

	s1 = s1.lower()
	s2 = s2.lower()
	if (s1.endswith(s2) or s2.endswith(s1)):
		return True
	else:
		return False

#function2
def count_code(s3):
	"""Returns the number of times the string 'code' appears anywhere in the givern string, except any letter will be accepted in place of 'd'."""

	count = 0
	import string
	x = string.ascii_lowercase
	for c in x:
		count += s3.count("co%se" %c)
	return count

#print output
print("Output1 is " + str(end_other("Hiabc","abc")))
print("Output2 is " + str(count_code("cozexxcope")))