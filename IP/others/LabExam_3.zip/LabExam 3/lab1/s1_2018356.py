#Midterm Lab Exam Set-1 -2018
#ParthSingh	
#2018256
#Section:B
#Group:5
#23/09/18
#http\192.168.1.89

def end_other(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	n=len(s1)
	m=len(s2)
	if n>m :
		x=s1.find(s2)
		if (x==n-m):
			print("Output1 is " + "True")
		else:
			print("Output1 is " + "False")
	if m>n:
		x=s2.find(s1)
		if (x==m-n):
			print("Output1 is " + "True")
		else:
			print("Output1 is " + "False")

def count_code(s3):
	p='abcdefghijklmnopqrstuvwxyz'
	k=0
	for i in p :
		y=('co' + i + 'e')
		k=k+s3.count(y)
	print("Output2 is " + str(k))
end_other("Hiabc","abc")
count_code("cozexxcope")
