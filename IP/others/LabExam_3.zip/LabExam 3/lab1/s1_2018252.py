'''
Midterm lab exam set 1 - 2018
Name: Prabhat Soni
Roll no: 2018252
Section: B
Group: 5
Date: Sept 23, 2018
You need to implement both functions in this module
'''


#function1
def end_other(s1,s2):
 length1=len(s1)
 length2=len(s2)

 s1=s1.lower()
 s2=s2.lower()

 if s1[length1-length2:length1]==s2:      #s1 is longer string and s2 is shorter
  return True
 else:
  return False


#function2
def count_code(s3):
 s3=s3.lower()
 length=len(s3)
 count=0

 for i in range(length-3):
  if (s3[i]=="c" and s3[i+1]=="o" and s3[i+3]=="e"):
   count=count+1
 return str((count))


#print output
print("Output1 is " + str(end_other("HiaBcd","abcD"))
print("Output2 is " + str(count_code("cozexxcope"))
