#midterm_s1_2018408.py
#midterm lab exam set -1 - 2018
#name: rushil thareja
#roll number:2018408
#section:b
#group:1
#date:23 september 2018
#function1
def end_other(s1,s2):
	b=0
	s1=s1.lower()
	s2=s2.lower()
	new1=''
	new2=''
	l1=len(s1)
	l2=len(s2)
	if l1>=l2:
		d1=l1-l2
		new1=s1[d1:]
		if new1==s2:
			b=1

	elif l2>=l1:
		d2=l2-l1
		new2=s2[d2:]
		if new2==s1:
			b=1
	if b==1:
		return True
	else:
		return False
#function2
def count_code(s3):
	x=0
	y=0
	count=0
	while(x!=-1):
		if len(s3)<4:
			break

		x=s3.find("co")
		if (x+4)>len(s3):
			break
		y=s3[x+3]
		if x!=-1 and y=='e':
			count+=1
			s3=s3[:x]+s3[x+4:]
		if len(s3)<4:
			x=-1
	return count
#print output
print(end_other("abc","hiabch"))
print(count_code("cozexxcop"))