#Name = Ritik Garg
#Roll no= 2018305
#Section = B
# Group =2
def end_other(s1,s2):
	s1 = s1.lower()
	s2= s2.lower()
	u = len(s1)
	v = len(s2)
	if u>=v:
		if s1[u-v:] == s2[:]:
			return True
	elif v>=u:
		if s2[v-u:] == s1[:]:
			return True
	else:
		return False

def count_code(s3):
	z= 0
	for c in s3:
		if c == "c":
			u = s3.index(c)
			v = s3[u+1]
			t =s3[u+3]
			if v == "o" and t == "e":
				z = z+1
				for c in s3[u:]:
					if c == "c":
						u = s3.index(c)
						v = s3[u+1]
						t =s3[u+3]
					if v == "o" and t == "e":
						z = z+1
						return z
					else:
						return z

			else:


				return z





print("Output1 is " + str(end_other("Hiabc","abc")))
print("Output2 is " + str(count_code("cozexxcape")))
