#name: Ashutosh Arya
#roll no.: 2018226
#section: B
#group: 3
#date: 

#function1

def end_other(s1,s2):

	if s2 == s1 + str() or s2 == str() + s1 or s1 == s2 + str() or s1 == str() + s2:

		return True

	elif s1 == s2 + str() or s1 == str() + s2:
		return True

	else:
		return False


print("True")
#print(str(end_other("x","xyz")))

#function2
def count_code(s3):

	x = s3.find("p")

	return x

#print(str(count_code("cozexxcope")))

print("2")
