#Midterm Lab Exam Set 1 - 2018
#Name: Manak Bisht
#Roll Number: 2018340
#Section: B
#Group: 5
#Date: 23/09/18

#function1
def end_other(s1,s2):
	'''Returns True if either of the strings appear at the very end of the other string, ignoring upper/lower case differences'''
	s1 = s1.lower()
	s2 = s2.lower()
	
	if len(s1)>=len(s2) and s2 == s1[len(s1)-len(s2):]:
		return True
	elif len(s2)>len(s1) and s1 == s2[len(s2)-len(s1):]:
		return True
	else:
		return False

#function2
def count_code(s3):
	'''Returns the number of times the string "code" appears anywhere in the given string, except any letter will be accepted in place of "d"'''
	s3 = s3.lower()
	from string import ascii_lowercase
	a = ascii_lowercase
	c = 0
	
	for i in range(len(a)):
		b = 'co'+a[i]+'e'
		c = c + s3.count(b)
	return c

#print output
print("Output1 is "+str(end_other("Hiabc","abc")))
print("Output2 is "+str(count_code("cozexxcope")))
	

		

	
