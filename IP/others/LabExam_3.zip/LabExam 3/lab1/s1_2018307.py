#NAME : SARTHAK ARORA
#ROLL NUMBER: 2018307
#SECTION: B
#GROUP: 4
#DATE: 23-9-18


def end_other(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	a=len(s1)
	b=len(s2)
	if (s1[a-b:a]==s2):
		return True
	elif(s2[b-a:b]==s1):
		return True
	else:
		return False


def count_code(s3):
	ct=0
	for a in 'abcdefghijklmnopqrstuvwxyz':
		d="co"+a+"e"
		ct=ct+s3.count(d)
	return ct

