#name - Md. talib
#roll no. - 2018245
#section- B
#group- 06
#date- 23 sep 2018

def end_other(s1,s2):
	s1=input("enter a string 1 :,   ")
	s2=input("enter a string 2 :,   ")

	if find end.s2() 
		return true
	else 
		return false


	
print("output1 is" + str(end_other("s1","s2")))







	
