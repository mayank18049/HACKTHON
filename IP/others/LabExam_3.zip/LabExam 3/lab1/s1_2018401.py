# Midterm Lab Exam Set 1 - 2018
# Name : Parth Garg
# Roll Number : 2018401
# Section : B
# Group : 2
# Date : 23/09/2018

import string

#function 1

def end_other(s1,s2):
	x=''
	y=''
	for i in range (0,len(s1)):
		if(s1[i].isalpha()):
			x=x+s1[i].lower()
		else:
			x=x+s1[i]

	for i in range (0,len(s2)):
		if(s2[i].isalpha()):
			y=y+s2[i].lower()
		else:
			y=y+s2[i]

	# all the characters are now lowercase....can do case nsensitive checking now

	def check(c1,c2):
		
		flag=True

		if(len(c1)>len(c2)):
			return False
		else:
			pos = len(c2)-len(c1)
			for i in range (0, len(c1)):
				if(c1[i] != c2[pos]):
					flag=False
				pos+=1
		if(flag):
			return True
		else:
			return False

	if( (check(x,y))  or  check(y,x) ):
		return True
	else:
		return False


# Function 2

def count_code(s3):
		count=0
		x=s3

		for i in range(0,len(x)-3):
			if(x[i]=='c' and x[i+1]=='o' and x[i+3]=='e'):
				count+=1

		return count




















