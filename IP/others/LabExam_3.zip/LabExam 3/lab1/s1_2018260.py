# Midterm Lab Exam Set 1- 2018
#Name: sahil
#Roll Number: 2018260
#section: B
#group: 5
#date: 21/09/18
#function 1
def end_other(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	if s1 in s2:
		u=s2.index(s1)
		if s1==s2[u:]:
			return True
	elif s2 in s1:
		v=s1.index(s2)
		if s2==s1[v:]:
			return True
	else:
		return False
#function 2
def count_code(s3):
	t='abcdefghijklmnopqrstwxyz'
	m=0
	for i in t:
		q=("co" + i + "e")
		
		return q
	return 0
#print output
print("output1 is" + str(end_other("Hiabc","abc")))
print("output2 is" + str(count_code("cozexxcope")))


	

