#midterm Lab Exam Set 1 - 2018
#rachit jaiswal
#2018404
#section B
#group 5
#23/09/2018
def end_other(s1,s2):
        y=len(s1)
        x=len(s2)
        s1=s1.lower()
        s2=s2.lower()
        if y>x:
          if s1[y-x:]==s2:
           
            return True
          else:
           
            return False
        elif y<x:
          if s2[x-y:]==s1:
            
             return True
             
          else:
            
            return False
        else:
          if s1==s2:
          
            return True
          else:
            return False


def count_code(s3):
       count=0
       for i in range(len(s3)):
           
           if s3[i]=="c" and s3[i+1]=="o" and s3[i+3]=="e":
                   count=count+1
  
       return count
                    
print("Output1 is "+ str(end_other("Hiabc","abc")))
print("Output2 is "+ str(count_code("cozexxcope")))

