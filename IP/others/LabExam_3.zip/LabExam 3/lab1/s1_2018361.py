#Name: Purvashi Saxena
#Roll No.:2018361
#Section B
#Group2

def end_other(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	if s1[-len(s2):]==s2 or s1[-len(s2):]==s2:
		return True
	else:
		return False	

def count_code(s3):
	count=0
	for i in s3[:len(s3)]:
		i=ord(i)
		if i==ord("c") and i+1==ord("o") and i+3==ord("e"):
			count+=1
	print(count)		


