
#Name: Himanshu
#Roll Number: 2018235
#Section : B
#Group : 4





def end_other(s1,s2):
	s1=s1.upper()
	s2=s2.upper()
	a=s1.rfind(s2)
	b=s2.rfind(s1)
	if a>=0:
		if s1[a:len(s1)]==s2:
			return True
		else:
			return False
	elif b>=0:
		if s2[b:len(s2)]==s1:
			return True
		else:
			return False
	else:
		return False




def count_code(s3):
	s=s3
	x=s.count('coae')+s.count('cobe')+s.count('coce')+s.count('code')+s.count('coee')+s.count('cofe')+s.count('coge')+s.count('cohe')+s.count('coie')+s.count('coje')+s.count('coke')+s.count('cole')+s.count('come')+s.count('cone')+s.count('cooe')+s.count('cope')+s.count('coqe')+s.count('coqe')+s.count('core')+s.count('cose')+s.count('cote')+s.count('coue')+s.count('cove')+s.count('cowe')+s.count('coxe')+s.count('coye')+s.count('coze')
	return x

print('output1 is ' + str(end_other('Hiabc','abc')))
print('output2 is ' + str(count_code('cozexxcope')))
