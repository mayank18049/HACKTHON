#Midterm Lab Exam Set 1- 2018
#Name	: Srijan Jain
#Roll no: 2018319
#Section: B
#Group	: 8
#Date	: 23/09/18


#function1
def end_other(s1,s2):
	s1=s1.upper()
	s2=s2.upper()
	l1=len(s1)
	l2=len(s2)
	if(s1[-l2:]==s2 or s2[-l1:]==s1):
		return True
	else:
		return False

#function2
def count_code(s3):
	#s3=s3.lower()
	l=len(s3)-3
	x=0
	for i in range(l):
		if(s3[i]=='c' and s3[i+1]=='o' and ord(s3[i+2])>=97 and ord(s3[i+2])<=122 and s3[i+3]=='e'):
			x+=1
	return x


#print output
print("Output1 is " + str(end_other("HiabcgsfhgogfABC", "abc")))
print("Output2 is " + str(count_code("cozexxcopecoDeco2decode")))