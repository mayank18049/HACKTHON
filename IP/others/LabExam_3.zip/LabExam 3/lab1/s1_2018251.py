#mid sem
#nitin gupta
#rno- 2018251
#sec- B
#grp-4


def end_other(s1,s2):
	
	l1=len(s1)
	l2=len(s2)
	s1=s1.upper()
	s2=s2.upper()

	if l1>l2:
		if s1[l1-l2:]==s2:
			return True
		else:
			return False
	else:
		if s2[l2-l1:]==s1:
			return True
		else:
			return False

def count_code(s3):
	s3=s
	
	f=0
	c=0
	a=0
	x=0
	while f==0:
		if s.find("co",x)==-1:
			f=1
		else:
			x=s.find("co",x)
			if s[x+3]=='e':
				c=c+1
		x=x+4




	return c


	

