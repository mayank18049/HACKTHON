#Midterm Lab Exam Set 1 - 2018
#Rishi Raj Jain
#2018304
#Section B
#Group 1
#23/09/2018

#Function1
def end_other(s1,s2):
	s1=str(s1.lower())
	s2=str(s2.lower())
	l1=len(s1)
	l2=len(s2)
	s=s1[-1:(-1-l2):-1]
	t=s2[-1:(-1-l1):-1]
	s=s[::-1]
	t=t[::-1]
	
	if(s==s2 or t==s1):
		return print(True)
	else:
		return print(False)

#Function2
def count_code(s3):
	s3=str(s3)
	l1=0
	test=0
	count=0
	if(s3[0:2]=='co' and s3[3]=='e'):
		count=1
	else:
		count=0
	while(test==0):
		l1=s3.find('co',l1+1)
		l2=l1+3
		if(l1>=0 and l2>=0):
			if(s3[l2]=='e'):
				count+=1
				test=0
			else:
				test=1
		else:
			test=1
	return count