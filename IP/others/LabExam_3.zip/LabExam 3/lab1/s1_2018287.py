#Midterm Lab Exam Set 1 - 2018
#Name: Jasmine Kaur
#Roll number: 2018287
#Section: B
#Group: 8
#Date: 23 September 2018
from string import ascii_lowercase
def end_other(s1,s2):
	s1 = s1.lower() #converting to lowercase
	s2 = s2.lower()
	if s1.startswith(s2) or s1.endswith(s2) or s2.startswith(s1) or s2.endswith(s1):
		return True
	else:
		return False

def count_code(s3):
	count = 0
	for a in ascii_lowercase: #contains all the lowercase characters 
		code = s3.find('co' + a + 'e')
		if code != -1:
			count += 1
	return count

print("Output1 is " + str(end_other("Hiabc",'abc')))
print("Output2 is " + str(count_code("cozexxcope")))
