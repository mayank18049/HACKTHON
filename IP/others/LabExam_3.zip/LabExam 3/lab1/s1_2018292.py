'''
Midterm Lab Exam Set -1
Name: Kshitij Agrawal
Roll Number: 2018292
Section: B
Grooup: 05
Date: 23-09-2018
'''

#Funtion 1
def end_other(s1,s2):
	s1 = s1.lower()
	s2 = s2.lower()
	len_s1=len(s1)
	len_s2=len(s2)

	if(len_s1>=len_s2):
		if (s1[(len_s1-len_s2):]==s2):
			return (True)
		else:
			return (False)
	elif(len_s2>len_s1):
		if (s2[len_s2-len_s1:]==s1):
			return (True)
		else:
			return (False)

#Function 2
def count_code(s3):
	s3 = s3.lower()
	len_s3 = len(s3)
	count = 0
	for i in range (len_s3):
		if(s3[i:i+2]=='co'):
			if(s3[i+3]=='e'):
				count+=1
	return (count)

#Print Output
s1,s2 = input("Enter two strings (separated by a space): ").split()
print("Output 1 is: " + str(end_other(s1,s2)))

s3 = input("Enter a string to count the no. of 'code': ")
print("Output 2 is: " + str(count_code(s3)))