#Midterm Lab Exam Set 1 - 2018
#Name:Tanmay Garg
#Section:B
#Group:1
#Date: 23rd September , 2018
#you need to implement both the functions given in this module.



#function1
def end_other(s1,s2):
	s1_ = s1.lower()
	s2_ = s2.lower()
	x1 = len(s1_)
	x2 = len(s2_)
	if x1 > x2:
		w_ = s1.find(s2)
		if w_ == -1:
			k = 'False'
			return k
		else:
			k = 'True'
			return k
	elif x1 < x2:
		w_ = s2.find(s1)
		if w_ == -1:
			k = 'False'
			return k
		else:
			k = 'True'
			return k

	elif x1 == x2:
		w_ = s1.find(s2)
		if w_ == -1:
			k = 'False'
			return k
		else:
			k = 'True'
			return k





#function2
def count_code(s3):
	string = s3.lower()
	kkk = len(string)
	x = 0
	while kkk > 0:
		q = int(string.find('co'))
		
		a = int(string.find('e'))
		if a - q == 3:
			x = x + 1
			string = string[a+1:]
			kkk = len(string)
		elif a - q > 1:
			string = string[a+1:]
			kkk = len(string)
		elif a - q < 1:
			string = string[q:]
			kkk = len(string)
		else:
			kkk = 0
	return x				



