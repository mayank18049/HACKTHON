#midterm Lab exam Set 1 - 2018
#Name : kunal anand
#Roll Number : 2018293
#Section : B
#Group : 06
#Date : 23 september 2018

#function 1
def end_other(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	found=0
	if s1>s2:
		n=len(s2)
		y=""
		for i in range(0,len(s1)-n+1,1):
			for j in range(i,i+n,1):
				y=y+s1[j]
			if y==s2:
				found = 1
		if found == 1:
			return True
		else:
			return False
	if s1<s2:
		n=len(s1)
		y=""
		for i in range(0,len(s2)-n+1,1):
			for j in range(i,i+n,1):
				y=y+s2[j]
			if y==s1:
				found = 1
		if found == 1:
			return True
		else:
			return False

#function 2
def count_code(s3):
	s3=s3.lower()
	n=0
	for i in range(0,len(s3)-3,1):
		if s3[i]=="c" and s3[i+1]=="o" and s3[i+3]=="e":
			n=n+1

	return n
	

