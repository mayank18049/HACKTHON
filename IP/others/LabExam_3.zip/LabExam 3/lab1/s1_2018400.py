#Name=Nitesh Jaiswal
#Roll no-2018400
#Section=B
#Group=1
def end_other(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	n=len(s1)
	m=len(s2)
	if(s1==s2[m-n:] or s2==s1[n-m:]):
		return True
	else:
		return False
def count_code(s3):
	l=len(s3)
	d=1 or 2 or 3 or 4 or 5 or 6 or 7 or 8 or 9 
	al="a" or "b" or "c" or "d" or "e" or "f" or "g" or "h" or "i" or "j" or "k" or "l" or "m" or "n" or "o" or "p"
	c=s3.count("co"+"d" or "al"+"e")
	return c