def end_other(s1,s2):
    if len(s1)>=len(s2):
       if s1[len(s1)-len(s2):].lower()==s2.lower():
          return True
       else:
            return False
    elif len(s2)>len(s1):
         if s2[len(s2)-len(s1):].lower()==s1.lower():
            return True
         else:
              return False
def count_code(s3):
    count=0
    for i in range(len(s3)-3):
        if s3[i:i+2].lower()+s3[i+3].lower()=="coe" and s3[i+2].isalpha():
           count=count+1
    return count
if __name__=="__main__":
   print("Output is "+str(end_other("Hiabc","abc")))
   print("Output is "+str(count_code("cozexxcope")))

