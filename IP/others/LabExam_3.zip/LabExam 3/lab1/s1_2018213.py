#Midterm Lab Exam Set 1 -2018
#Name:Adarsh Kumar
#Roll Number:2018213
#Group:6
#Date:23/09/2018
#function1
def end_other(s1,s2):
	s1=str(s1)
	s2=str(s2)
	len1=len(s1)
	len2=len(s2)
	s11=s1.lower()
	s22=s2.lower()
	s1new=s11[-len2:]
	s2new=s22[-len1:]
	if s1new.find(s22)>=0:
		z=True
	elif s2new.find(s11)>=0:
		z=True
	else:
		z=False
	return z
#function2
def count_code(s3):
	s33=str(s3)
	n=0
	while s33.find('co')>=0:
		help1=s33.find('co')
		s33new=s33[help1:]
		if s33new[3]=='e':
			s33new1=s33new[2]
			if s33new1.isalpha()==True:
				if ord(s33new[2])>=97 or ord(s33new[2]<=122):
					n=n+1	
		s33=s33new[3:]
	return n 
#print output
print('Output1 is '+str(end_other('cFDv','Hiabcfdv')))
print('Output2 is '+str(count_code('codesdhgcodesdhcode')))