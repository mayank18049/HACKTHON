#Midterm Lab Exam Set1-2018
#Name: Snigdha Gupta
#Roll Number:2018316
#Section:B
#Group:5
#Date-23-09-2018
#function1

def end_other(s1,s2):
	if len(s1)>len(s2):
		f=s1
		s=s2
	else:
		f=s2
		s=s1
	n=len(s)
	x=f[-n:-1]+f[-1]
	count=0
	for i in range(n):
		if s[i]==x[i].lower() or s[i]==x[i].upper():
			count=count+1

	if count==n:
		return True 
	else:
		return False

#function2
def count_code(s3):
	n=len(s3)
	count=0
	for x in range(n):
		if "c"==s3[x]:
			if "o"==s3[x+1]:
				if s3[x+2].isalpha():
					if s3[x+3]=="e":
						count=count+1
						x=x+3
	
	
	return count

#print
print("Output is "+str(end_other("abc","HiYbc")))
print("Output is "+str(count_code("cozexxcope")))
