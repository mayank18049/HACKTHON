#Midterm Lab Exam Set 1 -  2018
#Name:Aman Kumar Gupta
#Roll Number:2018217
#Section:B
#Group:2
#Date:23-09-2018


#function1
def end_other(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	l1=len(s1)
	l2=len(s2)
	if l1>=l2:
		if s1.find(s2)==(l1-l2):
			return('True')
		else:
			return('False')
	if l2>=l1:
		if s2.find(s1)==(l2-l1):
			return('True')
		else:
			return('False')
def count_code(s3):
	l3=len(s3)
	count=0
	for i in range(0,l3-3):
		if s3[i]=='c' and s3[i+1]=='o' and s3[i+3]=='e':
			count+=1
	return(count)
print("Output1 is " + str(end_other("Hiabc","abc")))
print("Output2 is " + str(count_code("cozexxcope")))