#Midtrm Lab Exam Set 1 - 2018
#Name : SUDHIR ATTRI
#Roll Number : 2018267
#Section : B
#Group : 4
#Date : 23-09-2018

def end_other(s1,s2):
	l1=len(s1)
	l2=len(s2)
	if(l1>l2):
		if((s1[-l2:]).lower()==s2.lower()):
			return True
		else:
			return False
	elif(l1<l2):
		if((s2[-l1:]).lower()==s1.lower()):
			return True
		else:
			return False
	elif(l1==0 or l2==0):
		return False
	else:
		if(s1.lower()==s2.lower()):
			return True
		else:
			return False

def count_code(s3):
	count=0
	for i in range(len(s3)-3):
		if(s3[i]=='c' and s3[i+1]=='o' and s3[i+3]=='e'):
			if(s3[i+2]!=' '):
				count+=1
	return count
	
a=input()
b=input()
print(str(end_other(a,b)))
c=input()
print(str(count_code(c)))