#Name:- Rishabh Kumar Solani
#Roll No.:- 2018257
#Section:- B
#Group:- 2

#function1
#for 
def end_other(s1,s2):

 s1=input(str)
 s2=input(str)
 n=len(s1)
 m=len(s2)
 if (n>m) and s2[0:]==s1[n-m:]:
  print(True)
 elif (m>n) and s1[0:]==s2[m-n:]:
  print(True)
 else:
  print(False)




#function2
def count_code(s3):

 s3=input(str)
 if s3==(str+'code'):
  print(1)
 elif s3==('co'+str+'e'+str+'code'):
  print(2)
 