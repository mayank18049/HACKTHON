#Midtern Lab Exam Set 1 - 2018
#Name - Bhavay Aggarwal
#Roll Number - 2018384
#Section - B
#Group - 1

#function1
def end_other(s1,s2):
	n1= len(s1)
	n2 = len(s2)
	S1= s1.casefold()
	S2= s2.casefold()
	if(S1[n1-n2:]==S2 or S2[n2-n1:]==S1):
		return True
	else: 
		return False	 


#fucntion2
def count_code(s3):
	i=0
	count=0
	while(i+3<len(s3)):
		if(s3[i]=='c' and s3[i+1]=='o' and s3[i+3]=='e'):
			count+=1
			i += 4
		else:
			i+=1
	return count
				
#print output
print("Output1 is " + str(end_other("Hiabc","abc")))
print("Output1 is " + str(end_other("abc","abe")))
print("Output2 is " + str(count_code("cozexxcope")))