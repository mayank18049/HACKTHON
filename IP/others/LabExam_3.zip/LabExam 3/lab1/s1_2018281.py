# Midterm Lab Exam Set 1 - 2018
# Name: Dhruv Yadav
# Roll Number: 2018281
# Section: B
# Group: 2

def end_other(s1, s2):
	if len(s1) < len(s2):
		index = len(s1) * -1
		return s2[index:]==s1
	else:
		index = len(s2) * -1
		return s1[index:]==s2

def count_code(s3):
	length = len(s3)
	counter = 0
	for i in range(0, length-3):
		if s3[i] == 'c' and s3[i + 1] == 'o' and s3[i + 3] == 'e':
			counter += 1
	return counter

print("Output1 is " + str(end_other("Hiabc", "abc")))
print("Output2 is " + str(count_code("cozexxcope")))