#Midterm lab exam set 1-2018
#Name: AANYA JAIN
#Roll number: 2018208
#Section : B
#Group : 1
#Date: 23/9/18
#func1
def end_other(s1,s2):
	a=len(s1)    	       #finds the length of the strings 
	b=len(s2)           
	if a>b:  	           #compares the lengths 
		x=s2
		d=x.lower()			#converts to lower case
	else:
		x=s1
		d=x.lower()
	if x==s2:
		e=s1[a-b:]
		f=e.lower()
		if f==d:
			z='True'
		else:
			z='False'
	else:
		e=s2[b-a:]
		f=e.lower()
		if f==d:
			z='True'
		else:
			z='False'
	return z



#func2
def count_code(s):
	count=0
	d=0
	a=len(s)
	for b in range(a):
		c=s.find('co',d)			#finds if the string 'co' is there
		if c!=-1:
			d=c+1
		if s[c+3]=='e':
			count=count+1
	return count



print('Output is ' + str(end_other('hiabc','abc')))
print('Output2 is ' + str(count_code('abcodef')))