#Name - Prashant
#Roll No.- 2018360
#Section - B
#Group - 1

def end_other(s1,s2):
	l1=len(s1)
	l2=len(s2)
	if(l1>l2):
		st1=s1[-1:l1-l2:-1]
		st2=s2[-1::-1]
		if(st1==st2):
			return(True)
		else:
			return(False)
	elif(l2>l1):
		st1=s1[-1::-1]
		st2=s2[-1:l2-l1:-1]
		if(st1==st2):
			return(True)
		else:
			return(False)
	else:
		if(s1==s2):
			return(True)
		else:
			return(False)

def count_code(s3):
	s=s3
	p=s.find('co')
	if(s.find('code')):
		return(1)
	elif(p>=0):
		if(s[p+3].find('e')):
			return(2)
		else:
			return(0)
	else:
		return(0)

print("Output1 is " +str(end_other("Hiabc","abc")))
print("Output2 is " +str(count_code("cozexxcope")))