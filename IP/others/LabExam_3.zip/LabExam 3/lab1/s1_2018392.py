#Hemant Dhankar
#2018392
#sec B
#Group 1
#23/09/2018
#L317-PC48
def end_other(s1,s2):
	s1=s1.upper()
	s2=s2.upper()
	a=len(s1)
	b=len(s2)
	c=0
	t=0
	if(a<b):
		for i in range(a,1,-1):
			if(s2[-(i)]!=s1[c]):
				t=1
			c=c+1
	elif (a>b):
		for i in range(b,1,-1):
			if(s1[-(i)]!=s2[c]):
				t=1
			c=c+1
	else:
		for i in range(0,a-1):
			if(s1[i]!=s2[i]):
				t=1
	if(t==0):
		return True
	elif (t==1):
		return False

def count_code(s3):
	l=int(len(s3))
	s="code"
	count=0
	i=0
	f=0
	for f in range(0,l-4):
			if(i<l-4):
				n=s3[f,f+4]
				x=s3[f,f+2]
				if((n==s) or (x=="co" and s3[i+3]=="e")):
					count=count+1
			f=f+1
	return count


print("Output1 is "+str(end_other("Hiabc","abc")))
print("Output2 is "+str(count_code("cozexxcope")))