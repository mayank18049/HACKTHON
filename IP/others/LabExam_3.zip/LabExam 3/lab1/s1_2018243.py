def end_other(s1,s2):
	x = s1.lower()
	y = s2.lower()
	a = len(x)
	b = len(y)
	if a<b:
		c = y[-a:]
		if c == x:
			return("output1 is + True")
		else:
			return("output1 is + False")
	else:
		c = x[-b:]
		if c == y:
			return("output1 is + True")
		else:
			return("output1 is + False")
def count_code(s3):
	z = len(s3)
	count = 0
	for i in range (0,z-3):
		if s3[i] == 'c':
			if s3[i+1] == 'o':
				if s3[i+3] == 'e':
					count+=1
				
	return("Output2 is count")
