def count_code(s3):
	count1=0
	a=input()
	s="co"+i+"e"
	t=a.find(s) 
	if t != -1:
		if i=i.isalpha()
			for s in a :		
				if t!= -1:
					count1 += 1					    
					x=a[t+1:]
					t=x.find(s)
			

	else:
		count1=0	
	return(count1)
