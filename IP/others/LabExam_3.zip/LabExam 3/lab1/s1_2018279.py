#Midterm Lab Exam Set 1 - 2018
#Name: Arunesh Singh
#Roll Number: 2018279
#Section: B
#Group: 8
#Date: 23/09/2018

def end_other(s1,s2):
	s1 = s1.lower()
	s2 = s2.lower()
	s1len = len(s1)
	#print(s1len)
	s2len = len(s2)
	#print(s2len)
	if s1 in s2:
		#print("if")
		x = s2.find(s1)
		#print(x)
		if s2len-x == s1len:
			return True
		else:
			return False
	elif s2 in s1:
		#print("elif")
		x = s1.find(s2)
		#print(x)
		if s1len-x == s2len:
			return True
		else:
			return False
	else:
		return False

def count_code(s3):
	flag = 0
	for i in range(0, len(s3)-3 ):
		if s3[i]=='c' and s3[i+1]=='o' and s3[i+3]=='e' :
			flag+=1
		else:
			continue
	return flag

#x1 = input("s1: ")
#x2 = input("s2: ")
#x3 = input("s3: ")
#end_other(x1,x2)
#count_code(x3)

print("Output1 is " + str(end_other("Hiabc","abc")))
print("Output2 is " + str(count_code("cozexxcope")))


