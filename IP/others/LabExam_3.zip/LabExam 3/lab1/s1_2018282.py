#Midterm Lab Exam Set-1 2018
#Name: Dibya Gautam
#Roll number: 2018282
#Section: B
#Group: 3
#Date: 09/23/2018

#function1
def end_other(s1,s2):
	if len(s1)>=len(s2):
		longStr=s1
		shortStr=s2
	else:
		longStr=s2
		shortStr=s1

	shortLen=len(shortStr)
	longSt=longStr[(len(longStr)-shortLen):]
	if longSt.lower()==shortStr.lower():
		return True
	else:
		return False

"""
print(end_other("abc","ABC"))
print(end_other("AbC","HiaBc"))
print(end_other("abc","abXabc"))
print(end_other("abc","defx"))

"""


#function2
def count_code(s3):
	temp=s3
	count=0
	for i in range(len(s3)):

		codeIndex=temp.find("co")
		if (codeIndex+3) <len(temp):
			if temp[codeIndex+3]=="e":
				count=count+1
				temp=temp[codeIndex+4:]

		else:
			break

	return count


print(count_code("co"))
"""		
print(count_code("aaacodebbb"))
print(count_code("aabbcccodecodecod"))
print(count_code("cozexxcope"))
print(count_code("cpdexxxcode"))
"""

#print output
print("Output1 is "+ str(end_other("Hiabc","abc")))
print("Output2 is "+ str(count_code("cozexxcope")))

