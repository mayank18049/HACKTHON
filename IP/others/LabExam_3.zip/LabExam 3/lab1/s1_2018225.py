# Midterm Lab Exam Set 1 - 2018
# Name: Arundhati Bhattacharya
# Roll number: 2018225
# Section: B
# Group: 2
# Date: 23rd September 2018

from string import *

# function 1
def end_other(s1,s2):
	s1 = s1.lower()
	s2 = s2.lower()
	if len(s1) > len(s2):
		b = s1
		s = s2
	else:
		b = s2
		s = s1
	x = b.find(s)
	if x == -1:
		return False
	if b[x:] != s:
		return False
	return True


# function 2
def count_code(s3):
	cnt = 0
	for c in ascii_letters:
		s = 'co' + c + 'e'
		cnt = cnt + s3.count(s)
	return cnt

if __name__ == "__main__":
	print("Output1 is " + str(end_other("Hiabc","abc")))
	print("Output2 is " + str(count_code("cozexxcope")))
