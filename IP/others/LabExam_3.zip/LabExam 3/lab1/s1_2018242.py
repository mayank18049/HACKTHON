# Midterm Lab Exam Set 1 - 2018
# Name : Lakshya A Agrawal
# Roll Number : 2018242
# Section : B
# Group : 3
# Date : 23 September 2018
# You need to implement both functions given in this module.

#function1
"""
Returns True if either of the strings appear at the very end of the other string, ignoring upper/lower case differences, i.e., computation is case-insensitive;
else return false
"""
def end_other(s1, s2):
	str1=s1.lower()
	str2=s2.lower()
	if str1.endswith(str2):
		return(True)
	elif str2.endswith(str1):
		return(True)
	return(False)
	
#function2
"""
Returns the number of times the string code appeqars anywhere in the given string, except any letter will be accepted in place of d, i.e., 'cole' and 'cone' will be counted as well;
if there is no occurence, return 0
"""
def count_code(s3):
	str3=s3
	ind=str3.find("co")
	count=0
	while ind!=(-1):
		str3=str3[ind:]
		if len(str3)<4:
			ind=-1
		elif str3[3]=='e':
			count=count+1
		str3=str3[1:]
		ind=str3.find("co")
	return(count)
