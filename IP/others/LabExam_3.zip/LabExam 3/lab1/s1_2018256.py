#Midterm LAb Exam Set 1- 2018
#name: Rishabh Chauhan
#roll no.:2018256
#Section: B
#Group: 1
#Date: 23 sep,2018

#fuction1
def end_other(s1,s2):
	l1= int(len(s1))
	l2= int(len(s2))
	if l1>l2:
		s1= s1.lower()
		s2= s2.lower()
		if s1[l1-l2:]==s2:
			print('True')
			return True
		else:
			print('False')
			return False
	else:
		s1= s1.lower()
		s2= s2.lower()
		if s2[l2-l1:]==s1:
			print('True')
			return True
		else:
			print('False')
			return False

#function2
def count_code(s3):
	s=0
	for a in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ/*!@#$%^&*()+':
		c= s3.count('co'+ a +'e')
		s= s+c
	print(s)
	return s
print("output1 is"+ str(end_other("Hiabc","abc")))
print("output2 is"+ str(count_code("cozexxcope")))