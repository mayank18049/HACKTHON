#Midterm Lab Exam Set 1- 2018
#name:chhavi munjal
#roll number: 2018387
#section:B
#group: 4
#date: 23rd september 2018

#function1
import string
def end_other(s1,s2):
	a=s1.lower()
	b=s2.lower()
	if (len(a)<=len(b) and s2[len(b)-len(a):]==s1) or (len(b)<=len(a) and s1[len(a)-len(b):]==s2):
		print(True)
	else :
		print(False)
	return()

#function2
def count_code(s3):
	n=0
	for i in range(len(s3)):
		a=s3.find('co')
		if s3[a+3]=='e' and s3[len(s3)-1:]!='co' :
			n=n+1
			s3=s3[a+4:]
	print(n)
	return()


print('output1 is'+str(end_other('Hiabc','abc')))
print('output2 is'+str(count_code('cozexxcope')))

