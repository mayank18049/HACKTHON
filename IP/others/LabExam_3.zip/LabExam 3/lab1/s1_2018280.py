# Midterm Lab Exam Set 1 - 2018
# Name: Bhunesh
# Roll Number: 2018280
# Section: B
# Group: 1
# Date: 23/09/2018



# function1
def end_other(s1,s2):

    l1=len(s1)
    l2=len(s2)
    end_s1=s1[l1-3:]
    end_s2=s2[l2-3:]

    end_first=end_s1.lower()
    end_second=end_s2.lower()

    if end_first==end_second:
        return True
    else:
        return False




# function2

def count_code(s3):
    string=s3
    count=0
    k=string.find('co')
    while k!=-1:
        if string[k+3]=='e':
            count+=1
        string=string[k+2:]
        k=string.find('co')
    
    if count!=0:
        return count
    else:
        return 0


# print output
print("Output1 is " + str(end_other("Hiabc","abc")))
print("Output2 is " + str(count_code('cozexxcope')))
