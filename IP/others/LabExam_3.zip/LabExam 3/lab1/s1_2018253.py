#MIDTERM LAB EXAM SET1-2018
#NAME: PRASHANT JAIN
#ROLL NO=2018253
#SECTION B
#GROUP: 6
#DATE:22/09/2018

#FUNCTION 1
def end_other(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	if len(s2)<=len(s1):
		x=s1.find(s2)
		if x==-1:
			return "False"
		else:
			return "True"
	elif len(s2)>=len(s1):
		x=s2.find(s1)
		if x==-1:
			return "False"
		else:
			return "True"

#FUNCTION 2
def count_code(s3):
	s3=s3.lower()
	count=0
	letter="abcdefghijklmnopqrstuvwxyz"
	for i in letter:
		word="co"+str(i)+"e"
		x=s3.find(word)
		if s3.count(word)>1:
			count=count+s3.count(word)-1
		if x!=-1:
			count=count+1
	return count
		

print("output is "+str(end_other("HIabc","abc")))
print("output is "+str(end_other("HIabc","abc")))
print("output is "+str(end_other("ABC","HIabc")))
print("output is "+str(end_other("abc","abXabc")))
print("output is "+str(end_other("ABC","defx")))
print("output is "+str(end_other("ABC","abc")))
print("output is "+str(end_other("ABCde","abc")))

print("output is "+str(count_code("cozexxcope")))
print("output is "+str(count_code("aaacodebbb")))
print("output is "+str(count_code("cpdexxcode")))
print("output is "+str(count_code("cozexxxcoeecozE")))
print("output is "+str(count_code("cvjyagefuh")))
print("output is "+str(count_code("cozexxxcoeecozEcozecoeecodecode coze")))






