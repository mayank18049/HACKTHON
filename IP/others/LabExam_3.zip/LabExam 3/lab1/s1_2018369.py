# Mid Term Lab Exam Set 1 - 2018
# Name: Uday Narayan Goel
# RollNo. :2018369
# Section B 
# Group 2
# Date: 23 September 2018

#function1

#s1=input()
#s2=input()
def end_other(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	n1=len(s1)
	n2=len(s2)
	#print (n1)
	#print (n2)
	#print (s2[-n1:])
	#print (s1[-n2:])
	if s2[-n1:]==s1 or s1[-n2:]==s2:
		value=True
	else:
		value=False	
	return value
#print(end_other(s1,s2))	

#function2
#s3=input()
def count_code(s3):
	m=len(s3)
	i=0
	flag=0
	while i+3<m:
		if s3[i:i+2]=='co' and s3[i+3]=='e':
			flag=flag+1
		i=i+1	
	return flag		
#print(count_code(s3))
print('Output1 is ' + str(end_other('Hiabc','abc')))
print('Output2 is '+str(count_code('coxexxcope')))

