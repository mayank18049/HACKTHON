#Midterm Lab Exam Set 1 - 2018
#Name : Khushali Verma
#Roll Number : 2018290
#Section : B
#Group : 3
#Date : 23/09/2018

#function 1
def end_other(s1,s2):
	n1 = len(s1)
	n2 = len(s2)
	one = s1[-n2:]
	two = s2[-n1:]

	if s1.upper()==two.upper() or s1.lower()==two.lower():
		return True
	elif s2.upper()==one.upper() or s2.lower()==one.lower():
		return True
	else:
		return False

#function 2
def count_code(s3):
	alpha = 'abcdefghijklmnopqrstuvwxyz`~!@#$%^&*()-_=+[]{};:\'\"\|?/><.,1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ'
	c = 0
	for i in alpha:
		new = 'co'+i+'e'
		c += s3.count(new)
	return c

print("Output is " + str(end_other("Hiabc","abc")))
print("Output is " + str(count_code("cozexxcope")))