#Name: Ruhma Mehek Khan
#Roll Number: 2018362
#Section: B
#Group: 3
#Date: 22/09/18

def end_other(s1, s2):
	
	n=len(s1)
	m=len(s2)
	s1=s1.lower
	s2=s2.lower

	if m=n:
		if s1==s2:
			return True
	if n>m:
		if s1[(n-m):(n-1)] == s2:
			return True
	if m>n:
		if s2[(m-n):(m-1)]== s1:
			return True
	
	else:
		return False


def count_code(s3):
	
	count=0
	i=0
	n=len(s3)
	for i in range(0, n):
		if s3[i]=="c" and s3[i+1]=="o" and s3[i+3]=="e":
			count=count+1
		
		i=i+1
	return count

print("Output1 is "+str(end_other("Hiabc", "abc")))
print("Output2 is "+str(count_code("cozexxcope")))

