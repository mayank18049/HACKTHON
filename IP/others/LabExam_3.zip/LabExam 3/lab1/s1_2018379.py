#name: Amritpal singh
#roll number: 2018379
#section: B
#group: 4
#Date:23/09/2018

#function1
def end_other(s1,s2):
	s1="hiabc"
	s2="abc"
	if s1==s1-s2:
		print(True)
	else:
		print(False)
print("output1"+str(end_other("hiabc","abcs")))
#function2
def count_code(s3):
	s3="aaacodebbb"
	while s3<9:
		if d==s3:
			print("aaaconebbb")
			if s3=="aaaconebbb":
				print(1) 
			else:
				print(0)
	
print(1+str(count_code("aaacodebbb")))
















