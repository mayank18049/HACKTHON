#midterm SET1
#MRIGANK CHUGH
#2018345
#SECTION B GROUP2 
#DATE: 23 SEPTEMBER
def end_other (S1,S2):
	s1=S1.lower()
	s2=S2.lower()
	if len(s1)>len(s2):
		x=s1
		y=s2
	else:
		x=s2
		y=s1
	a=len(y)
	b=x[-a:]
	if b==y:
		return True
	else:
		return False
#S1=str(input())
#S2=str(input())
#print( end_other (S1,S2))
def count_code (S3):
	lst=S3.split("e")
	l=[]
	z=[]
	for i in lst:
		if i[-3:-1]=='co':
			l=l+[i]
	
	for j in l:
		if ord(j[-1])<65 or ord(j[-1])>90 :
			z=z+[j]
	return len(z)
#S3=str(input())
#print(count_code(S3))
