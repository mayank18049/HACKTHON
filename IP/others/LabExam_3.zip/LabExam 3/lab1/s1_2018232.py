"""
	midterm lab exam set 1 - 2018
	name:DIPTANSHU MITTAL
	ROLL NO. : 2018232
	SECTION : B
	GROUP : 1
	DATE : 23/09/2018
"""
def end_other(s1,s2):
	x=len(s1)
	y=len(s2)
	r=0
	s2=s2.lower()
	s1=s1.lower()
	if x>y:
		r=s1.find(s2,x-y)
	else:
		r=s2.find(s1,y-x)
	if r==-1:
		return False
	else:
		return True



def count_code(s3):
	count=0
	x=0
	y=0
	c=len(s3)
	while x<c:
		x=s3.find("co",y)
		y=x+3
		if x==-1:
			return count
		if s3[x+3]=='e':
			count=count+1
	return count