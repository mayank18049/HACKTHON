# Ojasva Saxena
# 2018352
# Group B - 1

def end_other (s1, s2) :
	s1 = s1.lower()
	s2 = s2.lower()
	l1 = len(s1)
	l2 = len(s2)
	if l1 > l2 :
		subS = s1[(-l2) : ]
		if subS == s2 :
			return (True)
		else :
			return (False)
	else :
		subS = s2[(-l1) : ]		
		if subS == s1 :
			return (True)
		else :
			return (False)	

def count_code (s3)	:
	c = 0
	l3 = len(s3)
	for i in range(l3) :
		if (s3[i] == 'c') and (s3[i+1] == 'o') and (s3[i+3] == 'e') :
			c += 1
	return (c)		

# FUNCTION 1
s1 = input()
s2 = input()
result = end_other(s1 ,s2)
#FUNCTION 2
s3 = input()
count = count_code(s3)
#PRINT OUTPUT
print("Output1 is " + str(result))
print("Output2 is " + str(count))