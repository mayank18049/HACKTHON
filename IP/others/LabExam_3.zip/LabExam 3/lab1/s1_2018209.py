#Midterm Lab Exam Set 1- 2018
# Name :  Abhinay Gupta
# Roll Number : 2018209
#Section : B
#Group : 2
#Date : 23-09-2018
#PC Name : L317-PC13
   


def end_other(s1,s2) :
	b1=s1.lower()
	b2=s2.lower()
	a1=len(s1)
	a2=len(s2)
	if a1 > a2 :
		if b1[a1-a2 : ] == b2 :
			return True
		else :
			return False
	elif a1 < a2 :
		if b2[a2-a1 : ] == b1 :
			return True
		else :
			return False
	elif a1==a2 :
		if b2==b1:
			return True 
		else:
			return False

def count_code(s3) :
	a= len(s3)
	count=0
	for i in range(a):
		if i <= a-4 :
			if s3[i]=="c" and s3[i+1]=="o" and s3[ i+3]=="e" :
				count+=1
	return count


print("Output1 is "+ str(end_other("Hiabc" , "abc")))
print("Output1 is "+ str(count_code("cozexxcope")))
print("Output1 is "+ str(end_other("Abc" , "HiaBc")))
print("Output1 is "+ str(count_code("aaacodebbb")))
print("Output1 is "+ str(end_other("abc" , "abXabc")))
print("Output1 is "+ str(count_code("cpdeexxcode")))
print("Output1 is "+ str(end_other("abc" , "defx")))
print("Output1 is "+ str(count_code("aabbccc")))
print("Output1 is "+ str(count_code("cogecode")))

			
