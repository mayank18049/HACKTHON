#Midterm Lab Exam Set 1- 2018
#Name: Smera Goel
#Roll Number: 2018315
#Section: B
#Group: 4
#Date: 23-09-2018

import string

#function1
def end_other(s1,s2):

	t1=''
	t2=''
	for c in s1:
		x=string.ascii_lowercase
		if(c in x):
			a=x.index(c)
			c=string.ascii_uppercase[a]
		t1=t1+c
	for c in s2:
		x=string.ascii_lowercase
		if(c in x):
			a=x.index(c)
			c=string.ascii_uppercase[a]
		t2=t2+c
	
	len1=len(s1)
	len2=len(s2)
	if(len1<len2):
		t2=t2[-len1:]
		if(t1==t2):
			return True
		else:
			return False
	else:
		t1=t1[-len2:]
		if(t2==t1):
			return True
		else:
			return False

#function 2
def count_code(s3):
	count=0
	for c in string.ascii_lowercase:
		x='co' + c + 'e'
		count=count + s3.count(x)
	return(count)			


