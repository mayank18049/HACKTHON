# Midterm Lab Exam Set 1 - 2018
# Name: Kunal Gupta
# Roll Number: 2018240
# Section: B
# Group: 1 
# Date: 23.09.2018


# Function1

def end_other(s1,s2):

	return True	



# Function2

def count_code(s3):


	m1=s3.find("coae")
	m2=s3.find("cobe")
	m3=s3.find("coce")
	m4=s3.find("code")
	m5=s3.find("coee")
	m6=s3.find("cofe")
	m7=s3.find("coge")
	m8=s3.find("cohe")
	m9=s3.find("coie")
	m10=s3.find("coje")
	m11=s3.find("coke")
	m12=s3.find("cole")
	m13=s3.find("come")
	m14=s3.find("cone")
	m15=s3.find("cooe")
	m16=s3.find("cope")
	m17=s3.find("coqe")
	m18=s3.find("core")
	m19=s3.find("cose")
	m20=s3.find("cote")
	m21=s3.find("coue")
	m22=s3.find("cove")
	m23=s3.find("cowe")
	m24=s3.find("coxe")
	m25=s3.find("coye")
	m26=s3.find("coze")
	
	count=0

	if(m1>0):
		count=count+1
	if(m2>=0):
		count=count+1
	if(m3>=0):
		count=count+1
	if(m4>=0):
		count=count+1
	if(m5>=0):
		count=count+1
	if(m6>=0):
		count=count+1
	if(m7>=0):
		count=count+1
	if(m8>=0):
		count=count+1
	if(m9>=0):
		count=count+1
	if(m10>=0):
		count=count+1
	if(m11>=0):
		count=count+1
	if(m12>=0):
		count=count+1
	if(m13>=0):
		count=count+1
	if(m14>=0):
		count=count+1
	if(m15>=0):
		count=count+1
	if(m16>=0):
		count=count+1
	if(m17>=0):
		count=count+1
	if(m18>=0):
		count=count+1
	if(m19>=0):
		count=count+1
	
	if(m20>=0):
		count=count+1
	if(m21>=0):
		count=count+1
	if(m22>=0):
		count=count+1
	if(m23>=0):
		count=count+1
	if(m24>=0):
		count=count+1
	if(m25>=0):
		count=count+1
	if(m26>=0):
		count=count+1
	return count











# Print Output

print("Output1 is " + str(end_other("Hiabc","abc")))
print("Output2 is " + str(count_code("cozexxcope")))




