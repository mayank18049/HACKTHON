#Midtrerm Lab Exam Set 1 - 2018
#Name : Kunal Verma
#Roll Number : 2018241
#Section : B
#Group : 2
#Date : 23-09-2018, Sunday

def end_other(s1,s2):
	if s1.casefold()==s2[(len(s2)-len(s1)):].casefold() :
		return True
	elif s2.casefold()==s1[(len(s1)-len(s2)):].casefold():
		return True
	else :
		return False

def count_code(s3):
	tn=0
	for i in range(0,256):
		ch=chr(i)
		s='co'+ch+'e'
		n=s3.count(s)
		tn=tn+n
	return tn

#main
if __name__=='__main__' :
	print("Output1 is " + str(end_other('Hiabc','abc')))
	print("Output2 is " + str(count_code('cozexxcope')))


