#Midterm Lab Exam Set 1 - 2018
#Name: Ritwik Kar
#Roll Number: 2018306
#Section: B
#Group: 3
#Date: 23/09/2018
#function1
def end_other(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	s1_n=len(s1)
	s2_n=len(s2)
	if s1_n>s2_n:
		s1_c=s1[-s2_n:]
		if s1_c==s2:
			return True
		else:
			return False	
	elif s2_n>s1_n:
		s2_c=s2[-s1_n:]
		if s2_c==s1:
			return True
		else:
			return False
	else:
		if s1==s2:
			return True
		else:
			return False

#function2
def count_code(s3):
	sum=0
	p='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
	q='1234567890'
	r='`~!@#$%^&*()-_=+|,<.>/?[]{}\\\'\"'
	for s in p:
		check='co'+s+'e'
		sum=sum+s3.count(check)
	for s in q:
		check='co'+s+'e'
		sum=sum+s3.count(check)
	for s in r:
		check='co'+s+'e'
		sum=sum+s3.count(check)				
		#print(s)
	return sum

#if __name__=='__main__':
#print("Output1 is "+str(end_other("Hiabc","abc")))			
#print("Output2 is "+str(count_code("cozexxcope")))