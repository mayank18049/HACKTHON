#Shivangi Dhiman
#2018265
#Section B
#Group 2
def end_other(s1,s2):
	n1=len(s1)
	n2=len(s2)
	s1=s1.lower()
	s2=s2.lower()
	if(s1[(n1-n2):]==s2 or s2[(n2-n1):]==s1):
		return True
	else:
		return False

def count_code(s3):
	count=0
	n3=s3.find("c")
	
	if(s3[n3]=="c" and s3[n3+1]=="o" and s3[n3+3]=="e"):
		count=count+1
		return count

