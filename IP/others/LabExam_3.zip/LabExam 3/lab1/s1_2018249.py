#Midterm Lab Exam Set 1- 2018
#Name: Nikunj Singhal
#Roll Number: 2018249
#Section: B
#group: 2
#Date: 20/09/2018




def end_other(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	y=s1[-1::-1]
	z=s2[-1::-1]
	if y==z[0:len(y)]:
		return True
	elif z==y[0:len(z)]:
		return True
	else:
		return False
		


def count_code(s3):
	count=0
	x=-2
	while x!=-1:
		x=s3.find('co',x+2)
		if x!=-1:
			if s3[x+3]=='e':
				count+=1
	return count




