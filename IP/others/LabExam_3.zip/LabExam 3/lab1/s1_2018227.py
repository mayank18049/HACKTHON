# Midterm lab exam set 1 - 2018
# avinash
# 2018227
# B
# 4
# 23/09/18
 

 # function 1
 


def end_other(s1,s2):
	s1=s1.lower()
	s2=s2.lower()
	a=len(s1)
	b=len(s2)
	if s1[a-b:]==s2[:] and a>b:
		return True 
	elif s1[:]==s2[b-a:] and b>a:
		return True 
	elif s1==s2 and a==b:
		return True
	else:
		return False



# function 2

def count_code(s3):
	#if 
	a="code"
	#b=s3.count(a)
	#c=a.replace("d","n")
	if a=="code":
		b=s3.count(a)
		return b
	else:
		c=a.replace("d","n")
		d=s3.count(c)
		return d
	




	#b=s3.count(c)
	 

