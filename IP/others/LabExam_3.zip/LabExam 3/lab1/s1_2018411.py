#Midterm Lab Exam Set1
#name: sanskar sachdeva
#roll number: 2018411
#section: B
#GROUP: 4
#FUNCTION1
def end_other(s1,s2):
	s1= str(input= 's1')
	s2= str(input= 's2')
print('s1'+'s2')