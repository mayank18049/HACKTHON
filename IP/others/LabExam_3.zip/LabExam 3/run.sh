rm results;

touch results;

counter=0

for i in $(ls lab*/*py);
do
	echo "Evaluating" $i;
    echo -n $(basename $i | grep -o "_[0-9]\+" | grep -o "[0-9]\+") >>results;

    timeout 2 python evaluate.py $i 0 </dev/null >/dev/null;

    if [ $? -ne 0 ]
    then
    	echo -n ,0.00 >>results;
    fi

    timeout 2 python evaluate.py $i 1 </dev/null >/dev/null;
	if [ $? -ne 0 ]
    then
    	echo -n ,0.00 >>results;
    fi

    echo >>results;

    : '
    if [ $counter -eq 100 ]
    then
    	exit 0;
	fi
    counter=$(($counter+1));
    '
done

sort results > results.csv
