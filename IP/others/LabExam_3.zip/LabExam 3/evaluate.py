from test_cases import names, cases
import sys

from importlib import __import__

# sys.argv[1] == file name
# sys.argv[2] == func number

def get_lab(x):
	return int(x.split("/")[0].replace("lab", ""))

def get_score():
	score = 0.0

	try:
		mod = __import__(mod_name, fromlist=[names[lab_num][que_num]])
		fun = getattr(mod, names[lab_num][que_num])

	except:
		return score

	for x, y in cases[lab_num][que_num]:
		try:
			res = fun(*x)

			assert res == y

			score += 1
		except:
			pass

	score /= float(len(cases[lab_num][que_num]))

	return score

if __name__ == "__main__":
	lab_num = get_lab(sys.argv[1])
	que_num = int(sys.argv[2])

	mod_name = sys.argv[1].replace("/", ".").strip(".py")

	score = get_score()

	file = open("results", "a")

	print(",{:.2f}".format(score), end="", file=file)

	file.close()
