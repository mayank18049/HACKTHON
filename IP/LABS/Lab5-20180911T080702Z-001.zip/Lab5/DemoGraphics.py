# DemoGraphics.py
# CS 1110 (cs-1110profs-L@cornell.edu)
# February, 2016
""" Draws a design with squares and a design
with rings."""

from SimpleGraphics import *

# First Figure
MakeWindow(6,bgcolor=DARKGRAY,labels=False)
DrawRect(0,0,6,6,FillColor=CYAN,EdgeWidth=5,theta=0)
# Add more squares...


# Second Figure
MakeWindow(10,bgcolor=DARKGRAY,labels=False)
# Rings
DrawDisk(0,1,2,EdgeWidth=10)
# Add more rings...

ShowWindow()
